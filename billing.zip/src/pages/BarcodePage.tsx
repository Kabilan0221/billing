import React, { useState, useEffect, useRef } from 'react';
import {
  QrCode,
  Printer,
  Download,
  Copy,
  Check,
  Search,
  Sparkles,
  Layers,
  Scan,
  Camera,
  RefreshCw,
  Tag,
  Boxes,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Sliders,
  Maximize2,
  Edit3,
  Save,
} from 'lucide-react';
import JsBarcode from 'jsbarcode';
import { Product, Category, AppSettings } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { generateUniqueBarcode, playScanBeep } from '../utils/barcode';
import { BarcodeScannerModal } from '../components/BarcodeScannerModal';
import { useTheme } from '../context/ThemeContext';

interface BarcodePageProps {
  currentLang: Language;
  initialProductId?: number;
}

type LabelPreset = '50x25' | '40x20' | '38x25' | '100x50' | 'a4_24' | 'a4_40';

export const BarcodePage: React.FC<BarcodePageProps> = ({ currentLang, initialProductId }) => {
  const { isLight } = useTheme();
  const t = translations[currentLang];

  const [activeTab, setActiveTab] = useState<'studio' | 'bulk' | 'scanner'>('studio');
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Studio State
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [customBarcode, setCustomBarcode] = useState('');
  const [customTitle, setCustomTitle] = useState('');
  const [customPrice, setCustomPrice] = useState('');
  const [customBatch, setCustomBatch] = useState('B-2601');
  const [labelPreset, setLabelPreset] = useState<LabelPreset>('50x25');
  const [copies, setCopies] = useState<number>(1);

  // Label Customizer Toggles
  const [showStoreName, setShowStoreName] = useState(true);
  const [showTitle, setShowTitle] = useState(true);
  const [showBarcodeText, setShowBarcodeText] = useState(true);
  const [showPrice, setShowPrice] = useState(true);
  const [showBatch, setShowBatch] = useState(false);
  const [barcodeHeight, setBarcodeHeight] = useState<number>(42);
  const [barcodeWidth, setBarcodeWidth] = useState<number>(1.6);
  const [copied, setCopied] = useState(false);

  // Bulk State
  const [bulkCategory, setBulkCategory] = useState<string>('all');
  const [bulkSearch, setBulkSearch] = useState('');
  const [selectedProductIds, setSelectedProductIds] = useState<Set<number>>(new Set());
  const [bulkQuantities, setBulkQuantities] = useState<Record<number, number>>({});

  // Scanner Station State
  const [scannedCode, setScannedCode] = useState('');
  const [scannedProduct, setScannedProduct] = useState<Product | null>(null);
  const [scanHistory, setScanHistory] = useState<Array<{ code: string; time: string; product?: Product }>>([]);
  const [showCameraModal, setShowCameraModal] = useState(false);
  const [scannerStatusMessage, setScannerStatusMessage] = useState<string | null>(null);

  const previewSvgRef = useRef<SVGSVGElement | null>(null);
  const scannerInputRef = useRef<HTMLInputElement | null>(null);

  // Load products & settings
  const loadData = async () => {
    try {
      setIsLoading(true);
      const [prods, cats, sett] = await Promise.all([
        ipcClient.getProducts(),
        ipcClient.getCategories(),
        ipcClient.getSettings(),
      ]);
      setProducts(prods);
      setCategories(cats);
      setSettings(sett);

      if (prods.length > 0) {
        const target = initialProductId
          ? prods.find((p) => p.id === initialProductId) || prods[0]
          : prods[0];
        setSelectedProductId(target.id.toString());
        setCustomBarcode(target.barcode);
        setCustomTitle(target.name);
        setCustomPrice(target.selling_price.toString());
      }
    } catch (err) {
      console.error('Failed to load barcode page data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // When selected product changes in studio
  const handleProductSelect = (idStr: string) => {
    setSelectedProductId(idStr);
    if (idStr === 'custom') {
      const newBarcode = generateUniqueBarcode(products.map((p) => p.barcode));
      setCustomBarcode(newBarcode);
      setCustomTitle('Custom Item');
      setCustomPrice('100');
    } else {
      const prod = products.find((p) => p.id.toString() === idStr);
      if (prod) {
        setCustomBarcode(prod.barcode);
        setCustomTitle(prod.name);
        setCustomPrice(prod.selling_price.toString());
      }
    }
  };

  // Generate new barcode number
  const handleGenerateNewBarcode = () => {
    const fresh = generateUniqueBarcode(products.map((p) => p.barcode));
    setCustomBarcode(fresh);
    playScanBeep(true);
  };

  const [saveFeedback, setSaveFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const handleSaveBarcodeToProduct = async () => {
    if (!customBarcode.trim()) {
      setSaveFeedback({
        type: 'error',
        message: currentLang === 'ta' ? 'பார்கோடு எண் காலியாக இருக்கக்கூடாது' : 'Barcode number cannot be empty',
      });
      return;
    }
    if (selectedProductId && selectedProductId !== 'custom') {
      const prod = products.find((p) => p.id.toString() === selectedProductId);
      if (prod) {
        try {
          const updated = await ipcClient.saveProduct({
            ...prod,
            barcode: customBarcode.trim(),
            name: customTitle.trim() || prod.name,
            selling_price: parseFloat(customPrice) || prod.selling_price,
          });
          setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
          setSaveFeedback({
            type: 'success',
            message:
              currentLang === 'ta'
                ? `பார்கோடு "${customBarcode.trim()}" SQLite தரவுத்தளத்தில் வெற்றிகரமாக சேமிக்கப்பட்டது!`
                : `Barcode "${customBarcode.trim()}" successfully saved to product in SQLite database!`,
          });
          setTimeout(() => setSaveFeedback(null), 4000);
        } catch (err: any) {
          setSaveFeedback({
            type: 'error',
            message: err?.message || 'Failed to update barcode in database',
          });
        }
      }
    } else {
      setSaveFeedback({
        type: 'success',
        message:
          currentLang === 'ta'
            ? `தனிப்பயன் பார்கோடு "${customBarcode.trim()}" அச்சிட தயாராக உள்ளது!`
            : `Custom barcode "${customBarcode.trim()}" ready for printing!`,
      });
      setTimeout(() => setSaveFeedback(null), 3000);
    }
  };

  // Render SVG barcode in preview
  useEffect(() => {
    if (!previewSvgRef.current || !customBarcode.trim()) return;
    try {
      JsBarcode(previewSvgRef.current, customBarcode.trim(), {
        format: 'CODE128',
        width: barcodeWidth,
        height: barcodeHeight,
        displayValue: showBarcodeText,
        fontSize: 12,
        font: 'monospace',
        fontOptions: 'bold',
        textMargin: 3,
        margin: 4,
        background: '#ffffff',
        lineColor: '#000000',
      });
    } catch (e) {
      console.warn('Barcode preview render error:', e);
    }
  }, [customBarcode, barcodeWidth, barcodeHeight, showBarcodeText]);

  // Copy Barcode
  const handleCopyBarcode = () => {
    if (!customBarcode) return;
    navigator.clipboard.writeText(customBarcode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Print Label Studio (Formatted for thermal printer or stickers)
  const handlePrintStudio = () => {
    const printWindow = window.open('', '_blank', 'width=800,height=700');
    if (!printWindow) return;

    const storeName = settings?.business_name || 'TINY DEAMON WORKS';
    const currency = settings?.currency_symbol || '₹';
    const svgCode = previewSvgRef.current?.outerHTML || '';

    let labelDims = { width: '50mm', height: '25mm', padding: '2mm' };
    if (labelPreset === '40x20') labelDims = { width: '40mm', height: '20mm', padding: '1.5mm' };
    if (labelPreset === '38x25') labelDims = { width: '38mm', height: '25mm', padding: '1.5mm' };
    if (labelPreset === '100x50') labelDims = { width: '100mm', height: '50mm', padding: '4mm' };

    const isA4 = labelPreset === 'a4_24' || labelPreset === 'a4_40';
    const totalStickers = isA4 ? (labelPreset === 'a4_24' ? 24 : 40) : copies;

    let stickersHtml = '';
    for (let i = 0; i < totalStickers; i++) {
      stickersHtml += `
        <div class="sticker-card">
          ${showStoreName ? `<div class="store-header">${storeName}</div>` : ''}
          ${showTitle ? `<div class="item-title">${customTitle}</div>` : ''}
          <div class="barcode-wrapper">${svgCode}</div>
          <div class="bottom-row">
            ${showPrice ? `<div class="price-tag">${currency}${parseFloat(customPrice || '0').toFixed(2)}</div>` : ''}
            ${showBatch ? `<div class="batch-tag">${customBatch}</div>` : ''}
          </div>
        </div>
      `;
    }

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Print Barcode - ${customTitle}</title>
          <style>
            @page {
              margin: ${isA4 ? '8mm' : '0'};
              size: ${isA4 ? 'A4 portrait' : `${labelDims.width} ${labelDims.height}`};
            }
            body {
              margin: 0;
              padding: ${isA4 ? '4mm' : '1mm'};
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              background: #fff;
              color: #000;
              -webkit-print-color-adjust: exact;
            }
            ${
              isA4
                ? `
              .sheet-container {
                display: grid;
                grid-template-columns: repeat(${labelPreset === 'a4_24' ? 3 : 4}, 1fr);
                gap: 2mm;
              }
            `
                : `
              .sheet-container {
                display: flex;
                flex-direction: column;
                align-items: center;
              }
            `
            }
            .sticker-card {
              box-sizing: border-box;
              width: ${labelDims.width};
              height: ${labelDims.height};
              padding: ${labelDims.padding};
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: space-between;
              text-align: center;
              page-break-inside: avoid;
              border: ${isA4 ? '1px dashed #ccc' : 'none'};
              overflow: hidden;
            }
            .store-header {
              font-size: 8px;
              font-weight: 800;
              text-transform: uppercase;
              letter-spacing: 0.5px;
              line-height: 1;
              margin-bottom: 1px;
            }
            .item-title {
              font-size: 9px;
              font-weight: 700;
              line-height: 1.1;
              max-width: 100%;
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
            }
            .barcode-wrapper {
              display: flex;
              justify-content: center;
              align-items: center;
              margin: 1px 0;
            }
            .barcode-wrapper svg {
              max-width: 95%;
              height: auto;
              display: block;
            }
            .bottom-row {
              width: 100%;
              display: flex;
              justify-content: space-between;
              align-items: center;
              padding: 0 4px;
            }
            .price-tag {
              font-size: 10px;
              font-weight: 900;
            }
            .batch-tag {
              font-size: 7px;
              color: #555;
              font-mono;
            }
          </style>
        </head>
        <body>
          <div class="sheet-container">
            ${stickersHtml}
          </div>
          <script>
            window.onload = function() {
              window.print();
              setTimeout(function() { window.close(); }, 500);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Download SVG
  const handleDownloadSvg = () => {
    if (!previewSvgRef.current) return;
    const svgData = new XMLSerializer().serializeToString(previewSvgRef.current);
    const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `barcode-${customBarcode || 'label'}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Bulk Label Filtering & Selection
  const filteredBulkProducts = products.filter((p) => {
    const matchCat = bulkCategory === 'all' || p.category_id?.toString() === bulkCategory;
    const matchSearch =
      p.name.toLowerCase().includes(bulkSearch.toLowerCase()) ||
      p.barcode.toLowerCase().includes(bulkSearch.toLowerCase());
    return matchCat && matchSearch;
  });

  const handleToggleSelectAllBulk = () => {
    if (selectedProductIds.size === filteredBulkProducts.length) {
      setSelectedProductIds(new Set());
    } else {
      const allIds = new Set(filteredBulkProducts.map((p) => p.id));
      setSelectedProductIds(allIds);
      const newQtys = { ...bulkQuantities };
      filteredBulkProducts.forEach((p) => {
        if (!newQtys[p.id]) newQtys[p.id] = Math.max(1, p.current_stock || 1);
      });
      setBulkQuantities(newQtys);
    }
  };

  const handleToggleSelectOneBulk = (id: number) => {
    const next = new Set(selectedProductIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
      if (!bulkQuantities[id]) {
        const prod = products.find((p) => p.id === id);
        setBulkQuantities((prev) => ({ ...prev, [id]: Math.max(1, prod?.current_stock || 1) }));
      }
    }
    setSelectedProductIds(next);
  };

  // Print Bulk Selected
  const handlePrintBulk = () => {
    if (selectedProductIds.size === 0) {
      alert('Please select at least one product to print barcodes.');
      return;
    }

    const printWindow = window.open('', '_blank', 'width=900,height=800');
    if (!printWindow) return;

    const storeName = settings?.business_name || 'TINY DEAMON WORKS';
    const currency = settings?.currency_symbol || '₹';

    const selectedProds = products.filter((p) => selectedProductIds.has(p.id));

    // Create temporary SVGs
    const tempContainer = document.createElement('div');
    document.body.appendChild(tempContainer);

    let stickersHtml = '';
    selectedProds.forEach((prod) => {
      const count = bulkQuantities[prod.id] || 1;
      const svgElem = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      tempContainer.appendChild(svgElem);

      try {
        JsBarcode(svgElem, prod.barcode, {
          format: 'CODE128',
          width: 1.5,
          height: 38,
          displayValue: true,
          fontSize: 11,
          font: 'monospace',
          textMargin: 2,
          margin: 3,
        });
      } catch (err) {
        console.warn('Bulk barcode render error:', prod.barcode, err);
      }

      const svgHtml = svgElem.outerHTML;

      for (let i = 0; i < count; i++) {
        stickersHtml += `
          <div class="sticker-card">
            <div class="store-header">${storeName}</div>
            <div class="item-title">${prod.name}</div>
            <div class="barcode-wrapper">${svgHtml}</div>
            <div class="bottom-row">
              <span class="price-tag">${currency}${prod.selling_price.toFixed(2)}</span>
              <span class="stock-tag">Stock: ${prod.current_stock}</span>
            </div>
          </div>
        `;
      }
    });

    document.body.removeChild(tempContainer);

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Bulk Barcode Sheet</title>
          <style>
            @page {
              margin: 6mm;
              size: A4 portrait;
            }
            body {
              margin: 0;
              padding: 4mm;
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              background: #fff;
              color: #000;
            }
            .sheet-grid {
              display: grid;
              grid-template-columns: repeat(3, 1fr);
              gap: 3mm;
            }
            .sticker-card {
              border: 1px dashed #bbb;
              padding: 2.5mm;
              height: 28mm;
              box-sizing: border-box;
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: space-between;
              text-align: center;
              page-break-inside: avoid;
            }
            .store-header {
              font-size: 8px;
              font-weight: bold;
              text-transform: uppercase;
              line-height: 1;
            }
            .item-title {
              font-size: 9px;
              font-weight: 700;
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
              max-width: 100%;
            }
            .barcode-wrapper svg {
              max-width: 95%;
              height: auto;
              display: block;
            }
            .bottom-row {
              width: 100%;
              display: flex;
              justify-content: space-between;
              font-size: 9px;
              font-weight: bold;
            }
            .stock-tag {
              font-size: 8px;
              color: #555;
            }
          </style>
        </head>
        <body>
          <div class="sheet-grid">
            ${stickersHtml}
          </div>
          <script>
            window.onload = function() {
              window.print();
              setTimeout(function() { window.close(); }, 500);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  // Hardware Barcode Scanner & Lookup
  const handleScannerSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const code = scannedCode.trim();
    if (!code) return;

    const found = products.find(
      (p) => p.barcode.toLowerCase() === code.toLowerCase() || p.name.toLowerCase() === code.toLowerCase()
    );

    if (found) {
      playScanBeep(true);
      setScannedProduct(found);
      setScannerStatusMessage(`Found product '${found.name}' (Stock: ${found.current_stock})`);
      setScanHistory((prev) => [
        { code, time: new Date().toLocaleTimeString(), product: found },
        ...prev.slice(0, 19),
      ]);
    } else {
      playScanBeep(false);
      setScannedProduct(null);
      setScannerStatusMessage(`Barcode '${code}' not found in database.`);
      setScanHistory((prev) => [
        { code, time: new Date().toLocaleTimeString() },
        ...prev.slice(0, 19),
      ]);
    }
    setScannedCode('');
    scannerInputRef.current?.focus();
  };

  return (
    <div
      id="barcode-page-container"
      className={`p-6 space-y-6 max-w-7xl mx-auto min-h-screen ${
        isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-950 text-slate-100'
      }`}
    >
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">
                {currentLang === 'ta' ? 'பார்கோடு மையம்' : 'Barcode Center'}
              </h1>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                {currentLang === 'ta'
                  ? 'பார்கோடு லேபிள் அச்சிடுதல், ஸ்டிக்கர் வடிவமைப்பு மற்றும் ஸ்கேனர் சோதனை'
                  : 'Barcode label printing, custom sticker studio & hardware scanner lookup'}
              </p>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div
          className={`flex items-center p-1 rounded-xl border ${
            isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
          }`}
        >
          <button
            id="tab-barcode-studio"
            onClick={() => setActiveTab('studio')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'studio'
                ? 'bg-blue-600 text-white shadow'
                : isLight
                ? 'text-slate-600 hover:text-slate-900'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Tag className="w-3.5 h-3.5" />
            <span>{currentLang === 'ta' ? 'லேபிள் ஸ்டுடியோ' : 'Label Studio'}</span>
          </button>
          <button
            id="tab-barcode-bulk"
            onClick={() => setActiveTab('bulk')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'bulk'
                ? 'bg-blue-600 text-white shadow'
                : isLight
                ? 'text-slate-600 hover:text-slate-900'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{currentLang === 'ta' ? 'மொத்த பார்கோடுகள்' : 'Bulk Barcodes'}</span>
          </button>
          <button
            id="tab-barcode-scanner"
            onClick={() => {
              setActiveTab('scanner');
              setTimeout(() => scannerInputRef.current?.focus(), 100);
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'scanner'
                ? 'bg-blue-600 text-white shadow'
                : isLight
                ? 'text-slate-600 hover:text-slate-900'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Scan className="w-3.5 h-3.5" />
            <span>{currentLang === 'ta' ? 'ஸ்கேனர் சோதனை' : 'Scanner Station'}</span>
          </button>
        </div>
      </div>

      {/* TAB 1: STUDIO */}
      {activeTab === 'studio' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Controls (7 cols) */}
          <div
            className={`lg:col-span-7 p-6 rounded-2xl border space-y-5 ${
              isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
              <h2 className="text-sm font-semibold flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-600" />
                <span>{currentLang === 'ta' ? 'லேபிள் அமைப்புகள்' : 'Label Customizer & Content'}</span>
              </h2>
              <button
                type="button"
                onClick={handleGenerateNewBarcode}
                className="flex items-center gap-1.5 text-xs text-blue-600 hover:text-blue-700 font-medium cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{currentLang === 'ta' ? 'புதிய பார்கோடு உருவாக்கு' : 'Auto Generate Code'}</span>
              </button>
            </div>

            {/* Product selection */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {currentLang === 'ta' ? 'பொருளைத் தேர்ந்தெடுக்கவும்' : 'Select Product or Custom'}
              </label>
              <select
                id="barcode-product-select"
                value={selectedProductId}
                onChange={(e) => handleProductSelect(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-sm border font-medium outline-none transition-all ${
                  isLight
                    ? 'bg-slate-50 border-slate-300 text-slate-900 focus:border-blue-600 focus:bg-white'
                    : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-blue-500'
                }`}
              >
                <option value="custom">-- {currentLang === 'ta' ? 'கைமுறை உள்ளீடு' : 'Custom Barcode & Text'} --</option>
                {products.map((p) => (
                  <option key={p.id} value={p.id.toString()}>
                    {p.name} ({p.barcode}) - ₹{p.selling_price} [Stock: {p.current_stock}]
                  </option>
                ))}
              </select>
            </div>

            {/* Save Feedback Banner */}
            {saveFeedback && (
              <div
                className={`p-3 rounded-xl border flex items-center justify-between text-xs font-semibold ${
                  saveFeedback.type === 'success'
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-800 dark:bg-emerald-950/60 dark:border-emerald-700 dark:text-emerald-300'
                    : 'bg-red-50 border-red-300 text-red-800 dark:bg-red-950/60 dark:border-red-700 dark:text-red-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  {saveFeedback.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
                  )}
                  <span>{saveFeedback.message}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setSaveFeedback(null)}
                  className="text-slate-400 hover:text-slate-700 dark:hover:text-white"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Editable Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label
                    className={`text-xs font-semibold flex items-center gap-1.5 ${
                      isLight ? 'text-slate-800' : 'text-slate-200'
                    }`}
                  >
                    <Edit3 className="w-3.5 h-3.5 text-blue-600" />
                    <span>{currentLang === 'ta' ? 'பார்கோடு எண் (இயல்புநிலை / திருத்தலாம்)' : 'Barcode Number (Default / Editable)'}</span>
                  </label>
                  <span className="text-[10px] text-blue-600 font-semibold">
                    {currentLang === 'ta' ? 'தட்டச்சு செய்யலாம்' : 'Click & Edit'}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="relative flex-1">
                    <input
                      id="input-barcode-number"
                      type="text"
                      value={customBarcode}
                      onChange={(e) => setCustomBarcode(e.target.value)}
                      placeholder={currentLang === 'ta' ? 'பார்கோடு உள்ளிடவும்...' : 'Enter or edit barcode...'}
                      className={`w-full pl-3 pr-3 py-2.5 rounded-xl text-sm font-mono border-2 font-bold outline-none cursor-text transition-all ${
                        isLight
                          ? 'bg-white border-blue-400 text-slate-900 focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                          : 'bg-slate-800 border-blue-500/60 text-slate-100 focus:border-blue-400 focus:ring-2 focus:ring-blue-500/20'
                      }`}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleGenerateNewBarcode}
                    title={currentLang === 'ta' ? 'புதிய குறியீடு உருவாக்கு' : 'Auto Generate New Code'}
                    className={`p-2.5 rounded-xl border transition-colors cursor-pointer text-xs font-semibold flex items-center justify-center shrink-0 ${
                      isLight
                        ? 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100'
                        : 'bg-blue-950/60 text-blue-300 border-blue-800 hover:bg-blue-900'
                    }`}
                  >
                    <Sparkles className="w-4 h-4 text-blue-600" />
                  </button>
                  <button
                    type="button"
                    onClick={handleCopyBarcode}
                    title="Copy Barcode"
                    className={`p-2.5 rounded-xl border transition-colors cursor-pointer shrink-0 ${
                      isLight
                        ? 'hover:bg-slate-100 border-slate-300 text-slate-700 bg-white'
                        : 'hover:bg-slate-800 border-slate-700 text-slate-300 bg-slate-800'
                    }`}
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4 text-slate-400" />}
                  </button>
                </div>

                {/* Status info about barcode */}
                {selectedProductId && selectedProductId !== 'custom' && (() => {
                  const currentProd = products.find((p) => p.id.toString() === selectedProductId);
                  const isModified = currentProd && currentProd.barcode !== customBarcode;
                  return (
                    <div className="space-y-1.5 pt-1">
                      {isModified ? (
                        <div className="flex items-center justify-between text-[11px] text-amber-600 dark:text-amber-400 font-medium">
                          <span>Original: <strong className="font-mono">{currentProd.barcode}</strong></span>
                          <button
                            type="button"
                            onClick={() => setCustomBarcode(currentProd.barcode)}
                            className="underline hover:text-amber-700 cursor-pointer"
                          >
                            Reset to Default
                          </button>
                        </div>
                      ) : (
                        <div className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span>Original product barcode is set as default</span>
                        </div>
                      )}
                      <button
                        type="button"
                        onClick={handleSaveBarcodeToProduct}
                        className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-sm cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>
                          {currentLang === 'ta'
                            ? 'பார்கோடை தரவுத்தளத்தில் சேமிக்கவும்'
                            : 'Save Barcode Changes to Product (SQLite)'}
                        </span>
                      </button>
                    </div>
                  );
                })()}

                {selectedProductId === 'custom' && (
                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={async () => {
                        if (!customTitle.trim() || !customBarcode.trim()) {
                          setSaveFeedback({
                            type: 'error',
                            message: 'Please provide product title and barcode to save',
                          });
                          return;
                        }
                        try {
                          const newProd = await ipcClient.saveProduct({
                            barcode: customBarcode.trim(),
                            name: customTitle.trim(),
                            selling_price: parseFloat(customPrice) || 0,
                            purchase_price: 0,
                            opening_stock: 100,
                            current_stock: 100,
                            min_stock_level: 5,
                          });
                          setProducts((prev) => [...prev, newProd]);
                          setSelectedProductId(newProd.id.toString());
                          setSaveFeedback({
                            type: 'success',
                            message: `Saved "${newProd.name}" as new product with barcode ${newProd.barcode}!`,
                          });
                          setTimeout(() => setSaveFeedback(null), 4000);
                        } catch (err) {
                          setSaveFeedback({ type: 'error', message: 'Failed to save new product' });
                        }
                      }}
                      className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-sm cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{currentLang === 'ta' ? 'புதிய பொருளாக சேமிக்கவும்' : 'Save as New Product with this Barcode'}</span>
                    </button>
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-500">
                  {currentLang === 'ta' ? 'பொருளின் பெயர்' : 'Product / Label Title'}
                </label>
                <input
                  type="text"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-sm border font-medium outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:border-blue-600 focus:bg-white'
                      : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-blue-500'
                  }`}
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-500">
                  {currentLang === 'ta' ? 'விற்பனை விலை (₹)' : 'Selling Price (MRP)'}
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={customPrice}
                  onChange={(e) => setCustomPrice(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-sm font-bold border outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:border-blue-600 focus:bg-white'
                      : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-blue-500'
                  }`}
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-500">
                  {currentLang === 'ta' ? 'தொகுதி / பேட்ச் எண்' : 'Batch / Lot No.'}
                </label>
                <input
                  type="text"
                  value={customBatch}
                  onChange={(e) => setCustomBatch(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-sm font-mono border outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:border-blue-600 focus:bg-white'
                      : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-blue-500'
                  }`}
                />
              </div>
            </div>

            {/* Label Presets */}
            <div
              className={`space-y-2 pt-2 border-t ${
                isLight ? 'border-slate-200' : 'border-slate-800'
              }`}
            >
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {currentLang === 'ta' ? 'லேபிள் அளவு' : 'Label Dimension Preset'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { id: '50x25', label: '50 × 25 mm', desc: 'Standard Roll (2"×1")' },
                  { id: '40x20', label: '40 × 20 mm', desc: 'Compact Shelf Tag' },
                  { id: '38x25', label: '38 × 25 mm', desc: 'Small Product Tag' },
                  { id: '100x50', label: '100 × 50 mm', desc: 'Outer Carton (4"×2")' },
                  { id: 'a4_24', label: 'A4 (24 Labels)', desc: '3 Cols × 8 Rows' },
                  { id: 'a4_40', label: 'A4 (40 Labels)', desc: '4 Cols × 10 Rows' },
                ].map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => setLabelPreset(preset.id as LabelPreset)}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      labelPreset === preset.id
                        ? isLight
                          ? 'border-blue-600 bg-blue-50 text-blue-950 font-bold ring-2 ring-blue-400 shadow-xs'
                          : 'border-blue-500 bg-blue-950 text-blue-200 font-bold ring-1 ring-blue-500'
                        : isLight
                        ? 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                        : 'border-slate-800 bg-slate-900/60 hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    <div
                      className={`text-xs font-bold ${
                        labelPreset === preset.id
                          ? isLight
                            ? 'text-blue-950 font-extrabold'
                            : 'text-blue-200 font-extrabold'
                          : isLight
                          ? 'text-slate-800'
                          : 'text-slate-200'
                      }`}
                    >
                      {preset.label}
                    </div>
                    <div
                      className={`text-[10px] truncate ${
                        labelPreset === preset.id
                          ? isLight
                            ? 'text-blue-700 font-medium'
                            : 'text-blue-300'
                          : isLight
                          ? 'text-slate-500'
                          : 'text-slate-400'
                      }`}
                    >
                      {preset.desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Visual elements toggles */}
            <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {currentLang === 'ta' ? 'லேபிளில் காண்பிக்க வேண்டியவை' : 'Elements to Print'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showStoreName}
                    onChange={(e) => setShowStoreName(e.target.checked)}
                    className="w-4 h-4 rounded text-blue-600"
                  />
                  <span>Store Header</span>
                </label>
                <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showTitle}
                    onChange={(e) => setShowTitle(e.target.checked)}
                    className="w-4 h-4 rounded text-blue-600"
                  />
                  <span>Product Title</span>
                </label>
                <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showBarcodeText}
                    onChange={(e) => setShowBarcodeText(e.target.checked)}
                    className="w-4 h-4 rounded text-blue-600"
                  />
                  <span>Barcode Digits</span>
                </label>
                <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showPrice}
                    onChange={(e) => setShowPrice(e.target.checked)}
                    className="w-4 h-4 rounded text-blue-600"
                  />
                  <span>Price / MRP</span>
                </label>
                <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showBatch}
                    onChange={(e) => setShowBatch(e.target.checked)}
                    className="w-4 h-4 rounded text-blue-600"
                  />
                  <span>Batch Date</span>
                </label>
              </div>
            </div>

            {/* Copies Count & Print */}
            <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <label className="text-xs font-semibold text-slate-500">
                  {currentLang === 'ta' ? 'அச்சடிக்க வேண்டிய பிரதிகள்:' : 'Print Copies:'}
                </label>
                <input
                  type="number"
                  min="1"
                  max="500"
                  value={copies}
                  onChange={(e) => setCopies(Math.max(1, parseInt(e.target.value || '1', 10)))}
                  className={`w-20 px-2.5 py-1.5 rounded-lg border text-sm font-bold text-center outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:border-blue-600'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  }`}
                />
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleDownloadSvg}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                    isLight
                      ? 'border-slate-200 hover:bg-slate-100 text-slate-700'
                      : 'border-slate-700 hover:bg-slate-800 text-slate-200'
                  }`}
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>SVG</span>
                </button>
                <button
                  type="button"
                  id="btn-print-barcode"
                  onClick={handlePrintStudio}
                  className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/20 transition-all cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>{currentLang === 'ta' ? 'லேபிள் அச்சிடுக' : 'Print Barcode Labels'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Live Sticker Preview (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div
              className={`p-6 rounded-2xl border flex flex-col items-center justify-center min-h-[380px] text-center ${
                isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
              }`}
            >
              <div className="w-full flex items-center justify-between mb-4">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  {currentLang === 'ta' ? 'நேரடி ஸ்டிக்கர் முன்னோட்டம்' : 'Live Sticker Preview'}
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200 font-bold dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800">
                  {labelPreset.toUpperCase()}
                </span>
              </div>

              {/* Realistic Physical Sticker View */}
              <div className={`p-4 rounded-2xl border w-full flex justify-center items-center ${isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-950 border-slate-800'}`}>
                <div
                  id="live-barcode-sticker"
                  className="bg-white text-slate-950 rounded-lg p-3 shadow-xl border border-slate-300 flex flex-col items-center justify-between text-center select-none"
                  style={{
                    width: labelPreset === '100x50' ? '280px' : '230px',
                    minHeight: labelPreset === '100x50' ? '150px' : '120px',
                  }}
                >
                  {showStoreName && (
                    <div className="text-[9px] font-black uppercase tracking-wider text-slate-800 leading-tight">
                      {settings?.business_name || 'TINY DEAMON WORKS'}
                    </div>
                  )}

                  {showTitle && (
                    <div className="text-[11px] font-bold text-slate-900 max-w-[200px] truncate leading-snug">
                      {customTitle || 'Product Name'}
                    </div>
                  )}

                  {/* Rendered Barcode */}
                  <div className="py-1 flex justify-center items-center w-full">
                    <svg ref={previewSvgRef} className="max-w-[95%] h-auto mx-auto"></svg>
                  </div>

                  <div className="w-full flex items-center justify-between px-1 text-[11px] font-black text-slate-950 border-t border-slate-100 pt-1">
                    {showPrice && (
                      <span>
                        {settings?.currency_symbol || '₹'}
                        {parseFloat(customPrice || '0').toFixed(2)}
                      </span>
                    )}
                    {showBatch && (
                      <span className="text-[8px] font-mono text-slate-600">{customBatch}</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Barcode Info Card */}
              <div className="w-full mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-left text-xs space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">Barcode Symbology:</span>
                  <span className="font-mono font-bold">CODE128 (GS1 Compatible)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Value Length:</span>
                  <span className="font-mono font-bold">{customBarcode.length} Digits</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Printer Target:</span>
                  <span className="font-bold text-blue-600">Thermal Roll / A4 Sticker Sheet</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: BULK BARCODES */}
      {activeTab === 'bulk' && (
        <div
          className={`p-6 rounded-2xl border space-y-4 ${
            isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
          }`}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b pb-4 border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-sm font-semibold">
                {currentLang === 'ta' ? 'மொத்த பார்கோடு அச்சிடுதல்' : 'Inventory Bulk Barcode Generator'}
              </h2>
              <p className="text-xs text-slate-500">
                {currentLang === 'ta'
                  ? 'சரக்கு இருப்புக்கேற்ப பல பொருட்களுக்கான பார்கோடு தாள்களை ஒரே கிளிக்கில் அச்சிடுங்கள்'
                  : 'Select multiple products to print label sheets formatted for A4 or thermal rolls'}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleToggleSelectAllBulk}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                  isLight ? 'border-slate-200 hover:bg-slate-100' : 'border-slate-700 hover:bg-slate-800'
                }`}
              >
                {selectedProductIds.size === filteredBulkProducts.length
                  ? 'Deselect All'
                  : `Select All (${filteredBulkProducts.length})`}
              </button>
              <button
                type="button"
                id="btn-print-bulk"
                onClick={handlePrintBulk}
                disabled={selectedProductIds.size === 0}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50 disabled:cursor-not-allowed shadow cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>
                  {currentLang === 'ta'
                    ? `தேர்வுசெய்தவை (${selectedProductIds.size}) அச்சிடு`
                    : `Print Selected Labels (${selectedProductIds.size})`}
                </span>
              </button>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={bulkSearch}
                onChange={(e) => setBulkSearch(e.target.value)}
                placeholder="Search products by name or barcode..."
                className={`w-full pl-9 pr-3 py-1.5 rounded-xl text-xs border outline-none ${
                  isLight
                    ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                    : 'bg-slate-800 border-slate-700 text-slate-100'
                }`}
              />
            </div>
            <select
              value={bulkCategory}
              onChange={(e) => setBulkCategory(e.target.value)}
              className={`px-3 py-1.5 rounded-xl text-xs border outline-none font-medium ${
                isLight
                  ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white'
                  : 'bg-slate-800 border-slate-700 text-slate-100'
              }`}
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id.toString()}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Bulk Product Table */}
          <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
            <table className="w-full text-left text-xs">
              <thead
                className={`border-b ${
                  isLight ? 'bg-slate-100 text-slate-700 font-semibold border-slate-200' : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}
              >
                <tr>
                  <th className="p-3 w-10">#</th>
                  <th className="p-3">Product</th>
                  <th className="p-3">Barcode</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Price</th>
                  <th className="p-3">Current Stock</th>
                  <th className="p-3 text-right">Print Qty</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredBulkProducts.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-500">
                      No products found.
                    </td>
                  </tr>
                ) : (
                  filteredBulkProducts.map((p) => {
                    const isSelected = selectedProductIds.has(p.id);
                    return (
                      <tr
                        key={p.id}
                        onClick={() => handleToggleSelectOneBulk(p.id)}
                        className={`transition-colors cursor-pointer ${
                          isSelected
                            ? isLight
                              ? 'bg-blue-50/70'
                              : 'bg-blue-950/30'
                            : isLight
                            ? 'hover:bg-slate-50'
                            : 'hover:bg-slate-850'
                        }`}
                      >
                        <td className="p-3" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleToggleSelectOneBulk(p.id)}
                            className="w-4 h-4 rounded text-blue-600 cursor-pointer"
                          />
                        </td>
                        <td className="p-3 font-semibold">{p.name}</td>
                        <td className="p-3 font-mono text-slate-600 dark:text-slate-400">{p.barcode}</td>
                        <td className="p-3 text-slate-500">{p.category_name || '-'}</td>
                        <td className="p-3 font-bold text-slate-900 dark:text-slate-100">
                          ₹{p.selling_price.toFixed(2)}
                        </td>
                        <td className="p-3 font-semibold">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] ${
                              p.current_stock <= p.min_stock_level
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300'
                                : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300'
                            }`}
                          >
                            {p.current_stock} in stock
                          </span>
                        </td>
                        <td className="p-3 text-right" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="number"
                            min="1"
                            max="500"
                            value={bulkQuantities[p.id] || p.current_stock || 1}
                            onChange={(e) =>
                              setBulkQuantities((prev) => ({
                                ...prev,
                                [p.id]: Math.max(1, parseInt(e.target.value || '1', 10)),
                              }))
                            }
                            className={`w-16 px-2 py-1 rounded text-right border text-xs font-bold outline-none ${
                              isLight
                                ? 'bg-white border-slate-300 text-slate-900 focus:border-blue-600'
                                : 'bg-slate-800 border-slate-700 text-slate-100'
                            }`}
                          />
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: SCANNER STATION */}
      {activeTab === 'scanner' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Scan Input & Details (7 cols) */}
          <div
            className={`lg:col-span-7 p-6 rounded-2xl border space-y-5 ${
              isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
              <div>
                <h2 className="text-sm font-semibold flex items-center gap-2">
                  <Scan className="w-4 h-4 text-blue-600" />
                  <span>{currentLang === 'ta' ? 'பார்கோடு ஸ்கேனர் சோதனை' : 'Barcode Scanner Verification'}</span>
                </h2>
                <p className="text-xs text-slate-500">
                  {currentLang === 'ta'
                    ? 'USB லேசர் பார்கோடு கன் அல்லது கேமரா வழியாக உடனடியாக விவரங்களை சரிபார்க்கவும்'
                    : 'Works instantly with any USB barcode scanner gun or webcam camera'}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowCameraModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition-colors cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>{currentLang === 'ta' ? 'கேமரா ஸ்கேனர்' : 'Camera Scan'}</span>
              </button>
            </div>

            {/* Hardware Scanner Input */}
            <form onSubmit={handleScannerSubmit} className="space-y-2">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {currentLang === 'ta' ? 'பார்கோடு உள்ளிடுக / ஸ்கேன் செய்க' : 'Scan or Enter Barcode (Press Enter)'}
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    ref={scannerInputRef}
                    type="text"
                    value={scannedCode}
                    onChange={(e) => setScannedCode(e.target.value)}
                    placeholder="Ready for USB scanner gun input (Press Enter to test)..."
                    className={`w-full px-4 py-3 rounded-xl text-sm font-mono border font-bold outline-none transition-all ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600 focus:ring-2 focus:ring-blue-100'
                        : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-blue-500'
                    }`}
                  />
                </div>
                <button
                  type="submit"
                  className="px-5 py-3 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow transition-all cursor-pointer"
                >
                  Lookup
                </button>
              </div>
            </form>

            {/* Status notification */}
            {scannerStatusMessage && (
              <div
                className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                  scannedProduct
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800'
                    : 'bg-amber-50 text-amber-800 border border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800'
                }`}
              >
                {scannedProduct ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                <span>{scannerStatusMessage}</span>
              </div>
            )}

            {/* Scanned Product Card */}
            {scannedProduct && (
              <div
                className={`p-5 rounded-xl border space-y-4 ${
                  isLight ? 'bg-slate-50/80 border-slate-200' : 'bg-slate-850 border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600">
                      Product Verified
                    </span>
                    <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                      {scannedProduct.name}
                    </h3>
                    <p className="text-xs font-mono text-slate-500">Barcode: {scannedProduct.barcode}</p>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold ${
                      scannedProduct.current_stock <= scannedProduct.min_stock_level
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    }`}
                  >
                    Stock: {scannedProduct.current_stock}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-3 text-xs">
                  <div
                    className={`p-3 rounded-lg border ${
                      isLight ? 'bg-white border-slate-200' : 'bg-slate-800 border-slate-700'
                    }`}
                  >
                    <div className="text-slate-500">Selling Price</div>
                    <div className="text-base font-black text-slate-900 dark:text-slate-100">
                      ₹{scannedProduct.selling_price.toFixed(2)}
                    </div>
                  </div>
                  <div
                    className={`p-3 rounded-lg border ${
                      isLight ? 'bg-white border-slate-200' : 'bg-slate-800 border-slate-700'
                    }`}
                  >
                    <div className="text-slate-500">Purchase Cost</div>
                    <div className="text-base font-black text-slate-900 dark:text-slate-100">
                      ₹{scannedProduct.purchase_price.toFixed(2)}
                    </div>
                  </div>
                  <div
                    className={`p-3 rounded-lg border ${
                      isLight ? 'bg-white border-slate-200' : 'bg-slate-800 border-slate-700'
                    }`}
                  >
                    <div className="text-slate-500">Gross Margin</div>
                    <div className="text-base font-black text-emerald-600">
                      {scannedProduct.selling_price > 0
                        ? `${(
                            ((scannedProduct.selling_price - scannedProduct.purchase_price) /
                              scannedProduct.selling_price) *
                            100
                          ).toFixed(1)}%`
                        : '0%'}
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      handleProductSelect(scannedProduct.id.toString());
                      setActiveTab('studio');
                    }}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow transition-colors cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print Label in Studio</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right Scan History Log (5 cols) */}
          <div
            className={`lg:col-span-5 p-6 rounded-2xl border space-y-4 ${
              isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-semibold">
                {currentLang === 'ta' ? 'அண்மைக்கால ஸ்கேன்கள்' : 'Recent Scan Log'}
              </h3>
              {scanHistory.length > 0 && (
                <button
                  type="button"
                  onClick={() => setScanHistory([])}
                  className="text-xs text-red-500 hover:text-red-600 font-medium cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>

            {scanHistory.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs">
                Scan log is currently empty. Scan with your USB gun or camera.
              </div>
            ) : (
              <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                {scanHistory.map((item, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                      item.product
                        ? isLight
                          ? 'bg-slate-50 border-slate-200'
                          : 'bg-slate-850 border-slate-800'
                        : isLight
                        ? 'bg-red-50/60 border-red-200 text-red-800'
                        : 'bg-red-950/30 border-red-900 text-red-300'
                    }`}
                  >
                    <div className="space-y-0.5">
                      <div className="font-bold">{item.product ? item.product.name : 'Unknown Barcode'}</div>
                      <div className="font-mono text-[11px] text-slate-500">{item.code}</div>
                    </div>
                    <div className="text-right">
                      {item.product && (
                        <div className="font-bold text-slate-900 dark:text-slate-100">
                          ₹{item.product.selling_price.toFixed(2)}
                        </div>
                      )}
                      <div className="text-[10px] text-slate-400">{item.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Camera Barcode Scanner Modal */}
      {showCameraModal && (
        <BarcodeScannerModal
          isOpen={showCameraModal}
          onClose={() => setShowCameraModal(false)}
          onScan={(code) => {
            setScannedCode(code);
            setShowCameraModal(false);
            const found = products.find((p) => p.barcode === code);
            if (found) {
              playScanBeep(true);
              setScannedProduct(found);
              setScannerStatusMessage(`Found product '${found.name}' (Stock: ${found.current_stock})`);
              setScanHistory((prev) => [
                { code, time: new Date().toLocaleTimeString(), product: found },
                ...prev.slice(0, 19),
              ]);
            } else {
              playScanBeep(false);
              setScannedProduct(null);
              setScannerStatusMessage(`Barcode '${code}' not found in database.`);
            }
          }}
          currentLang={currentLang}
        />
      )}
    </div>
  );
};
