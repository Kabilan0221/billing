import React, { useState, useEffect } from 'react';
import { Settings as SettingsIcon, Save, Printer, Building2, CheckCircle2 } from 'lucide-react';
import { BusinessSettings } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';

interface SettingsPageProps {
  currentLang: Language;
  onLanguageChanged: (lang: Language) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  currentLang,
  onLanguageChanged,
}) => {
  const [settings, setSettings] = useState<BusinessSettings>({
    business_name: '',
    business_tagline: '',
    business_phone: '',
    business_email: '',
    business_address: '',
    thermal_printer_width: '80mm',
    receipt_footer: '',
    currency_symbol: '₹',
    language: 'en',
  });

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const t = translations[currentLang];

  const loadSettings = async () => {
    try {
      setIsLoading(true);
      const data = await ipcClient.getSettings();
      setSettings(data);
    } catch (err) {
      console.error('Failed to load settings:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSaving(true);
      await ipcClient.updateSettings(settings);
      setFeedback('Settings updated successfully in SQLite database');
      if (settings.language && settings.language !== currentLang) {
        onLanguageChanged(settings.language as Language);
      }
    } catch (err: any) {
      alert(`Failed to save settings: ${err?.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div id="settings-page-container" className="p-6 space-y-6 max-w-3xl mx-auto">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <SettingsIcon className="w-6 h-6 text-blue-400" />
          <span>{t.businessSettings}</span>
        </h2>
        <p className="text-xs text-slate-400">
          Configure receipt branding, thermal printer paper size, and locale preferences
        </p>
      </div>

      {feedback && (
        <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>{feedback}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-white">
            ✕
          </button>
        </div>
      )}

      {/* Settings Form */}
      <form
        onSubmit={handleSave}
        className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-5 shadow-xl"
      >
        <div className="space-y-4">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Building2 className="w-4 h-4 text-blue-400" />
            <span>Store / Business Profile</span>
          </h3>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              {t.businessName} *
            </label>
            <input
              type="text"
              required
              value={settings.business_name}
              onChange={(e) => setSettings({ ...settings, business_name: e.target.value })}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.businessTagline}
              </label>
              <input
                type="text"
                value={settings.business_tagline}
                onChange={(e) => setSettings({ ...settings, business_tagline: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.businessPhone}
              </label>
              <input
                type="text"
                value={settings.business_phone}
                onChange={(e) => setSettings({ ...settings, business_phone: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.businessEmail}
              </label>
              <input
                type="email"
                value={settings.business_email}
                onChange={(e) => setSettings({ ...settings, business_email: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.currencySymbol}
              </label>
              <input
                type="text"
                value={settings.currency_symbol}
                onChange={(e) => setSettings({ ...settings, currency_symbol: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Store Address
            </label>
            <input
              type="text"
              value={settings.business_address}
              onChange={(e) => setSettings({ ...settings, business_address: e.target.value })}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
            />
          </div>
        </div>

        {/* Thermal Hardware & Receipt settings */}
        <div className="pt-4 border-t border-slate-800 space-y-4">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Printer className="w-4 h-4 text-cyan-400" />
            <span>Thermal Receipt & Printing Hardware</span>
          </h3>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.printerWidth}
              </label>
              <select
                value={settings.thermal_printer_width}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    thermal_printer_width: e.target.value as '58mm' | '80mm',
                  })
                }
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
              >
                <option value="58mm">58mm Thermal Roll (Narrow ~32 cols)</option>
                <option value="80mm">80mm Thermal Roll (Standard ~48 cols)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Default UI Language
              </label>
              <select
                value={settings.language}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    language: e.target.value as Language,
                  })
                }
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
              >
                <option value="en">English</option>
                <option value="ta">தமிழ் (Tamil)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              {t.receiptFooterText}
            </label>
            <input
              type="text"
              value={settings.receipt_footer}
              onChange={(e) => setSettings({ ...settings, receipt_footer: e.target.value })}
              placeholder="e.g. Thank you for shopping with us! Visit again."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
            />
          </div>
        </div>

        <div className="pt-4 border-t border-slate-800 flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md cursor-pointer transition-all"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Saving...' : t.saveSettings}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
