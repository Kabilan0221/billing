import React, { useState } from 'react';
import {
  HardDriveDownload,
  UploadCloud,
  Database,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
} from 'lucide-react';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';

interface BackupRestorePageProps {
  currentLang: Language;
}

export const BackupRestorePage: React.FC<BackupRestorePageProps> = ({ currentLang }) => {
  const [isExporting, setIsExporting] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );

  const t = translations[currentLang];

  const handleDownloadBackup = async () => {
    try {
      setIsExporting(true);
      setStatusMsg(null);
      const uint8Array = await ipcClient.exportDatabase();

      const blob = new Blob([uint8Array], { type: 'application/x-sqlite3' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      link.href = url;
      link.download = `TinyDeamonWorks_Billing_Backup_${timestamp}.sqlite`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setStatusMsg({
        type: 'success',
        text: 'Authoritative SQLite backup file generated and downloaded successfully!',
      });
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: `Backup download failed: ${err?.message}` });
    } finally {
      setIsExporting(false);
    }
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const confirmed = window.confirm(
      'CRITICAL WARNING: Restoring this database backup file will OVERWRITE all current products, bills, stock, and settings. Are you absolutely certain you want to proceed?'
    );

    if (!confirmed) {
      e.target.value = '';
      return;
    }

    try {
      setIsRestoring(true);
      setStatusMsg(null);
      const arrayBuffer = await file.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);

      await ipcClient.restoreDatabase(uint8Array);

      setStatusMsg({
        type: 'success',
        text: 'Database successfully restored and verified from backup file! Reloading views...',
      });

      setTimeout(() => {
        window.location.reload();
      }, 1200);
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: `Restore failed: ${err?.message}` });
    } finally {
      setIsRestoring(false);
      e.target.value = '';
    }
  };

  return (
    <div id="backup-restore-container" className="p-6 space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <HardDriveDownload className="w-6 h-6 text-blue-400" />
          <span>{t.backupTitle}</span>
        </h2>
        <p className="text-xs text-slate-400">
          Export binary SQLite database snapshots or restore existing backups onto this offline desktop workstation
        </p>
      </div>

      {statusMsg && (
        <div
          className={`p-4 rounded-xl border text-xs flex items-center gap-2 ${
            statusMsg.type === 'success'
              ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
              : 'bg-red-950/60 border-red-800 text-red-300'
          }`}
        >
          {statusMsg.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
          )}
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* Grid of actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Backup Card */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-12 h-12 rounded-xl bg-blue-900/40 border border-blue-700/60 flex items-center justify-center text-blue-400">
              <Database className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Export SQLite Database</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              {t.backupDescription} This produces a real offline `.sqlite` database file containing all your products, bills, stock transactions, customer records, and settings.
            </p>
          </div>

          <button
            onClick={handleDownloadBackup}
            disabled={isExporting}
            className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
          >
            <HardDriveDownload className="w-4 h-4" />
            <span>{isExporting ? 'Generating SQLite Backup...' : t.downloadBackup}</span>
          </button>
        </div>

        {/* Restore Card */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl flex flex-col justify-between">
          <div className="space-y-3">
            <div className="w-12 h-12 rounded-xl bg-red-900/40 border border-red-700/60 flex items-center justify-center text-red-400">
              <UploadCloud className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">{t.restoreTitle}</h3>
            <div className="p-3 rounded-lg bg-red-950/40 border border-red-900/80 text-red-300 text-xs flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{t.restoreWarning}</span>
            </div>
          </div>

          <label className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors">
            <UploadCloud className="w-4 h-4 text-cyan-400" />
            <span>{isRestoring ? 'Restoring Database...' : t.selectBackupFile}</span>
            <input
              type="file"
              accept=".sqlite,.db,.sqlite3"
              disabled={isRestoring}
              onChange={handleRestoreFile}
              className="hidden"
            />
          </label>
        </div>
      </div>
    </div>
  );
};
