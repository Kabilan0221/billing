import React, { useState, useEffect } from 'react';
import { History, Search, Printer, Trash2, Calendar, X, AlertCircle } from 'lucide-react';
import { Bill } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { ReceiptModal } from '../components/ReceiptModal';
import { PrintableReceiptData } from '../printing/thermal-printer';
import { useTheme } from '../context/ThemeContext';

interface BillHistoryPageProps {
  currentLang: Language;
}

export const BillHistoryPage: React.FC<BillHistoryPageProps> = ({ currentLang }) => {
  const { isLight } = useTheme();
  const [bills, setBills] = useState<Bill[]>([]);
  const [search, setSearch] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [activeReceipt, setActiveReceipt] = useState<PrintableReceiptData | null>(null);
  const [deleteConfirmBill, setDeleteConfirmBill] = useState<Bill | null>(null);
  const [restoreStockOnDelete, setRestoreStockOnDelete] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);

  const t = translations[currentLang];

  const loadBills = async () => {
    try {
      setIsLoading(true);
      const data = await ipcClient.getBills({
        search: search.trim(),
        startDate: startDate || undefined,
        endDate: endDate || undefined,
      });
      setBills(data);
    } catch (err) {
      console.error('Failed to load bills:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadBills();
  }, [search, startDate, endDate]);

  const handleClearDates = () => {
    setStartDate('');
    setEndDate('');
  };

  const handleReprint = async (billId: number) => {
    try {
      const bill = await ipcClient.getBillById(billId);
      if (!bill) return;

      const settings = await ipcClient.getSettings();

      const receipt: PrintableReceiptData = {
        title: 'BILL (REPRINT)',
        documentNumber: bill.bill_number,
        date: new Date(bill.created_at).toLocaleDateString(),
        time: new Date(bill.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        customerName: bill.customer_name,
        customerMobile: bill.customer_mobile,
        items: (bill.items || []).map((i) => ({
          name: i.product_name,
          quantity: i.quantity,
          rate: i.rate,
          amount: i.amount,
        })),
        subtotal: bill.subtotal,
        discount: bill.discount,
        total: bill.total_amount,
        paymentMethod: bill.payment_method,
        cashTendered: bill.cash_tendered,
        changeDue: bill.change_due,
        splitDetails: bill.split_details,
        settings,
      };

      setActiveReceipt(receipt);
    } catch (err: any) {
      alert(`Error reprinting bill: ${err?.message}`);
    }
  };

  const handleDeleteBill = async () => {
    if (!deleteConfirmBill) return;

    try {
      setIsDeleting(true);
      const res = await ipcClient.deleteBill(deleteConfirmBill.id, restoreStockOnDelete);
      alert(`Bill #${res.billNumber} deleted successfully.${restoreStockOnDelete ? ' Stock was restored.' : ''}`);
      setDeleteConfirmBill(null);
      await loadBills();
    } catch (err: any) {
      alert(`Failed to delete bill: ${err?.message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div
      id="bill-history-container"
      className={`p-6 space-y-6 max-w-7xl mx-auto transition-colors duration-200 ${
        isLight ? 'text-slate-800' : 'text-slate-100'
      }`}
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2
            className={`text-xl font-bold tracking-tight flex items-center gap-2 ${
              isLight ? 'text-slate-900' : 'text-white'
            }`}
          >
            <History className="w-6 h-6 text-blue-500" />
            <span>{t.billHistory}</span>
          </h2>
          <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
            Historical transaction archives stored securely in offline SQLite database
          </p>
        </div>

        <div
          className={`flex items-center gap-2 px-4 py-2 rounded-xl border text-xs transition-colors ${
            isLight
              ? 'bg-white border-slate-200 text-slate-600 shadow-xs'
              : 'bg-slate-900 border-slate-800 text-slate-400'
          }`}
        >
          <span>Total Records:</span>
          <span className={`font-bold font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
            {bills.length}
          </span>
        </div>
      </div>

      {/* Filter bar: Search + Start Date & End Date */}
      <div
        className={`p-4 rounded-xl border space-y-3 transition-colors ${
          isLight
            ? 'bg-white border-slate-200 shadow-xs'
            : 'bg-slate-900 border-slate-800'
        }`}
      >
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by Bill # (e.g. BILL-2026), customer name, or mobile number..."
            className={`w-full pl-10 pr-4 py-2 rounded-lg text-xs outline-none border transition-colors ${
              isLight
                ? 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400 focus:border-blue-600 focus:bg-white'
                : 'bg-slate-950 border-slate-700 text-slate-100 placeholder-slate-500 focus:border-blue-500'
            }`}
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-1">
          <div className={`flex items-center gap-2 text-xs ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
            <Calendar className="w-4 h-4 text-blue-500" />
            <span>Date Range:</span>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              title="Start Date"
              className={`px-2.5 py-1.5 rounded-lg text-xs outline-none border transition-colors ${
                isLight
                  ? 'bg-white border-slate-300 text-slate-800 focus:border-blue-600'
                  : 'bg-slate-950 border-slate-700 text-slate-200 focus:border-blue-500'
              }`}
            />
            <span className={`text-xs ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              title="End Date"
              className={`px-2.5 py-1.5 rounded-lg text-xs outline-none border transition-colors ${
                isLight
                  ? 'bg-white border-slate-300 text-slate-800 focus:border-blue-600'
                  : 'bg-slate-950 border-slate-700 text-slate-200 focus:border-blue-500'
              }`}
            />
          </div>

          {(startDate || endDate) && (
            <button
              onClick={handleClearDates}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs cursor-pointer transition-colors border ${
                isLight
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
              }`}
            >
              <X className="w-3.5 h-3.5" />
              <span>Clear Dates</span>
            </button>
          )}
        </div>
      </div>

      {/* Bills Table */}
      <div
        className={`border rounded-xl overflow-hidden transition-colors ${
          isLight
            ? 'border-slate-200 bg-white shadow-xs'
            : 'border-slate-800 bg-slate-900 shadow-xl'
        }`}
      >
        <table className="w-full text-left text-xs border-collapse">
          <thead
            className={`uppercase tracking-wider border-b font-medium ${
              isLight
                ? 'bg-slate-50 text-slate-600 border-slate-200'
                : 'bg-slate-950 text-slate-400 border-slate-800'
            }`}
          >
            <tr>
              <th className="p-3.5">Bill #</th>
              <th className="p-3.5">Date & Time</th>
              <th className="p-3.5">Customer</th>
              <th className="p-3.5">Payment</th>
              <th className="p-3.5 text-right">Subtotal (₹)</th>
              <th className="p-3.5 text-right">Discount (₹)</th>
              <th className="p-3.5 text-right">Total Net (₹)</th>
              <th className="p-3.5 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className={`divide-y ${isLight ? 'divide-slate-100' : 'divide-slate-800'}`}>
            {isLoading ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-slate-400">
                  Loading SQLite bill records...
                </td>
              </tr>
            ) : bills.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-slate-400">
                  No bills found matching your criteria.
                </td>
              </tr>
            ) : (
              bills.map((b) => (
                <tr
                  key={b.id}
                  className={`transition-colors ${
                    isLight ? 'hover:bg-slate-50 text-slate-800' : 'hover:bg-slate-800/40 text-slate-200'
                  }`}
                >
                  <td className="p-3.5 font-mono font-semibold text-blue-600 dark:text-blue-400">
                    #{b.bill_number}
                  </td>
                  <td className={`p-3.5 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                    {new Date(b.created_at).toLocaleString()}
                  </td>
                  <td className="p-3.5">
                    <div className={`font-medium ${isLight ? 'text-slate-900' : 'text-slate-200'}`}>
                      {b.customer_name || 'Walk-in'}
                    </div>
                    {b.customer_mobile && (
                      <div className={`text-[10px] font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                        {b.customer_mobile}
                      </div>
                    )}
                  </td>
                  <td className="p-3.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] font-mono border ${
                        isLight
                          ? 'bg-slate-100 text-slate-700 border-slate-200'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}
                    >
                      {b.payment_method}
                    </span>
                  </td>
                  <td className={`p-3.5 text-right font-mono ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                    ₹{b.subtotal.toFixed(2)}
                  </td>
                  <td className={`p-3.5 text-right font-mono ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                    {b.discount > 0 ? `₹${b.discount.toFixed(2)}` : '—'}
                  </td>
                  <td className="p-3.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    ₹{b.total_amount.toFixed(2)}
                  </td>
                  <td className="p-3.5 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => handleReprint(b.id)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer transition-colors ${
                          isLight
                            ? 'bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border-slate-700'
                        }`}
                        title="Reprint Thermal Receipt"
                      >
                        <Printer className="w-3.5 h-3.5 text-blue-500" />
                        <span>{t.reprint}</span>
                      </button>
                      <button
                        onClick={() => setDeleteConfirmBill(b)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer transition-colors ${
                          isLight
                            ? 'bg-red-50 hover:bg-red-100 text-red-700 border-red-200'
                            : 'bg-red-950/40 hover:bg-red-900/60 text-red-400 hover:text-red-300 border-red-800/60'
                        }`}
                        title="Delete Bill"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Delete Single Bill Confirmation Modal */}
      {deleteConfirmBill && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`border rounded-2xl max-w-md w-full shadow-2xl p-6 space-y-4 ${
              isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-slate-900 border-slate-700 text-white'
            }`}
          >
            <div className="flex items-center gap-3 text-red-500">
              <AlertCircle className="w-6 h-6 shrink-0" />
              <h3 className={`text-base font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                Delete Bill #{deleteConfirmBill.bill_number}?
              </h3>
            </div>

            <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-300'}`}>
              Are you sure you want to delete this bill for{' '}
              <strong className={isLight ? 'text-slate-900' : 'text-white'}>
                ₹{deleteConfirmBill.total_amount.toFixed(2)}
              </strong>
              ? Associated payment and line item records will be removed.
            </p>

            <div
              className={`p-3 rounded-xl border ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950 border-slate-800'
              }`}
            >
              <label
                className={`flex items-center gap-2.5 cursor-pointer text-xs ${
                  isLight ? 'text-slate-700' : 'text-slate-200'
                }`}
              >
                <input
                  type="checkbox"
                  checked={restoreStockOnDelete}
                  onChange={(e) => setRestoreStockOnDelete(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600 w-4 h-4"
                />
                <span>Restore product stock inventory levels automatically</span>
              </label>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmBill(null)}
                disabled={isDeleting}
                className={`px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer ${
                  isLight ? 'text-slate-600 hover:bg-slate-100' : 'text-slate-400 hover:bg-slate-800'
                }`}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteBill}
                disabled={isDeleting}
                className="px-5 py-2 rounded-lg bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-xs font-bold cursor-pointer transition-colors shadow-md"
              >
                {isDeleting ? 'Deleting...' : 'Delete Bill'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Thermal Receipt Preview Modal */}
      {activeReceipt && (
        <ReceiptModal
          receiptData={activeReceipt}
          currentLang={currentLang}
          onClose={() => setActiveReceipt(null)}
        />
      )}
    </div>
  );
};
