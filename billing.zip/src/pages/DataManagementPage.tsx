import React, { useState } from 'react';
import {
  Trash2,
  AlertTriangle,
  Calculator,
  ShieldAlert,
  CheckCircle2,
  Calendar,
  Layers,
  FileSpreadsheet,
  Receipt,
  RotateCcw,
} from 'lucide-react';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { DataManagementImpact } from '../types';

interface DataManagementPageProps {
  currentLang: Language;
}

export const DataManagementPage: React.FC<DataManagementPageProps> = ({ currentLang }) => {
  const todayStr = new Date().toISOString().slice(0, 10);
  const [startDate, setStartDate] = useState(todayStr);
  const [endDate, setEndDate] = useState(todayStr);
  const [includeEstimatesAndInvoices, setIncludeEstimatesAndInvoices] = useState(false);

  const [impact, setImpact] = useState<DataManagementImpact | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [isPurging, setIsPurging] = useState(false);
  const [resultMsg, setResultMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const t = translations[currentLang];

  const setDatePreset = (preset: 'today' | 'yesterday' | '7days' | '30days' | 'thisMonth' | 'allTime') => {
    const today = new Date();
    setImpact(null);
    setResultMsg(null);

    if (preset === 'today') {
      const s = today.toISOString().slice(0, 10);
      setStartDate(s);
      setEndDate(s);
    } else if (preset === 'yesterday') {
      const y = new Date(today);
      y.setDate(y.getDate() - 1);
      const s = y.toISOString().slice(0, 10);
      setStartDate(s);
      setEndDate(s);
    } else if (preset === '7days') {
      const p = new Date(today);
      p.setDate(p.getDate() - 6);
      setStartDate(p.toISOString().slice(0, 10));
      setEndDate(today.toISOString().slice(0, 10));
    } else if (preset === '30days') {
      const p = new Date(today);
      p.setDate(p.getDate() - 29);
      setStartDate(p.toISOString().slice(0, 10));
      setEndDate(today.toISOString().slice(0, 10));
    } else if (preset === 'thisMonth') {
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
      setStartDate(firstDay.toISOString().slice(0, 10));
      setEndDate(today.toISOString().slice(0, 10));
    } else if (preset === 'allTime') {
      setStartDate('2020-01-01');
      setEndDate(today.toISOString().slice(0, 10));
    }
  };

  const handleCalculateImpact = async () => {
    if (!startDate || !endDate) {
      alert('Please select both Start Date and End Date');
      return;
    }

    if (startDate > endDate) {
      alert('Start Date cannot be after End Date');
      return;
    }

    try {
      setIsCalculating(true);
      setResultMsg(null);
      const data = await ipcClient.calculateDataImpact(startDate, endDate);
      setImpact(data);
    } catch (err: any) {
      alert(`Impact calculation error: ${err?.message}`);
    } finally {
      setIsCalculating(false);
    }
  };

  const handleConfirmPurge = async () => {
    if (!startDate || !endDate || !impact) return;

    if (impact.billCount === 0 && (!includeEstimatesAndInvoices || (impact.estimateCount === 0 && impact.invoiceCount === 0))) {
      alert('No records found in the selected date range to delete.');
      return;
    }

    const confirm1 = window.confirm(
      `DANGER: You are about to permanently delete:\n` +
      `• ${impact.billCount} Bills\n` +
      `• ${impact.paymentCount} Payment Records\n` +
      `• ₹${impact.totalSales.toFixed(2)} Total Sales Value\n` +
      (includeEstimatesAndInvoices ? `• ${impact.estimateCount} Estimates & ${impact.invoiceCount} Invoices\n` : '') +
      `between ${startDate} and ${endDate}.\n\n` +
      `Have you taken a recent SQLite backup from Backup & Restore?`
    );

    if (!confirm1) return;

    const confirm2 = window.prompt(
      'Type "PURGE-CONFIRM" in capital letters to verify this irreversible action:'
    );

    if (confirm2 !== 'PURGE-CONFIRM') {
      alert('Purge aborted. Confirmation text did not match.');
      return;
    }

    try {
      setIsPurging(true);
      const res = await ipcClient.purgeDataRange(startDate, endDate, includeEstimatesAndInvoices);
      setResultMsg({
        type: 'success',
        text: `Data successfully purged between ${startDate} and ${endDate}! Deleted ${res.deletedBills} bills, ${res.deletedInvoices || 0} invoices, and ${res.deletedEstimates || 0} estimates.`,
      });
      setImpact(null);
    } catch (err: any) {
      setResultMsg({
        type: 'error',
        text: `Purge aborted and rolled back safely: ${err?.message}`,
      });
    } finally {
      setIsPurging(false);
    }
  };

  return (
    <div id="data-management-container" className="p-6 space-y-6 max-w-3xl mx-auto">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
          <Trash2 className="w-6 h-6 text-red-400" />
          <span>{t.dataPurgeTitle}</span>
        </h2>
        <p className="text-xs text-slate-400">
          Delete bills, payments, estimates, and invoices by selecting a custom Start Date and End Date range.
        </p>
      </div>

      {/* Backup Warning */}
      <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-800 text-amber-300 text-xs flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold text-sm">Backup Requirement Reminder</p>
          <p className="text-amber-400/90 text-xs leading-relaxed">
            Permanent deletion cannot be undone once executed on SQLite. Always download a fresh backup via the "Backup & Restore" module before deleting data.
          </p>
        </div>
      </div>

      {resultMsg && (
        <div
          className={`p-4 rounded-xl border text-xs flex items-center gap-2 ${
            resultMsg.type === 'success'
              ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
              : 'bg-red-950/60 border-red-800 text-red-300'
          }`}
        >
          {resultMsg.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          ) : (
            <ShieldAlert className="w-5 h-5 text-red-400 shrink-0" />
          )}
          <span>{resultMsg.text}</span>
        </div>
      )}

      {/* Date selector & calculation card */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-5 shadow-xl">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-blue-400" />
            <span>Select Date Range to Delete (தொடக்க & முடிவு தேதி)</span>
          </h3>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <span className="text-[11px] text-slate-400 mr-1">Quick Range:</span>
          {[
            { id: 'today', label: 'Today' },
            { id: 'yesterday', label: 'Yesterday' },
            { id: '7days', label: 'Last 7 Days' },
            { id: '30days', label: 'Last 30 Days' },
            { id: 'thisMonth', label: 'This Month' },
            { id: 'allTime', label: 'All Time' },
          ].map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => setDatePreset(preset.id as any)}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition-colors cursor-pointer border border-slate-700/60"
            >
              {preset.label}
            </button>
          ))}
        </div>

        {/* Start Date & End Date Inputs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-950/70 p-4 rounded-xl border border-slate-800">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Start Date (தொடக்க தேதி)
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setImpact(null);
              }}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white focus:outline-hidden focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              End Date (முடிவு தேதி)
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => {
                setEndDate(e.target.value);
                setImpact(null);
              }}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white focus:outline-hidden focus:border-blue-500"
            />
          </div>
        </div>

        {/* Options */}
        <div className="space-y-2 pt-1">
          <label className="flex items-center gap-2.5 cursor-pointer text-xs text-slate-300">
            <input
              type="checkbox"
              checked={includeEstimatesAndInvoices}
              onChange={(e) => {
                setIncludeEstimatesAndInvoices(e.target.checked);
                setImpact(null);
              }}
              className="rounded border-slate-700 bg-slate-950 text-blue-500 w-4 h-4"
            />
            <span>Also delete Estimates and Invoices in this date range (மதிப்பீடு & விலைப்பட்டியல்களையும் நீக்கு)</span>
          </label>
          <p className="text-[11px] text-slate-500 pl-6.5">
            Products inventory catalog and category classifications will remain completely untouched.
          </p>
        </div>

        {/* Calculate Impact Button */}
        <div className="pt-2">
          <button
            onClick={handleCalculateImpact}
            disabled={!startDate || !endDate || isCalculating}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer shadow-md transition-colors"
          >
            <Calculator className="w-4 h-4" />
            <span>{isCalculating ? 'Auditing SQLite Database...' : 'Preview Delete Impact (விளைவைச் சரிபார்க்க)'}</span>
          </button>
        </div>
      </div>

      {/* Impact results display */}
      {impact && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-red-900/60 space-y-5 shadow-2xl">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-red-400" />
              <span>Impact Analysis: {startDate} to {endDate}</span>
            </h3>
            <span className="text-[11px] bg-red-950 text-red-400 border border-red-800 px-2 py-0.5 rounded font-mono">
              PERMANENT DELETION
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <p className="text-[11px] text-slate-400 mb-1">Bills to Delete</p>
              <p className="text-xl font-bold font-mono text-red-400">{impact.billCount}</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <p className="text-[11px] text-slate-400 mb-1">Total Sales (₹)</p>
              <p className="text-xl font-bold font-mono text-emerald-400">
                ₹{impact.totalSales.toFixed(2)}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <p className="text-[11px] text-slate-400 mb-1">Payments</p>
              <p className="text-xl font-bold font-mono text-amber-400">{impact.paymentCount}</p>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <p className="text-[11px] text-slate-400 mb-1">Estimates & Invoices</p>
              <p className="text-xl font-bold font-mono text-cyan-400">
                {includeEstimatesAndInvoices ? impact.estimateCount + impact.invoiceCount : 'Excluded'}
              </p>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={handleConfirmPurge}
              disabled={isPurging}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-xs font-bold shadow-lg shadow-red-950/50 cursor-pointer transition-colors"
            >
              <Trash2 className="w-4 h-4" />
              <span>
                {isPurging
                  ? 'Purging Records in SQLite...'
                  : `Permanently Delete Data Between ${startDate} and ${endDate}`}
              </span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
