import React, { useState, useEffect } from 'react';
import {
  Boxes,
  PlusCircle,
  SlidersHorizontal,
  History,
  AlertTriangle,
  Search,
  CheckCircle2,
} from 'lucide-react';
import { Product, StockTransaction } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { useTheme } from '../context/ThemeContext';

interface StockPageProps {
  currentLang: Language;
}

export const StockPage: React.FC<StockPageProps> = ({ currentLang }) => {
  const { isLight } = useTheme();
  const [activeSubTab, setActiveSubTab] = useState<'inventory' | 'history'>('inventory');
  const [products, setProducts] = useState<Product[]>([]);
  const [history, setHistory] = useState<StockTransaction[]>([]);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Stock action modal
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [actionType, setActionType] = useState<'INWARD' | 'ADJUSTMENT'>('INWARD');
  const [qtyChange, setQtyChange] = useState('');
  const [reasonNotes, setReasonNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const t = translations[currentLang];

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [prods, txs] = await Promise.all([
        ipcClient.getProducts(),
        ipcClient.getStockTransactions(),
      ]);
      setProducts(prods);
      setHistory(txs);
    } catch (err) {
      console.error('Failed to load stock data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleStockUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;
    const qty = parseInt(qtyChange, 10);
    if (isNaN(qty) || qty === 0) {
      alert('Please enter a non-zero quantity change');
      return;
    }

    try {
      setIsSubmitting(true);
      await ipcClient.recordStockAdjustment({
        productId: selectedProduct.id,
        quantityChange: actionType === 'INWARD' ? Math.abs(qty) : qty,
        type: actionType,
        notes: reasonNotes.trim() || undefined,
      });

      setFeedback(
        `Successfully recorded ${actionType.toLowerCase()} for '${selectedProduct.name}'`
      );
      setSelectedProduct(null);
      setQtyChange('');
      setReasonNotes('');
      loadData();
    } catch (err: any) {
      alert(`Stock update failed: ${err?.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.barcode.toLowerCase().includes(search.toLowerCase())
  );

  const lowStockItems = products.filter((p) => p.current_stock <= p.min_stock_level);

  return (
    <div
      id="stock-page-container"
      className={`p-6 space-y-6 max-w-7xl mx-auto transition-colors duration-200 ${
        isLight ? 'text-slate-800' : 'text-slate-100'
      }`}
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2
            className={`text-xl font-bold tracking-tight flex items-center gap-2 ${
              isLight ? 'text-slate-900' : 'text-white'
            }`}
          >
            <Boxes className="w-6 h-6 text-blue-500" />
            <span>{t.stock}</span>
          </h2>
          <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
            Real-time SQLite inventory balances, stock inward entries, and audit trail logs
          </p>
        </div>

        {/* Subtab switcher */}
        <div
          className={`flex border rounded-xl p-1 text-xs transition-colors ${
            isLight
              ? 'bg-white border-slate-200 shadow-xs'
              : 'bg-slate-900 border-slate-800'
          }`}
        >
          <button
            onClick={() => setActiveSubTab('inventory')}
            className={`px-4 py-1.5 rounded-lg font-medium cursor-pointer transition-colors ${
              activeSubTab === 'inventory'
                ? 'bg-blue-600 text-white shadow-xs'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            Inventory Balances ({products.length})
          </button>
          <button
            onClick={() => setActiveSubTab('history')}
            className={`px-4 py-1.5 rounded-lg font-medium cursor-pointer transition-colors ${
              activeSubTab === 'history'
                ? 'bg-blue-600 text-white shadow-xs'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            {t.transactionHistory} ({history.length})
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-3 rounded-lg border text-xs flex items-center justify-between transition-colors ${
            isLight
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
          }`}
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{feedback}</span>
          </div>
          <button
            onClick={() => setFeedback(null)}
            className={`cursor-pointer ${isLight ? 'text-slate-400 hover:text-slate-700' : 'text-slate-400 hover:text-white'}`}
          >
            ✕
          </button>
        </div>
      )}

      {/* Low Stock Warning Banner if any */}
      {lowStockItems.length > 0 && activeSubTab === 'inventory' && (
        <div
          className={`p-4 rounded-xl border text-xs flex items-start gap-3 transition-colors ${
            isLight
              ? 'bg-amber-50 border-amber-200 text-amber-900 shadow-xs'
              : 'bg-amber-950/40 border-amber-800/80 text-amber-300'
          }`}
        >
          <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold text-sm">
              {lowStockItems.length} product(s) have reached or fallen below minimum stock thresholds!
            </p>
            <p className={`text-xs ${isLight ? 'text-amber-800' : 'text-amber-400/90'}`}>
              Items:{' '}
              {lowStockItems
                .slice(0, 5)
                .map((p) => `${p.name} (${p.current_stock} left)`)
                .join(', ')}
              {lowStockItems.length > 5 && ` and ${lowStockItems.length - 5} more.`}
            </p>
          </div>
        </div>
      )}

      {activeSubTab === 'inventory' ? (
        <div className="space-y-4">
          {/* Search bar */}
          <div
            className={`relative p-3 rounded-xl border transition-colors ${
              isLight
                ? 'bg-white border-slate-200 shadow-xs'
                : 'bg-slate-900 border-slate-800'
            }`}
          >
            <Search className="w-4 h-4 absolute left-6 top-5.5 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search inventory by product name or barcode..."
              className={`w-full pl-10 pr-4 py-2 rounded-lg text-xs outline-none border transition-colors ${
                isLight
                  ? 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400 focus:border-blue-600 focus:bg-white'
                  : 'bg-slate-950 border-slate-700 text-slate-100 placeholder-slate-500 focus:border-blue-500'
              }`}
            />
          </div>

          {/* Table */}
          <div
            className={`border rounded-xl overflow-hidden transition-colors ${
              isLight
                ? 'border-slate-200 bg-white shadow-xs'
                : 'border-slate-800 bg-slate-900 shadow-xl'
            }`}
          >
            <table className="w-full text-left text-xs border-collapse">
              <thead
                className={`uppercase tracking-wider border-b font-medium ${
                  isLight
                    ? 'bg-slate-50 text-slate-600 border-slate-200'
                    : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                <tr>
                  <th className="p-3.5">#</th>
                  <th className="p-3.5">Product Name</th>
                  <th className="p-3.5">Barcode</th>
                  <th className="p-3.5 text-center">Opening Stock</th>
                  <th className="p-3.5 text-center">Current Stock</th>
                  <th className="p-3.5 text-center">Min Level</th>
                  <th className="p-3.5 text-center">Quick Adjust</th>
                </tr>
              </thead>
              <tbody className={`divide-y ${isLight ? 'divide-slate-100' : 'divide-slate-800'}`}>
                {isLoading ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400">
                      Loading inventory levels...
                    </td>
                  </tr>
                ) : filteredProducts.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400">
                      No products found.
                    </td>
                  </tr>
                ) : (
                  filteredProducts.map((p, idx) => {
                    const isLow = p.current_stock <= p.min_stock_level;
                    return (
                      <tr
                        key={p.id}
                        className={`transition-colors ${
                          isLight ? 'hover:bg-slate-50 text-slate-800' : 'hover:bg-slate-800/40 text-slate-200'
                        }`}
                      >
                        <td className={`p-3.5 font-mono ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>{idx + 1}</td>
                        <td className={`p-3.5 font-medium ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>{p.name}</td>
                        <td className={`p-3.5 font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>{p.barcode}</td>
                        <td className={`p-3.5 text-center font-mono ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                          {p.opening_stock}
                        </td>
                        <td className="p-3.5 text-center font-bold font-mono">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                              isLow
                                ? isLight
                                  ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                  : 'bg-amber-950 text-amber-300 border border-amber-800'
                                : isLight
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                : 'bg-emerald-950/60 text-emerald-300'
                            }`}
                          >
                            {isLow && <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />}
                            {p.current_stock}
                          </span>
                        </td>
                        <td className={`p-3.5 text-center font-mono ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                          {p.min_stock_level}
                        </td>
                        <td className="p-3.5 text-center">
                          <div className="flex items-center justify-center gap-2">
                            <button
                              onClick={() => {
                                setSelectedProduct(p);
                                setActionType('INWARD');
                                setQtyChange('');
                              }}
                              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] font-semibold cursor-pointer transition-colors ${
                                isLight
                                  ? 'bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-700'
                                  : 'bg-emerald-950/70 hover:bg-emerald-900 border-emerald-800 text-emerald-300'
                              }`}
                              title="Stock Inward (+)"
                            >
                              <PlusCircle className="w-3.5 h-3.5" />
                              <span>{t.stockInward}</span>
                            </button>
                            <button
                              onClick={() => {
                                setSelectedProduct(p);
                                setActionType('ADJUSTMENT');
                                setQtyChange('');
                              }}
                              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] font-semibold cursor-pointer transition-colors ${
                                isLight
                                  ? 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                                  : 'bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300'
                              }`}
                              title="Manual Adjustment (±)"
                            >
                              <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-500" />
                              <span>{t.stockAdjustment}</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Stock Movement History Table */
        <div
          className={`border rounded-xl overflow-hidden transition-colors ${
            isLight
              ? 'border-slate-200 bg-white shadow-xs'
              : 'border-slate-800 bg-slate-900 shadow-xl'
          }`}
        >
          <table className="w-full text-left text-xs border-collapse">
            <thead
              className={`uppercase tracking-wider border-b font-medium ${
                isLight
                  ? 'bg-slate-50 text-slate-600 border-slate-200'
                  : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
            >
              <tr>
                <th className="p-3.5">#</th>
                <th className="p-3.5">Product</th>
                <th className="p-3.5">Movement Type</th>
                <th className="p-3.5 text-center">Change (±)</th>
                <th className="p-3.5 text-center">Previous</th>
                <th className="p-3.5 text-center">New Stock</th>
                <th className="p-3.5">Reference / Reason Notes</th>
                <th className="p-3.5">Date & Time</th>
              </tr>
            </thead>
            <tbody className={`divide-y ${isLight ? 'divide-slate-100' : 'divide-slate-800'}`}>
              {history.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    No stock transactions recorded yet. Sales, inward additions, and manual adjustments are logged automatically.
                  </td>
                </tr>
              ) : (
                history.map((tx, idx) => (
                  <tr
                    key={tx.id}
                    className={`transition-colors ${
                      isLight ? 'hover:bg-slate-50 text-slate-800' : 'hover:bg-slate-800/40 text-slate-200'
                    }`}
                  >
                    <td className={`p-3.5 font-mono ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>{idx + 1}</td>
                    <td className={`p-3.5 font-medium ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>{tx.product_name}</td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase font-semibold border ${
                          tx.type === 'SALE' || tx.type === 'INVOICE'
                            ? isLight
                              ? 'bg-red-50 text-red-700 border-red-200'
                              : 'bg-red-950/60 text-red-400 border-red-800/70'
                            : tx.type === 'INWARD'
                            ? isLight
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-emerald-950/60 text-emerald-400 border-emerald-800/70'
                            : isLight
                            ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                            : 'bg-indigo-950/60 text-indigo-400 border-indigo-800/70'
                        }`}
                      >
                        {tx.type}
                      </span>
                    </td>
                    <td
                      className={`p-3.5 text-center font-bold font-mono ${
                        tx.quantity_change > 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'
                      }`}
                    >
                      {tx.quantity_change > 0 ? `+${tx.quantity_change}` : tx.quantity_change}
                    </td>
                    <td className={`p-3.5 text-center font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      {tx.previous_stock}
                    </td>
                    <td className={`p-3.5 text-center font-mono font-semibold ${isLight ? 'text-slate-900' : 'text-slate-200'}`}>
                      {tx.new_stock}
                    </td>
                    <td className={`p-3.5 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>{tx.notes || '—'}</td>
                    <td className={`p-3.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                      {new Date(tx.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Stock Inward / Adjustment Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`border rounded-2xl max-w-md w-full shadow-2xl overflow-hidden transition-colors ${
              isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-slate-900 border-slate-700 text-slate-100'
            }`}
          >
            <div
              className={`flex items-center justify-between px-5 py-4 border-b ${
                isLight ? 'border-slate-100' : 'border-slate-800'
              }`}
            >
              <h3 className={`text-sm font-bold ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
                {actionType === 'INWARD' ? t.stockInward : t.stockAdjustment}
              </h3>
              <button
                onClick={() => setSelectedProduct(null)}
                className={`cursor-pointer ${isLight ? 'text-slate-400 hover:text-slate-700' : 'text-slate-400 hover:text-white'}`}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleStockUpdate} className="p-5 space-y-4">
              <div
                className={`p-3.5 rounded-xl border space-y-1 ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-950 border-slate-800'
                }`}
              >
                <p className={`text-xs font-bold ${isLight ? 'text-slate-900' : 'text-white'}`}>
                  {selectedProduct.name}
                </p>
                <div className={`flex justify-between text-[11px] font-mono ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                  <span>Barcode: {selectedProduct.barcode}</span>
                  <span>Current Stock: <strong className={isLight ? 'text-slate-900' : 'text-white'}>{selectedProduct.current_stock}</strong></span>
                </div>
              </div>

              <div>
                <label className={`block text-xs font-medium mb-1.5 ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  {actionType === 'INWARD'
                    ? 'Quantity to Add (+)'
                    : 'Quantity Change (Enter positive to add, negative to deduct)'}
                </label>
                <input
                  type="number"
                  required
                  autoFocus
                  value={qtyChange}
                  onChange={(e) => setQtyChange(e.target.value)}
                  placeholder={actionType === 'INWARD' ? 'e.g. 50' : 'e.g. -5 or 10'}
                  className={`w-full px-3 py-2 rounded-lg text-sm font-mono outline-none border transition-colors ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400 focus:border-blue-600 focus:bg-white'
                      : 'bg-slate-950 border-slate-700 text-white placeholder-slate-500 focus:border-blue-500'
                  }`}
                />
              </div>

              <div>
                <label className={`block text-xs font-medium mb-1.5 ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                  {t.reasonNotes}
                </label>
                <input
                  type="text"
                  value={reasonNotes}
                  onChange={(e) => setReasonNotes(e.target.value)}
                  placeholder="e.g. Supplier delivery PO-448, damaged box write-off..."
                  className={`w-full px-3 py-2 rounded-lg text-xs outline-none border transition-colors ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400 focus:border-blue-600 focus:bg-white'
                      : 'bg-slate-950 border-slate-700 text-white placeholder-slate-500 focus:border-blue-500'
                  }`}
                />
              </div>

              <div className={`flex justify-end gap-2 pt-3 border-t ${isLight ? 'border-slate-100' : 'border-slate-800'}`}>
                <button
                  type="button"
                  onClick={() => setSelectedProduct(null)}
                  className={`px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer ${
                    isLight ? 'text-slate-600 hover:bg-slate-100' : 'text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-bold cursor-pointer shadow-md transition-colors"
                >
                  {isSubmitting ? 'Updating...' : t.saveStock}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
