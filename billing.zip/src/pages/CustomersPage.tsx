import React, { useState, useEffect } from 'react';
import { Users, Search, Phone, MapPin, Receipt, Wallet } from 'lucide-react';
import { Customer } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { useTheme } from '../context/ThemeContext';

interface CustomersPageProps {
  currentLang: Language;
}

export const CustomersPage: React.FC<CustomersPageProps> = ({ currentLang }) => {
  const { isLight } = useTheme();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const t = translations[currentLang];

  const loadCustomers = async () => {
    try {
      setIsLoading(true);
      const data = await ipcClient.getCustomers(search);
      setCustomers(data);
    } catch (err) {
      console.error('Failed to load customers:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, [search]);

  return (
    <div
      id="customers-page-container"
      className={`p-6 space-y-6 max-w-7xl mx-auto transition-colors duration-200 ${
        isLight ? 'text-slate-800' : 'text-slate-100'
      }`}
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2
            className={`text-xl font-bold tracking-tight flex items-center gap-2 ${
              isLight ? 'text-slate-900' : 'text-white'
            }`}
          >
            <Users className="w-6 h-6 text-blue-500" />
            <span>{t.customers}</span>
          </h2>
          <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
            Local customer ledger tracking spending and transaction frequency
          </p>
        </div>

        <div
          className={`flex items-center gap-2 px-4 py-2 rounded-xl border text-xs transition-colors ${
            isLight
              ? 'bg-white border-slate-200 text-slate-600 shadow-xs'
              : 'bg-slate-900 border-slate-800 text-slate-400'
          }`}
        >
          <span>Registered Customers:</span>
          <span className={`font-bold font-mono ${isLight ? 'text-slate-900' : 'text-white'}`}>
            {customers.length}
          </span>
        </div>
      </div>

      {/* Search Input */}
      <div
        className={`relative p-3 rounded-xl border transition-colors ${
          isLight
            ? 'bg-white border-slate-200 shadow-xs'
            : 'bg-slate-900 border-slate-800'
        }`}
      >
        <Search className={`w-4 h-4 absolute left-6 top-5.5 ${isLight ? 'text-slate-400' : 'text-slate-400'}`} />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={t.searchCustomers}
          className={`w-full pl-10 pr-4 py-2 rounded-lg text-xs outline-none border transition-colors ${
            isLight
              ? 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-400 focus:border-blue-600 focus:bg-white'
              : 'bg-slate-950 border-slate-700 text-slate-100 placeholder-slate-500 focus:border-blue-500'
          }`}
        />
      </div>

      {/* Customers Table */}
      <div
        className={`border rounded-xl overflow-hidden transition-colors ${
          isLight
            ? 'border-slate-200 bg-white shadow-xs'
            : 'border-slate-800 bg-slate-900 shadow-xl'
        }`}
      >
        <table className="w-full text-left text-xs border-collapse">
          <thead
            className={`uppercase tracking-wider border-b font-medium ${
              isLight
                ? 'bg-slate-50 text-slate-600 border-slate-200'
                : 'bg-slate-950 text-slate-400 border-slate-800'
            }`}
          >
            <tr>
              <th className="p-3.5">#</th>
              <th className="p-3.5">{t.customerName}</th>
              <th className="p-3.5">{t.customerMobile}</th>
              <th className="p-3.5">{t.customerAddress}</th>
              <th className="p-3.5 text-center">{t.billsCount}</th>
              <th className="p-3.5 text-right">{t.totalSpent} (₹)</th>
            </tr>
          </thead>
          <tbody className={`divide-y ${isLight ? 'divide-slate-100' : 'divide-slate-800'}`}>
            {isLoading ? (
              <tr>
                <td colSpan={6} className="p-8 text-center text-slate-400">
                  Loading SQLite customer directory...
                </td>
              </tr>
            ) : customers.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-8 text-center text-slate-400">
                  No registered customers yet. Enter customer names or mobile numbers during POS billing to register them automatically.
                </td>
              </tr>
            ) : (
              customers.map((c, idx) => (
                <tr
                  key={c.id}
                  className={`transition-colors ${
                    isLight ? 'hover:bg-slate-50 text-slate-800' : 'hover:bg-slate-800/40 text-slate-200'
                  }`}
                >
                  <td className={`p-3.5 font-mono ${isLight ? 'text-slate-400' : 'text-slate-500'}`}>{idx + 1}</td>
                  <td className={`p-3.5 font-semibold ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>{c.name}</td>
                  <td className={`p-3.5 font-mono ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>{c.mobile || '—'}</td>
                  <td className={`p-3.5 truncate max-w-xs ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>{c.address || '—'}</td>
                  <td className="p-3.5 text-center">
                    <span
                      className={`px-2 py-0.5 rounded-full font-mono text-xs border ${
                        isLight
                          ? 'bg-slate-100 text-slate-700 border-slate-200'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}
                    >
                      {c.bills_count || 0}
                    </span>
                  </td>
                  <td className="p-3.5 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    ₹{(c.total_spent || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
