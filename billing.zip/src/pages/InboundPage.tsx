import React, { useState, useEffect, useRef } from 'react';
import {
  Truck,
  Plus,
  Trash2,
  Search,
  Printer,
  CheckCircle2,
  Calendar,
  DollarSign,
  Package,
  QrCode,
  FileText,
  Boxes,
  ArrowRight,
  RefreshCw,
  Phone,
  User,
  AlertTriangle,
  History,
  Eye,
  X,
} from 'lucide-react';
import { Product, Category, InboundReceipt, InboundItem, AppSettings } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { useTheme } from '../context/ThemeContext';
import { playScanBeep } from '../utils/barcode';

interface InboundPageProps {
  currentLang: Language;
  onNavigateToBarcode?: (productId?: number) => void;
}

interface InboundFormRow {
  productId: number;
  productName: string;
  barcode: string;
  batchNo: string;
  expiryDate: string;
  quantity: number;
  purchaseRate: number;
  sellingRate: number;
  amount: number;
}

export const InboundPage: React.FC<InboundPageProps> = ({ currentLang, onNavigateToBarcode }) => {
  const { isLight } = useTheme();
  const t = translations[currentLang];

  const [activeTab, setActiveTab] = useState<'new_inbound' | 'history'>('new_inbound');
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [inboundHistory, setInboundHistory] = useState<InboundReceipt[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Form State
  const [referenceNo, setReferenceNo] = useState('');
  const [supplierName, setSupplierName] = useState('');
  const [supplierMobile, setSupplierMobile] = useState('');
  const [inboundDate, setInboundDate] = useState(new Date().toISOString().slice(0, 10));
  const [paymentStatus, setPaymentStatus] = useState<'PAID' | 'CREDIT' | 'PARTIAL'>('PAID');
  const [extraCharges, setExtraCharges] = useState<string>('0');
  const [notes, setNotes] = useState('');
  const [items, setItems] = useState<InboundFormRow[]>([]);

  // Item Selector State
  const [productSearch, setProductSearch] = useState('');
  const [selectedProductToAdd, setSelectedProductToAdd] = useState<Product | null>(null);
  const [addQty, setAddQty] = useState<number>(1);
  const [addPurchaseRate, setAddPurchaseRate] = useState<string>('0');
  const [addSellingRate, setAddSellingRate] = useState<string>('0');
  const [addBatchNo, setAddBatchNo] = useState<string>('');
  const [addExpiryDate, setAddExpiryDate] = useState<string>('');

  // Quick Add New Product Modal
  const [showNewProductModal, setShowNewProductModal] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdBarcode, setNewProdBarcode] = useState('');
  const [newProdCost, setNewProdCost] = useState('');
  const [newProdSell, setNewProdSell] = useState('');
  const [newProdCatId, setNewProdCatId] = useState<number | undefined>(undefined);

  // Post-Save Success Modal
  const [savedReceipt, setSavedReceipt] = useState<InboundReceipt | null>(null);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // View Receipt Modal
  const [viewingReceipt, setViewingReceipt] = useState<InboundReceipt | null>(null);

  // Search History
  const [historySearch, setHistorySearch] = useState('');

  const barcodeInputRef = useRef<HTMLInputElement | null>(null);

  const loadAll = async () => {
    try {
      setIsLoading(true);
      const [prods, cats, sett, receipts] = await Promise.all([
        ipcClient.getProducts(),
        ipcClient.getCategories(),
        ipcClient.getSettings(),
        ipcClient.getInboundReceipts(),
      ]);
      setProducts(prods);
      setCategories(cats);
      setSettings(sett);
      setInboundHistory(receipts);

      // Generate initial reference number
      const datePrefix = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const nextNum = (receipts.length || 0) + 1;
      setReferenceNo(`INW-${datePrefix}-${String(nextNum).padStart(4, '0')}`);
    } catch (err) {
      console.error('Failed to load Inbound data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  // When picking a product to add
  const handleSelectProduct = (prod: Product) => {
    setSelectedProductToAdd(prod);
    setAddPurchaseRate(prod.purchase_price.toString());
    setAddSellingRate(prod.selling_price.toString());
    setAddQty(1);
    setProductSearch('');
  };

  // Add Row to Table
  const handleAddItemRow = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selectedProductToAdd) {
      // Check if productSearch is an exact barcode
      const found = products.find(
        (p) => p.barcode.toLowerCase() === productSearch.trim().toLowerCase()
      );
      if (found) {
        handleSelectProduct(found);
        return;
      }
      alert('Please select a product first.');
      return;
    }

    if (addQty <= 0) {
      alert('Quantity must be greater than 0.');
      return;
    }

    const rate = parseFloat(addPurchaseRate) || 0;
    const sellRate = parseFloat(addSellingRate) || selectedProductToAdd.selling_price;
    const amount = addQty * rate;

    const newRow: InboundFormRow = {
      productId: selectedProductToAdd.id,
      productName: selectedProductToAdd.name,
      barcode: selectedProductToAdd.barcode,
      batchNo: addBatchNo.trim(),
      expiryDate: addExpiryDate,
      quantity: addQty,
      purchaseRate: rate,
      sellingRate: sellRate,
      amount,
    };

    setItems((prev) => [...prev, newRow]);
    playScanBeep(true);

    // Reset selector
    setSelectedProductToAdd(null);
    setAddQty(1);
    setAddPurchaseRate('0');
    setAddSellingRate('0');
    setAddBatchNo('');
    setAddExpiryDate('');
    setProductSearch('');
    setTimeout(() => barcodeInputRef.current?.focus(), 100);
  };

  const handleRemoveRow = (index: number) => {
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleUpdateRow = (index: number, field: keyof InboundFormRow, val: any) => {
    setItems((prev) =>
      prev.map((row, i) => {
        if (i !== index) return row;
        const updated = { ...row, [field]: val };
        if (field === 'quantity' || field === 'purchaseRate') {
          updated.amount = (updated.quantity || 0) * (updated.purchaseRate || 0);
        }
        return updated;
      })
    );
  };

  // Calculations
  const subtotal = items.reduce((sum, itm) => sum + itm.amount, 0);
  const extra = parseFloat(extraCharges) || 0;
  const grandTotal = subtotal + extra;
  const totalUnits = items.reduce((sum, itm) => sum + (itm.quantity || 0), 0);

  // Save Inbound Goods Receipt
  const handleSaveInbound = async () => {
    if (!supplierName.trim()) {
      alert('Please enter the Supplier / Vendor name.');
      return;
    }
    if (items.length === 0) {
      alert('Please add at least one product item to inward.');
      return;
    }

    try {
      setIsLoading(true);
      const created = await ipcClient.createInboundReceipt({
        referenceNo: referenceNo.trim(),
        supplierName: supplierName.trim(),
        supplierMobile: supplierMobile.trim() || undefined,
        inboundDate,
        paymentStatus,
        extraCharges: extra,
        notes: notes.trim() || undefined,
        items: items.map((itm) => ({
          product_id: itm.productId,
          quantity: itm.quantity,
          purchase_rate: itm.purchaseRate,
          selling_rate: itm.sellingRate,
          batch_no: itm.batchNo || undefined,
          expiry_date: itm.expiryDate || undefined,
        })),
      });

      setSavedReceipt(created);
      setShowSuccessModal(true);
      playScanBeep(true);

      // Reset Form
      setItems([]);
      setSupplierName('');
      setSupplierMobile('');
      setExtraCharges('0');
      setNotes('');

      // Reload products & receipts list
      const [updatedProds, receipts] = await Promise.all([
        ipcClient.getProducts(),
        ipcClient.getInboundReceipts(),
      ]);
      setProducts(updatedProds);
      setInboundHistory(receipts);

      // Generate next ref
      const datePrefix = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const nextNum = (receipts.length || 0) + 1;
      setReferenceNo(`INW-${datePrefix}-${String(nextNum).padStart(4, '0')}`);
    } catch (err: any) {
      console.error('Failed to save Inbound Receipt:', err);
      alert(`Error saving inbound receipt: ${err.message || err}`);
    } finally {
      setIsLoading(false);
    }
  };

  // Create Quick Product
  const handleCreateQuickProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim() || !newProdBarcode.trim()) {
      alert('Please enter product name and barcode.');
      return;
    }

    try {
      const created = await ipcClient.createProduct({
        name: newProdName.trim(),
        barcode: newProdBarcode.trim(),
        category_id: newProdCatId,
        purchase_price: parseFloat(newProdCost) || 0,
        selling_price: parseFloat(newProdSell) || 0,
        opening_stock: 0,
        current_stock: 0,
        min_stock_level: 5,
      });

      setProducts((prev) => [...prev, created]);
      handleSelectProduct(created);
      setShowNewProductModal(false);
      setNewProdName('');
      setNewProdBarcode('');
      setNewProdCost('');
      setNewProdSell('');
    } catch (err: any) {
      alert(`Error creating product: ${err.message || err}`);
    }
  };

  // Filter History
  const filteredHistory = inboundHistory.filter((r) => {
    const q = historySearch.toLowerCase();
    return (
      r.reference_no.toLowerCase().includes(q) ||
      r.supplier_name.toLowerCase().includes(q) ||
      (r.supplier_mobile && r.supplier_mobile.includes(q))
    );
  });

  // Print Goods Receipt Note (GRN) Voucher
  const handlePrintGRN = (receipt: InboundReceipt) => {
    const printWindow = window.open('', '_blank', 'width=850,height=750');
    if (!printWindow) return;

    const storeName = settings?.business_name || 'TINY DEAMON WORKS';
    const storeAddress = settings?.address || 'Main Road, Business District';
    const storePhone = settings?.phone || '';
    const currency = settings?.currency_symbol || '₹';

    let itemRowsHtml = '';
    (receipt.items || []).forEach((itm, idx) => {
      itemRowsHtml += `
        <tr>
          <td style="padding: 6px 8px; border-bottom: 1px solid #ddd; text-align: center;">${idx + 1}</td>
          <td style="padding: 6px 8px; border-bottom: 1px solid #ddd;">
            <div style="font-weight: bold;">${itm.product_name}</div>
            <div style="font-size: 10px; color: #666; font-family: monospace;">Barcode: ${itm.barcode} ${itm.batch_no ? `| Batch: ${itm.batch_no}` : ''}</div>
          </td>
          <td style="padding: 6px 8px; border-bottom: 1px solid #ddd; text-align: right; font-weight: bold;">${itm.quantity}</td>
          <td style="padding: 6px 8px; border-bottom: 1px solid #ddd; text-align: right;">${currency}${itm.purchase_rate.toFixed(2)}</td>
          <td style="padding: 6px 8px; border-bottom: 1px solid #ddd; text-align: right; font-weight: bold;">${currency}${itm.amount.toFixed(2)}</td>
        </tr>
      `;
    });

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>GRN - ${receipt.reference_no}</title>
          <style>
            @page { margin: 12mm; }
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              color: #111;
              background: #fff;
              font-size: 12px;
              line-height: 1.4;
            }
            .header-table { width: 100%; margin-bottom: 16px; border-bottom: 2px solid #222; padding-bottom: 12px; }
            .info-box { width: 100%; border: 1px solid #ccc; border-radius: 6px; padding: 10px; margin-bottom: 16px; }
            .items-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
            .items-table th { background: #f0f0f0; border-bottom: 2px solid #333; padding: 8px; text-align: left; font-size: 11px; }
            .total-box { width: 300px; margin-left: auto; border: 1px solid #ccc; border-radius: 6px; padding: 10px; }
            .footer-sig { margin-top: 40px; display: flex; justify-content: space-between; }
          </style>
        </head>
        <body>
          <table class="header-table">
            <tr>
              <td>
                <h1 style="margin: 0; font-size: 20px; font-weight: 800; text-transform: uppercase;">${storeName}</h1>
                <div style="font-size: 11px; color: #444;">${storeAddress} ${storePhone ? `| Tel: ${storePhone}` : ''}</div>
              </td>
              <td style="text-align: right;">
                <div style="font-size: 16px; font-weight: 800; color: #1e40af;">GOODS RECEIPT NOTE (GRN)</div>
                <div style="font-weight: bold; font-family: monospace; font-size: 13px;">${receipt.reference_no}</div>
                <div style="font-size: 11px; color: #555;">Date: ${receipt.inbound_date}</div>
              </td>
            </tr>
          </table>

          <table class="info-box">
            <tr>
              <td style="width: 50%;">
                <div style="font-size: 10px; font-weight: bold; color: #666; text-transform: uppercase;">Supplier / Vendor:</div>
                <div style="font-size: 14px; font-weight: bold;">${receipt.supplier_name}</div>
                ${receipt.supplier_mobile ? `<div style="font-size: 11px; color: #444;">Phone: ${receipt.supplier_mobile}</div>` : ''}
              </td>
              <td style="width: 50%; text-align: right;">
                <div><strong>Payment Status:</strong> <span style="font-weight: bold; color: #047857;">${receipt.payment_status}</span></div>
                ${receipt.notes ? `<div style="font-size: 11px; color: #555; margin-top: 4px;">Memo: ${receipt.notes}</div>` : ''}
              </td>
            </tr>
          </table>

          <table class="items-table">
            <thead>
              <tr>
                <th style="width: 40px; text-align: center;">#</th>
                <th>Item Description</th>
                <th style="width: 80px; text-align: right;">Inward Qty</th>
                <th style="width: 100px; text-align: right;">Cost Rate</th>
                <th style="width: 110px; text-align: right;">Line Total</th>
              </tr>
            </thead>
            <tbody>
              ${itemRowsHtml}
            </tbody>
          </table>

          <div class="total-box">
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
              <span>Total Received Units:</span>
              <strong>${receipt.total_quantity}</strong>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
              <span>Subtotal:</span>
              <strong>${currency}${receipt.subtotal.toFixed(2)}</strong>
            </div>
            ${
              receipt.extra_charges > 0
                ? `
              <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span>Freight / Handling:</span>
                <strong>${currency}${receipt.extra_charges.toFixed(2)}</strong>
              </div>
            `
                : ''
            }
            <div style="display: flex; justify-content: space-between; border-top: 2px solid #222; padding-top: 6px; font-size: 14px; font-weight: bold;">
              <span>Grand Total:</span>
              <span>${currency}${receipt.total_amount.toFixed(2)}</span>
            </div>
          </div>

          <div class="footer-sig">
            <div style="text-align: center; width: 180px; border-top: 1px solid #888; padding-top: 5px;">
              Receiver's Signature
            </div>
            <div style="text-align: center; width: 180px; border-top: 1px solid #888; padding-top: 5px;">
              Store In-Charge / Authorized
            </div>
          </div>

          <script>
            window.onload = function() {
              window.print();
              setTimeout(function() { window.close(); }, 500);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div
      id="inbound-page-container"
      className={`p-6 space-y-6 max-w-7xl mx-auto min-h-screen ${
        isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-950 text-slate-100'
      }`}
    >
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">
                {currentLang === 'ta' ? 'உள்வரும் சரக்குகள் (Inbound / GRN)' : 'Inbound Goods (GRN)'}
              </h1>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                {currentLang === 'ta'
                  ? 'விற்பனையாளர்களிடமிருந்து வரும் சரக்கு வரவு, கொள்முதல் ரசீதுகள் மற்றும் இருப்பு புதுப்பித்தல்'
                  : 'Record supplier inward shipments, update inventory stock & generate Goods Receipt Notes'}
              </p>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div
          className={`flex items-center p-1 rounded-xl border ${
            isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
          }`}
        >
          <button
            id="tab-new-inbound"
            onClick={() => setActiveTab('new_inbound')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'new_inbound'
                ? 'bg-blue-600 text-white shadow'
                : isLight
                ? 'text-slate-600 hover:text-slate-900'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{currentLang === 'ta' ? 'புதிய சரக்கு வரவு' : 'New Inbound Entry'}</span>
          </button>
          <button
            id="tab-inbound-history"
            onClick={() => setActiveTab('history')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'history'
                ? 'bg-blue-600 text-white shadow'
                : isLight
                ? 'text-slate-600 hover:text-slate-900'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>{currentLang === 'ta' ? 'சரக்கு வரவு வரலாறு' : 'Inbound Receipts History'}</span>
          </button>
        </div>
      </div>

      {/* TAB 1: NEW INBOUND GOODS ENTRY */}
      {activeTab === 'new_inbound' && (
        <div className="space-y-6">
          {/* Top Form: Supplier & Reference Meta */}
          <div
            className={`p-6 rounded-2xl border space-y-4 ${
              isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
            }`}
          >
            <h2 className="text-sm font-semibold flex items-center gap-2 border-b pb-3 border-slate-200 dark:border-slate-800">
              <User className="w-4 h-4 text-blue-600" />
              <span>{currentLang === 'ta' ? 'விற்பனையாளர் & வரவு விவரங்கள்' : 'Supplier & Shipment Metadata'}</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-500">
                  {currentLang === 'ta' ? 'வரவு குறிப்பு எண்' : 'Reference / GRN No.'}
                </label>
                <input
                  type="text"
                  value={referenceNo}
                  onChange={(e) => setReferenceNo(e.target.value)}
                  placeholder="e.g. INW-20260917-0001"
                  className={`w-full px-3 py-2 rounded-xl text-xs font-mono font-bold border outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  }`}
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-500">
                  {currentLang === 'ta' ? 'விற்பனையாளர் பெயர் *' : 'Supplier / Vendor Name *'}
                </label>
                <input
                  type="text"
                  value={supplierName}
                  onChange={(e) => setSupplierName(e.target.value)}
                  placeholder="e.g. Apex Wholesalers Ltd"
                  className={`w-full px-3 py-2 rounded-xl text-xs font-semibold border outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  }`}
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-500">
                  {currentLang === 'ta' ? 'விற்பனையாளர் தொலைபேசி' : 'Supplier Mobile'}
                </label>
                <input
                  type="text"
                  value={supplierMobile}
                  onChange={(e) => setSupplierMobile(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className={`w-full px-3 py-2 rounded-xl text-xs border outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  }`}
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-slate-500">
                  {currentLang === 'ta' ? 'வரவு தேதி' : 'Inbound Receipt Date'}
                </label>
                <input
                  type="date"
                  value={inboundDate}
                  onChange={(e) => setInboundDate(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-xs font-medium border outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* Middle: Item Addition Bar */}
          <div
            className={`p-6 rounded-2xl border space-y-4 ${
              isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-3 border-slate-200 dark:border-slate-800">
              <h2 className="text-sm font-semibold flex items-center gap-2">
                <Boxes className="w-4 h-4 text-blue-600" />
                <span>{currentLang === 'ta' ? 'சரக்கு பொருட்களை சேர்த்தல்' : 'Add Inbound Goods'}</span>
              </h2>

              <button
                type="button"
                onClick={() => setShowNewProductModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{currentLang === 'ta' ? '+ புதிய பொருளை பதிவுசெய்' : '+ Quick Register New Product'}</span>
              </button>
            </div>

            {/* Fast Search & Selector */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
              <div className="sm:col-span-4 space-y-1">
                <label className="text-xs font-medium text-slate-500">
                  {currentLang === 'ta' ? 'பொருளைத் தேர்ந்தெடு / ஸ்கேன் செய்' : 'Scan Barcode or Search Catalog'}
                </label>
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    ref={barcodeInputRef}
                    type="text"
                    value={productSearch}
                    onChange={(e) => {
                      setProductSearch(e.target.value);
                      const exact = products.find(
                        (p) => p.barcode.toLowerCase() === e.target.value.trim().toLowerCase()
                      );
                      if (exact) handleSelectProduct(exact);
                    }}
                    placeholder="Scan barcode or type name..."
                    className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border outline-none ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                        : 'bg-slate-800 border-slate-700 text-slate-100'
                    }`}
                  />
                  {productSearch && (
                    <div
                      className={`absolute z-20 left-0 right-0 top-full mt-1 max-h-48 overflow-y-auto rounded-xl border shadow-xl ${
                        isLight ? 'bg-white border-slate-200' : 'bg-slate-850 border-slate-700'
                      }`}
                    >
                      {products
                        .filter(
                          (p) =>
                            p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
                            p.barcode.toLowerCase().includes(productSearch.toLowerCase())
                        )
                        .slice(0, 8)
                        .map((p) => (
                          <div
                            key={p.id}
                            onClick={() => handleSelectProduct(p)}
                            className={`p-2.5 text-xs flex justify-between items-center cursor-pointer ${
                              isLight ? 'hover:bg-slate-100' : 'hover:bg-slate-800'
                            }`}
                          >
                            <div>
                              <div className="font-bold">{p.name}</div>
                              <div className="text-[10px] font-mono text-slate-400">
                                {p.barcode} | Current Stock: {p.current_stock}
                              </div>
                            </div>
                            <span className="font-bold text-blue-600">₹{p.purchase_price}</span>
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="sm:col-span-2 space-y-1">
                <label className="text-xs font-medium text-slate-500">
                  {currentLang === 'ta' ? 'வரவு எண்ணிக்கை' : 'Inward Qty'}
                </label>
                <input
                  type="number"
                  min="1"
                  value={addQty}
                  onChange={(e) => setAddQty(Math.max(1, parseInt(e.target.value || '1', 10)))}
                  className={`w-full px-3 py-2 rounded-xl text-xs font-bold border outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  }`}
                />
              </div>

              <div className="sm:col-span-2 space-y-1">
                <label className="text-xs font-medium text-slate-500">
                  {currentLang === 'ta' ? 'கொள்முதல் விலை (₹)' : 'Purchase Cost (₹)'}
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={addPurchaseRate}
                  onChange={(e) => setAddPurchaseRate(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-xs font-bold border outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  }`}
                />
              </div>

              <div className="sm:col-span-2 space-y-1">
                <label className="text-xs font-medium text-slate-500">
                  {currentLang === 'ta' ? 'விற்பனை விலை (₹)' : 'Selling MRP (₹)'}
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={addSellingRate}
                  onChange={(e) => setAddSellingRate(e.target.value)}
                  className={`w-full px-3 py-2 rounded-xl text-xs font-bold border outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  }`}
                />
              </div>

              <div className="sm:col-span-2">
                <button
                  type="button"
                  onClick={handleAddItemRow}
                  disabled={!selectedProductToAdd}
                  className="w-full py-2.5 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50 disabled:cursor-not-allowed shadow transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Item</span>
                </button>
              </div>
            </div>

            {selectedProductToAdd && (
              <div className="p-2.5 rounded-xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-xs flex items-center justify-between">
                <span className="font-bold text-blue-900 dark:text-blue-200">
                  Selected: {selectedProductToAdd.name} ({selectedProductToAdd.barcode})
                </span>
                <span className="text-slate-600 dark:text-slate-400">
                  Current Stock: <strong>{selectedProductToAdd.current_stock}</strong> → Will become{' '}
                  <strong className="text-emerald-600">
                    {selectedProductToAdd.current_stock + addQty}
                  </strong>
                </span>
              </div>
            )}

            {/* Inbound Items Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
              <table className="w-full text-left text-xs">
                <thead
                  className={`border-b ${
                    isLight ? 'bg-slate-100 text-slate-700 font-semibold border-slate-200' : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  <tr>
                    <th className="p-3 w-10">#</th>
                    <th className="p-3">Product</th>
                    <th className="p-3">Barcode</th>
                    <th className="p-3 text-center">Inward Qty</th>
                    <th className="p-3 text-right">Cost Price (₹)</th>
                    <th className="p-3 text-right">Selling Price (₹)</th>
                    <th className="p-3 text-right">Line Total (₹)</th>
                    <th className="p-3 text-center w-12">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {items.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-400">
                        No goods added to this inbound receipt yet. Scan or search above to add items.
                      </td>
                    </tr>
                  ) : (
                    items.map((row, idx) => (
                      <tr
                        key={idx}
                        className={isLight ? 'hover:bg-slate-50' : 'hover:bg-slate-850'}
                      >
                        <td className="p-3 text-slate-400">{idx + 1}</td>
                        <td className="p-3 font-semibold">{row.productName}</td>
                        <td className="p-3 font-mono text-slate-500">{row.barcode}</td>
                        <td className="p-3 text-center">
                          <input
                            type="number"
                            min="1"
                            value={row.quantity}
                            onChange={(e) =>
                              handleUpdateRow(
                                idx,
                                'quantity',
                                Math.max(1, parseInt(e.target.value || '1', 10))
                              )
                            }
                            className={`w-16 px-2 py-1 rounded text-center border text-xs font-bold outline-none ${
                              isLight
                                ? 'bg-white border-slate-300 text-slate-900 focus:border-blue-600'
                                : 'bg-slate-800 border-slate-700 text-slate-100'
                            }`}
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            step="0.01"
                            value={row.purchaseRate}
                            onChange={(e) =>
                              handleUpdateRow(
                                idx,
                                'purchaseRate',
                                Math.max(0, parseFloat(e.target.value || '0'))
                              )
                            }
                            className={`w-20 px-2 py-1 rounded text-right border text-xs font-bold outline-none ${
                              isLight
                                ? 'bg-white border-slate-300 text-slate-900 focus:border-blue-600'
                                : 'bg-slate-800 border-slate-700 text-slate-100'
                            }`}
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            step="0.01"
                            value={row.sellingRate}
                            onChange={(e) =>
                              handleUpdateRow(
                                idx,
                                'sellingRate',
                                Math.max(0, parseFloat(e.target.value || '0'))
                              )
                            }
                            className={`w-20 px-2 py-1 rounded text-right border text-xs font-bold outline-none ${
                              isLight
                                ? 'bg-white border-slate-300 text-slate-900 focus:border-blue-600'
                                : 'bg-slate-800 border-slate-700 text-slate-100'
                            }`}
                          />
                        </td>
                        <td className="p-3 text-right font-black text-slate-900 dark:text-slate-100">
                          ₹{row.amount.toFixed(2)}
                        </td>
                        <td className="p-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveRow(idx)}
                            className="p-1 rounded text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950 transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Bottom Summary & Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div
              className={`lg:col-span-7 p-6 rounded-2xl border space-y-3 ${
                isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
              }`}
            >
              <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                {currentLang === 'ta' ? 'சரக்கு குறிப்புகள் & கட்டண நிலை' : 'Notes & Payment Terms'}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-slate-500">Payment Status</label>
                  <select
                    value={paymentStatus}
                    onChange={(e) => setPaymentStatus(e.target.value as any)}
                    className={`w-full px-3 py-2 rounded-xl text-xs border font-bold outline-none ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900'
                        : 'bg-slate-800 border-slate-700 text-slate-100'
                    }`}
                  >
                    <option value="PAID">PAID (செலுத்தப்பட்டது)</option>
                    <option value="CREDIT">CREDIT (கடன்)</option>
                    <option value="PARTIAL">PARTIAL (பகுதி)</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-slate-500">Freight / Extra Charges (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={extraCharges}
                    onChange={(e) => setExtraCharges(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl text-xs font-bold border outline-none ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900'
                        : 'bg-slate-800 border-slate-700 text-slate-100'
                    }`}
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs text-slate-500">Delivery Notes / LR No.</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Received via Transport, verified packaging..."
                  className={`w-full px-3 py-2 rounded-xl text-xs border outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  }`}
                ></textarea>
              </div>
            </div>

            <div
              className={`lg:col-span-5 p-6 rounded-2xl border flex flex-col justify-between space-y-4 ${
                isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
              }`}
            >
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-slate-500">
                  <span>Total Inbound Items:</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">{items.length} Products</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Total Received Units:</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">{totalUnits} Units</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Subtotal Cost:</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">₹{subtotal.toFixed(2)}</span>
                </div>
                {extra > 0 && (
                  <div className="flex justify-between text-slate-500">
                    <span>Freight / Charges:</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">₹{extra.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-base font-black border-t border-slate-200 dark:border-slate-800 pt-2 text-slate-950 dark:text-slate-100">
                  <span>Grand Inward Total:</span>
                  <span className="text-blue-600">₹{grandTotal.toFixed(2)}</span>
                </div>
              </div>

              <button
                type="button"
                id="btn-save-inbound"
                onClick={handleSaveInbound}
                disabled={items.length === 0 || !supplierName.trim()}
                className="w-full py-3 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{currentLang === 'ta' ? 'சரக்கு வரவை சேமித்து இருப்பை புதுப்பி' : 'Save & Inward Stock'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: INBOUND HISTORY */}
      {activeTab === 'history' && (
        <div
          className={`p-6 rounded-2xl border space-y-4 ${
            isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-4 border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-sm font-semibold">
                {currentLang === 'ta' ? 'சரக்கு வரவு பதிவுகள்' : 'Inbound Receipts Archive'}
              </h2>
              <p className="text-xs text-slate-500">
                {currentLang === 'ta'
                  ? 'கடந்த கால சரக்கு வரவுகள், விற்பனையாளர் ரசீதுகள் மற்றும் GRN அச்சிடுதல்'
                  : 'Track all inward deliveries, inspect line items and reprint Goods Receipt Notes'}
              </p>
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                placeholder="Search reference # or supplier..."
                className={`w-full pl-9 pr-3 py-1.5 rounded-xl text-xs border outline-none ${
                  isLight
                    ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                    : 'bg-slate-800 border-slate-700 text-slate-100'
                }`}
              />
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
            <table className="w-full text-left text-xs">
              <thead
                className={`border-b ${
                  isLight ? 'bg-slate-100 text-slate-700 font-semibold border-slate-200' : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}
              >
                <tr>
                  <th className="p-3">Reference #</th>
                  <th className="p-3">Supplier Name</th>
                  <th className="p-3">Date</th>
                  <th className="p-3 text-center">Items</th>
                  <th className="p-3 text-center">Total Qty</th>
                  <th className="p-3 text-right">Grand Total</th>
                  <th className="p-3 text-center">Payment</th>
                  <th className="p-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredHistory.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-400">
                      No inbound receipts found.
                    </td>
                  </tr>
                ) : (
                  filteredHistory.map((rec) => (
                    <tr
                      key={rec.id}
                      className={isLight ? 'hover:bg-slate-50' : 'hover:bg-slate-850'}
                    >
                      <td className="p-3 font-mono font-bold text-blue-600">{rec.reference_no}</td>
                      <td className="p-3 font-semibold">{rec.supplier_name}</td>
                      <td className="p-3 text-slate-500">{rec.inbound_date}</td>
                      <td className="p-3 text-center">{rec.total_items}</td>
                      <td className="p-3 text-center font-bold">{rec.total_quantity}</td>
                      <td className="p-3 text-right font-black text-slate-900 dark:text-slate-100">
                        ₹{rec.total_amount.toFixed(2)}
                      </td>
                      <td className="p-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            rec.payment_status === 'PAID'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          }`}
                        >
                          {rec.payment_status}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={async () => {
                              const full = await ipcClient.getInboundReceiptById(rec.id);
                              setViewingReceipt(full || rec);
                            }}
                            title="View GRN Details"
                            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                              isLight ? 'border-slate-200 hover:bg-slate-100' : 'border-slate-700 hover:bg-slate-800'
                            }`}
                          >
                            <Eye className="w-3.5 h-3.5 text-blue-600" />
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              const full = await ipcClient.getInboundReceiptById(rec.id);
                              handlePrintGRN(full || rec);
                            }}
                            title="Print GRN Voucher"
                            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                              isLight ? 'border-slate-200 hover:bg-slate-100' : 'border-slate-700 hover:bg-slate-800'
                            }`}
                          >
                            <Printer className="w-3.5 h-3.5 text-slate-600 dark:text-slate-300" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* QUICK ADD PRODUCT MODAL */}
      {showNewProductModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md p-6 rounded-2xl border shadow-2xl space-y-4 ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-slate-900 border-slate-800 text-slate-100'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <Package className="w-4 h-4 text-emerald-600" />
                <span>Quick Register New Product</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowNewProductModal(false)}
                className="p-1 rounded text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateQuickProduct} className="space-y-3 text-xs">
              <div className="space-y-1">
                <label className="font-semibold text-slate-500">Product Name *</label>
                <input
                  type="text"
                  required
                  value={newProdName}
                  onChange={(e) => setNewProdName(e.target.value)}
                  placeholder="e.g. A4 Notebook 192 Pages"
                  className={`w-full px-3 py-2 rounded-xl border outline-none font-medium ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  }`}
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-500">Barcode *</label>
                <input
                  type="text"
                  required
                  value={newProdBarcode}
                  onChange={(e) => setNewProdBarcode(e.target.value)}
                  placeholder="Scan or enter unique code..."
                  className={`w-full px-3 py-2 rounded-xl border font-mono font-bold outline-none ${
                    isLight
                      ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white focus:border-blue-600'
                      : 'bg-slate-800 border-slate-700 text-slate-100'
                  }`}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-500">Purchase Cost (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newProdCost}
                    onChange={(e) => setNewProdCost(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl border outline-none font-bold ${
                      isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-slate-100'
                    }`}
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-semibold text-slate-500">Selling Price (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newProdSell}
                    onChange={(e) => setNewProdSell(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl border outline-none font-bold ${
                      isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-slate-100'
                    }`}
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowNewProductModal(false)}
                  className={`flex-1 py-2 rounded-xl border font-semibold ${
                    isLight ? 'border-slate-200 hover:bg-slate-100' : 'border-slate-700 hover:bg-slate-800'
                  }`}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow"
                >
                  Save & Pick
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* POST-SAVE SUCCESS MODAL */}
      {showSuccessModal && savedReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md p-6 rounded-2xl border shadow-2xl space-y-4 text-center ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-slate-900 border-slate-800 text-slate-100'
            }`}
          >
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-7 h-7" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-bold">Stock Inward Successfully Recorded!</h3>
              <p className="text-xs text-slate-500">
                Reference <strong>{savedReceipt.reference_no}</strong> received {savedReceipt.total_quantity} units
                from {savedReceipt.supplier_name}. Product stocks have been updated.
              </p>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowSuccessModal(false);
                  handlePrintGRN(savedReceipt);
                }}
                className="w-full py-2.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-900 text-white dark:bg-slate-700 dark:hover:bg-slate-600 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Goods Receipt Note (GRN)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowSuccessModal(false);
                  if (onNavigateToBarcode && savedReceipt.items && savedReceipt.items.length > 0) {
                    onNavigateToBarcode(savedReceipt.items[0].product_id);
                  }
                }}
                className="w-full py-2.5 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow flex items-center justify-center gap-2 cursor-pointer"
              >
                <QrCode className="w-4 h-4" />
                <span>Print Barcode Labels for Received Items</span>
              </button>

              <button
                type="button"
                onClick={() => setShowSuccessModal(false)}
                className="w-full py-2 text-xs font-semibold text-slate-500 hover:text-slate-700 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VIEW RECEIPT DETAILS MODAL */}
      {viewingReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div
            className={`w-full max-w-2xl p-6 rounded-2xl border shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-slate-900 border-slate-800 text-slate-100'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="text-sm font-bold flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <span>Goods Receipt Note: {viewingReceipt.reference_no}</span>
                </h3>
                <p className="text-[11px] text-slate-500">
                  Supplier: {viewingReceipt.supplier_name} | Date: {viewingReceipt.inbound_date}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setViewingReceipt(null)}
                className="p-1 rounded text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Line items */}
            <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className={isLight ? 'bg-slate-100 text-slate-700' : 'bg-slate-800 text-slate-300'}>
                  <tr>
                    <th className="p-2.5">Product</th>
                    <th className="p-2.5">Barcode</th>
                    <th className="p-2.5 text-center">Qty</th>
                    <th className="p-2.5 text-right">Cost (₹)</th>
                    <th className="p-2.5 text-right">Total (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {(viewingReceipt.items || []).map((itm, idx) => (
                    <tr key={idx}>
                      <td className="p-2.5 font-semibold">{itm.product_name}</td>
                      <td className="p-2.5 font-mono text-slate-500">{itm.barcode}</td>
                      <td className="p-2.5 text-center font-bold">{itm.quantity}</td>
                      <td className="p-2.5 text-right">₹{itm.purchase_rate.toFixed(2)}</td>
                      <td className="p-2.5 text-right font-black">₹{itm.amount.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex justify-between items-center text-xs pt-2">
              <span className="text-slate-500">Grand Total: ₹{viewingReceipt.total_amount.toFixed(2)}</span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => handlePrintGRN(viewingReceipt)}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold bg-blue-600 text-white flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Voucher</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
