import React, { useEffect, useState } from 'react';
import {
  TrendingUp,
  Receipt,
  Boxes,
  AlertTriangle,
  FileClock,
  FilePlus,
  FileCheck,
  ShoppingCart,
  PlusCircle,
  Truck,
  QrCode,
  ArrowRight,
} from 'lucide-react';
import { DashboardStats } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { NavTab } from '../components/SidebarNav';
import { useTheme } from '../context/ThemeContext';

interface DashboardPageProps {
  onNavigate: (tab: NavTab) => void;
  currentLang: Language;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate, currentLang }) => {
  const { isLight } = useTheme();
  const [stats, setStats] = useState<DashboardStats>({
    todaySales: 0,
    todayBills: 0,
    totalQtySold: 0,
    lowStockCount: 0,
    pendingEstimates: 0,
    todayEstimates: 0,
    todayInvoices: 0,
  });
  const [businessName, setBusinessName] = useState('TINY DEAMON WORKS');

  const t = translations[currentLang];

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const [dashStats, settings] = await Promise.all([
          ipcClient.getDashboardStats(),
          ipcClient.getSettings(),
        ]);
        setStats(dashStats);
        if (settings?.business_name) {
          setBusinessName(settings.business_name);
        }
      } catch (err) {
        console.error('Failed to load dashboard statistics:', err);
      }
    };
    fetchDashboard();
  }, []);

  const statCards = [
    {
      title: t.todaySales,
      value: `₹${stats.todaySales.toFixed(2)}`,
      icon: TrendingUp,
      bg: isLight
        ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
        : 'bg-emerald-950/40 border-emerald-800/60 text-emerald-400',
      iconBg: isLight ? 'bg-emerald-100 text-emerald-700' : 'bg-emerald-900/50 text-emerald-400',
      numColor: isLight ? 'text-emerald-950' : 'text-emerald-400',
    },
    {
      title: t.todayBills,
      value: stats.todayBills.toString(),
      icon: Receipt,
      bg: isLight
        ? 'bg-blue-50 border-blue-200 text-blue-900'
        : 'bg-blue-950/40 border-blue-800/60 text-blue-400',
      iconBg: isLight ? 'bg-blue-100 text-blue-700' : 'bg-blue-900/50 text-blue-400',
      numColor: isLight ? 'text-blue-950' : 'text-blue-400',
    },
    {
      title: t.totalQtySold,
      value: stats.totalQtySold.toString(),
      icon: Boxes,
      bg: isLight
        ? 'bg-indigo-50 border-indigo-200 text-indigo-900'
        : 'bg-indigo-950/40 border-indigo-800/60 text-indigo-400',
      iconBg: isLight ? 'bg-indigo-100 text-indigo-700' : 'bg-indigo-900/50 text-indigo-400',
      numColor: isLight ? 'text-indigo-950' : 'text-indigo-400',
    },
    {
      title: t.lowStockItems,
      value: stats.lowStockCount.toString(),
      icon: AlertTriangle,
      bg: isLight
        ? 'bg-amber-50 border-amber-200 text-amber-900'
        : 'bg-amber-950/40 border-amber-800/60 text-amber-400',
      iconBg: isLight ? 'bg-amber-100 text-amber-700' : 'bg-amber-900/50 text-amber-400',
      numColor: isLight ? 'text-amber-950' : 'text-amber-400',
      action: () => onNavigate('stock'),
    },
    {
      title: t.pendingEstimates,
      value: stats.pendingEstimates.toString(),
      icon: FileClock,
      bg: isLight
        ? 'bg-purple-50 border-purple-200 text-purple-900'
        : 'bg-purple-950/40 border-purple-800/60 text-purple-400',
      iconBg: isLight ? 'bg-purple-100 text-purple-700' : 'bg-purple-900/50 text-purple-400',
      numColor: isLight ? 'text-purple-950' : 'text-purple-400',
      action: () => onNavigate('estimates_invoices'),
    },
    {
      title: t.todayEstimates,
      value: stats.todayEstimates.toString(),
      icon: FilePlus,
      bg: isLight
        ? 'bg-cyan-50 border-cyan-200 text-cyan-900'
        : 'bg-cyan-950/40 border-cyan-800/60 text-cyan-400',
      iconBg: isLight ? 'bg-cyan-100 text-cyan-700' : 'bg-cyan-900/50 text-cyan-400',
      numColor: isLight ? 'text-cyan-950' : 'text-cyan-400',
    },
    {
      title: t.todayInvoices,
      value: stats.todayInvoices.toString(),
      icon: FileCheck,
      bg: isLight
        ? 'bg-teal-50 border-teal-200 text-teal-900'
        : 'bg-teal-950/40 border-teal-800/60 text-teal-400',
      iconBg: isLight ? 'bg-teal-100 text-teal-700' : 'bg-teal-900/50 text-teal-400',
      numColor: isLight ? 'text-teal-950' : 'text-teal-400',
    },
  ];

  return (
    <div
      id="dashboard-container"
      className={`p-6 space-y-6 max-w-7xl mx-auto ${
        isLight ? 'text-slate-900' : 'text-slate-100'
      }`}
    >
      {/* Welcome banner */}
      <div
        className={`flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl border shadow-md transition-colors ${
          isLight
            ? 'bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-700 border-blue-600 text-white'
            : 'bg-gradient-to-r from-slate-900 via-slate-900 to-blue-950/60 border-slate-800 text-slate-100'
        }`}
      >
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-white text-[11px] font-semibold uppercase tracking-wider backdrop-blur-sm">
              Offline Retail POS
            </span>
            <span className="text-xs text-blue-100 font-medium font-mono">SQLite Local Fast Engine</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">{businessName}</h2>
          <p className="text-xs text-blue-100 max-w-xl">
            High-speed keyboard billing, barcode printing studio, supplier inbound stock, thermal printing, and comprehensive sales reports.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => onNavigate('pos')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-blue-700 hover:bg-blue-50 text-xs font-bold shadow-md cursor-pointer transition-all"
          >
            <ShoppingCart className="w-4 h-4 text-blue-600" />
            <span>{t.newSale} (F1)</span>
          </button>
          <button
            onClick={() => onNavigate('inbound')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-500/30 hover:bg-blue-500/40 text-white text-xs font-bold border border-white/20 backdrop-blur-sm cursor-pointer transition-colors"
          >
            <Truck className="w-4 h-4" />
            <span>{t.inbound} (F9)</span>
          </button>
          <button
            onClick={() => onNavigate('barcode')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-500/30 hover:bg-blue-500/40 text-white text-xs font-bold border border-white/20 backdrop-blur-sm cursor-pointer transition-colors"
          >
            <QrCode className="w-4 h-4" />
            <span>{t.barcodeHub} (F10)</span>
          </button>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div
              key={i}
              onClick={card.action}
              className={`p-5 rounded-2xl border ${card.bg} shadow-sm flex items-center justify-between ${
                card.action ? 'cursor-pointer hover:shadow-md transition-all' : ''
              }`}
            >
              <div className="space-y-1">
                <p className={`text-xs font-medium ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
                  {card.title}
                </p>
                <p className={`text-2xl font-bold tracking-tight ${card.numColor}`}>{card.value}</p>
              </div>
              <div className={`w-11 h-11 rounded-xl ${card.iconBg} flex items-center justify-center shadow-inner`}>
                <Icon className="w-5 h-5" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Action Navigation Panels */}
      <div className="space-y-3">
        <h3 className={`text-xs font-bold uppercase tracking-wider ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
          {t.quickActions}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div
            onClick={() => onNavigate('pos')}
            className={`p-5 rounded-2xl border transition-all cursor-pointer group space-y-2 ${
              isLight
                ? 'bg-white border-slate-200 hover:border-blue-500 hover:shadow-md'
                : 'bg-slate-900 border-slate-800 hover:border-blue-600/50 hover:bg-slate-800/40'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 dark:bg-blue-900/40 dark:border-blue-700/60 dark:text-blue-400">
              <ShoppingCart className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold group-hover:text-blue-600 transition-colors flex items-center justify-between">
              <span>{t.posBilling} (F1)</span>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-transform group-hover:translate-x-1" />
            </h4>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Instant barcode scanning, multi-item cart, split tender, cash change & thermal bill prints.
            </p>
          </div>

          <div
            onClick={() => onNavigate('inbound')}
            className={`p-5 rounded-2xl border transition-all cursor-pointer group space-y-2 ${
              isLight
                ? 'bg-white border-slate-200 hover:border-blue-500 hover:shadow-md'
                : 'bg-slate-900 border-slate-800 hover:border-blue-600/50 hover:bg-slate-800/40'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600 dark:bg-indigo-900/40 dark:border-indigo-700/60 dark:text-indigo-400">
              <Truck className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold group-hover:text-blue-600 transition-colors flex items-center justify-between">
              <span>{t.inbound} (F9)</span>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-transform group-hover:translate-x-1" />
            </h4>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Record vendor inward shipments, increase stocks automatically and generate Goods Receipt Notes.
            </p>
          </div>

          <div
            onClick={() => onNavigate('barcode')}
            className={`p-5 rounded-2xl border transition-all cursor-pointer group space-y-2 ${
              isLight
                ? 'bg-white border-slate-200 hover:border-blue-500 hover:shadow-md'
                : 'bg-slate-900 border-slate-800 hover:border-blue-600/50 hover:bg-slate-800/40'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-purple-50 border border-purple-200 flex items-center justify-center text-purple-600 dark:bg-purple-900/40 dark:border-purple-700/60 dark:text-purple-400">
              <QrCode className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold group-hover:text-blue-600 transition-colors flex items-center justify-between">
              <span>{t.barcodeHub} (F10)</span>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-transform group-hover:translate-x-1" />
            </h4>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Label customizer studio, barcode sticker printing on thermal rolls / A4 sheets & scanner tester.
            </p>
          </div>

          <div
            onClick={() => onNavigate('products')}
            className={`p-5 rounded-2xl border transition-all cursor-pointer group space-y-2 ${
              isLight
                ? 'bg-white border-slate-200 hover:border-blue-500 hover:shadow-md'
                : 'bg-slate-900 border-slate-800 hover:border-blue-600/50 hover:bg-slate-800/40'
            }`}
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 dark:bg-emerald-900/40 dark:border-emerald-700/60 dark:text-emerald-400">
              <Boxes className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold group-hover:text-emerald-600 transition-colors flex items-center justify-between">
              <span>{t.products} & {t.bulkImport}</span>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-transform group-hover:translate-x-1" />
            </h4>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
              Manage product pricing, barcodes, categories, and bulk import items via Excel/CSV.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
