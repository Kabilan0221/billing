import React, { useState } from 'react';
import { Lock, User as UserIcon, ShieldCheck, WifiOff, LogIn, Sun, Moon } from 'lucide-react';
import { User } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { useTheme } from '../context/ThemeContext';

interface LoginPageProps {
  onLoginSuccess: (user: User) => void;
  currentLang: Language;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess, currentLang }) => {
  const { isLight, toggleTheme } = useTheme();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const t = translations[currentLang];

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const user = await ipcClient.authenticate(username, password);
      if (user) {
        onLoginSuccess(user);
      } else {
        setError(t.invalidLogin);
      }
    } catch (err: any) {
      setError(err?.message || 'Authentication error');
    } finally {
      setIsLoading(false);
    }
  };

  const setDemoAccount = (u: string, p: string) => {
    setUsername(u);
    setPassword(p);
  };

  return (
    <div
      id="login-page-container"
      className={`min-h-screen flex flex-col justify-center items-center p-4 transition-colors duration-200 ${
        isLight ? 'bg-slate-100 text-slate-800' : 'bg-slate-950 text-slate-100'
      }`}
    >
      {/* Top Controls: Theme toggle */}
      <div className="absolute top-4 right-4 flex items-center gap-2">
        <button
          type="button"
          onClick={toggleTheme}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold shadow-xs transition-all cursor-pointer ${
            isLight
              ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              : 'bg-slate-900 border-slate-800 text-slate-200 hover:bg-slate-800'
          }`}
        >
          {isLight ? (
            <>
              <Sun className="w-4 h-4 text-amber-500" />
              <span>{t.lightMode || 'White Mode'}</span>
            </>
          ) : (
            <>
              <Moon className="w-4 h-4 text-blue-400" />
              <span>{t.darkMode || 'Dark Mode'}</span>
            </>
          )}
        </button>
      </div>

      <div
        className={`max-w-md w-full border rounded-2xl p-8 shadow-xl space-y-6 transition-colors duration-200 ${
          isLight ? 'bg-white border-slate-200 shadow-slate-200/60' : 'bg-slate-900 border-slate-800 shadow-2xl'
        }`}
      >
        {/* Brand Icon & Offline Badge */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-blue-600/10 border border-blue-500/30 text-blue-600 mb-2 shadow-inner">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <h1 className={`text-xl font-bold tracking-tight ${isLight ? 'text-slate-900' : 'text-white'}`}>
            {t.appName}
          </h1>
          <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>{t.loginPrompt}</p>

          <div
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${
              isLight
                ? 'bg-emerald-50 border border-emerald-200 text-emerald-700'
                : 'bg-emerald-950/80 border border-emerald-800 text-emerald-400'
            }`}
          >
            <WifiOff className="w-3.5 h-3.5" />
            <span>{t.offlineMode}</span>
          </div>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs dark:bg-red-950/60 dark:border-red-800 dark:text-red-300">
            {error}
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className={`block text-xs font-semibold mb-1.5 ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
              {t.username}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <UserIcon className="w-4 h-4" />
              </div>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin"
                className={`w-full pl-9 pr-3 py-2.5 border rounded-xl text-sm focus:outline-hidden focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all ${
                  isLight
                    ? 'bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-400'
                    : 'bg-slate-950 border-slate-700 text-slate-100 placeholder:text-slate-500'
                }`}
              />
            </div>
          </div>

          <div>
            <label className={`block text-xs font-semibold mb-1.5 ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
              {t.password}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className={`w-full pl-9 pr-3 py-2.5 border rounded-xl text-sm focus:outline-hidden focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all ${
                  isLight
                    ? 'bg-slate-50 border-slate-200 text-slate-900 placeholder:text-slate-400'
                    : 'bg-slate-950 border-slate-700 text-slate-100 placeholder:text-slate-500'
                }`}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-semibold cursor-pointer shadow-lg shadow-blue-500/20 transition-all"
          >
            <LogIn className="w-4 h-4" />
            <span>{isLoading ? 'Verifying...' : t.login}</span>
          </button>
        </form>

        {/* Quick Demo Accounts */}
        <div className={`pt-4 border-t text-center space-y-2 ${isLight ? 'border-slate-200' : 'border-slate-800'}`}>
          <p className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>Pre-configured local offline accounts:</p>
          <div className="flex justify-center gap-2">
            <button
              type="button"
              onClick={() => setDemoAccount('admin', 'admin123')}
              className={`px-3 py-1 rounded-lg text-xs font-mono transition-colors cursor-pointer border ${
                isLight
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
              }`}
            >
              admin / admin123
            </button>
            <button
              type="button"
              onClick={() => setDemoAccount('cashier', 'cashier123')}
              className={`px-3 py-1 rounded-lg text-xs font-mono transition-colors cursor-pointer border ${
                isLight
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
              }`}
            >
              cashier / cashier123
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
