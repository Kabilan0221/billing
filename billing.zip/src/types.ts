export type PaymentMethod = 'CASH' | 'UPI' | 'CARD' | 'SPLIT' | 'PAYTM_MANUAL';

export interface SplitPaymentDetail {
  cash: number;
  upi: number;
  card: number;
  paytm: number;
}

export interface User {
  id: number;
  username: string;
  password_hash: string;
  full_name: string;
  role: 'ADMIN' | 'CASHIER' | 'MANAGER';
  created_at: string;
  last_login?: string;
}

export interface Category {
  id: number;
  name: string;
  description?: string;
  created_at: string;
}

export interface Product {
  id: number;
  name: string;
  category_id?: number;
  category_name?: string;
  barcode: string;
  purchase_price: number;
  selling_price: number;
  opening_stock: number;
  current_stock: number;
  min_stock_level: number;
  created_at: string;
  updated_at: string;
}

export interface Customer {
  id: number;
  name: string;
  mobile: string;
  address?: string;
  total_bills?: number;
  total_spent?: number;
  created_at: string;
}

export interface BillItem {
  id?: number;
  bill_id?: number;
  product_id: number;
  product_name: string;
  barcode: string;
  quantity: number;
  rate: number;
  amount: number;
}

export interface Bill {
  id: number;
  bill_number: string;
  customer_id?: number;
  customer_name?: string;
  customer_mobile?: string;
  subtotal: number;
  discount: number;
  total_amount: number;
  payment_method: PaymentMethod;
  payment_status: 'PAID' | 'REFUNDED' | 'CANCELLED';
  cash_tendered?: number;
  change_due?: number;
  split_details?: string;
  notes?: string;
  created_at: string;
  items?: BillItem[];
}

export interface PaymentRecord {
  id: number;
  bill_id?: number;
  invoice_id?: number;
  payment_method: PaymentMethod;
  amount: number;
  cash_tendered?: number;
  change_due?: number;
  split_details?: string;
  notes?: string;
  created_at: string;
}

export type StockTransactionType =
  | 'OPENING'
  | 'SALE'
  | 'INWARD'
  | 'ADJUSTMENT'
  | 'INVOICE_SALE'
  | 'RESTORE';

export interface InboundItem {
  id?: number;
  inbound_id?: number;
  product_id: number;
  product_name: string;
  barcode: string;
  batch_no?: string;
  expiry_date?: string;
  quantity: number;
  purchase_rate: number;
  selling_rate?: number;
  amount: number;
}

export interface InboundReceipt {
  id: number;
  reference_no: string;
  supplier_name: string;
  supplier_mobile?: string;
  inbound_date: string;
  total_items: number;
  total_quantity: number;
  subtotal: number;
  extra_charges: number;
  total_amount: number;
  payment_status: 'PAID' | 'CREDIT' | 'PARTIAL';
  notes?: string;
  created_at: string;
  items?: InboundItem[];
}

export interface StockTransaction {
  id: number;
  product_id: number;
  product_name?: string;
  transaction_type: StockTransactionType;
  quantity_change: number;
  previous_stock: number;
  new_stock: number;
  reference_id?: string;
  notes?: string;
  created_at: string;
}

export type EstimateStatus = 'DRAFT' | 'SAVED' | 'CONVERTED' | 'CANCELLED';

export interface EstimateItem {
  id?: number;
  estimate_id?: number;
  product_id: number;
  product_name: string;
  barcode: string;
  quantity: number;
  rate: number;
  amount: number;
}

export interface Estimate {
  id: number;
  estimate_number: string;
  customer_name?: string;
  customer_mobile?: string;
  customer_address?: string;
  subtotal: number;
  discount: number;
  total_amount: number;
  status: EstimateStatus;
  notes?: string;
  converted_invoice_id?: number;
  converted_invoice_number?: string;
  created_at: string;
  updated_at: string;
  items?: EstimateItem[];
}

export interface InvoiceItem {
  id?: number;
  invoice_id?: number;
  product_id: number;
  product_name: string;
  barcode: string;
  quantity: number;
  rate: number;
  amount: number;
}

export interface Invoice {
  id: number;
  invoice_number: string;
  estimate_id?: number;
  estimate_number?: string;
  customer_name?: string;
  customer_mobile?: string;
  customer_address?: string;
  subtotal: number;
  discount: number;
  total_amount: number;
  payment_method: PaymentMethod;
  payment_status: 'PAID' | 'PARTIAL' | 'PENDING';
  cash_tendered?: number;
  change_due?: number;
  notes?: string;
  created_at: string;
  items?: InvoiceItem[];
}

export interface AppSettings {
  business_name: string;
  business_tagline: string;
  business_address: string;
  business_phone: string;
  business_email: string;
  receipt_footer: string;
  currency_symbol: string;
  thermal_printer_width: '58mm' | '80mm';
  auto_print_receipt: boolean;
  low_stock_warning_threshold: number;
  language: 'en' | 'ta';
}

export interface DashboardStats {
  todaySales: number;
  todayBills: number;
  totalQtySold: number;
  lowStockCount: number;
  pendingEstimates: number;
  todayEstimates: number;
  todayInvoices: number;
}

export interface SalesReportFilter {
  startDate: string;
  endDate: string;
  paymentMethod?: string;
}

export interface SalesReportSummary {
  totalSales: number;
  totalBills: number;
  totalQuantity: number;
  cashSales: number;
  upiSales: number;
  cardSales: number;
  splitSales: number;
  paytmSales: number;
  invoiceCount: number;
  invoiceTotal: number;
  estimateCount: number;
  productSales: Array<{
    product_name: string;
    barcode: string;
    total_quantity: number;
    total_revenue: number;
  }>;
  dailySales: Array<{
    date: string;
    bill_count: number;
    total_amount: number;
  }>;
}

export interface DataManagementImpact {
  billCount: number;
  totalSales: number;
  paymentCount: number;
  stockTransactionsCount: number;
  estimateCount: number;
  invoiceCount: number;
}

export type BusinessSettings = AppSettings;
export type SalesReportData = SalesReportSummary;
export type Payment = PaymentRecord;
