import { AppSettings, Bill } from '../types';

export interface PrintableReceiptData {
  title: string;
  documentNumber: string;
  date: string;
  time: string;
  customerName?: string;
  customerMobile?: string;
  customerAddress?: string;
  items: Array<{
    name: string;
    quantity: number;
    rate: number;
    amount: number;
  }>;
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod?: string;
  cashTendered?: number;
  changeDue?: number;
  splitDetails?: string;
  notes?: string;
  settings: AppSettings;
}

export class ThermalPrinterService {
  /**
   * Generates ESC/POS byte sequence for direct POS thermal hardware printers
   */
  public generateEscPos(data: PrintableReceiptData): Uint8Array {
    const bytes: number[] = [];

    // Helpers
    const pushBytes = (...b: number[]) => bytes.push(...b);
    const pushString = (str: string) => {
      for (let i = 0; i < str.length; i++) {
        bytes.push(str.charCodeAt(i) & 0xff);
      }
    };
    const pushLine = (str: string = '') => {
      pushString(str);
      pushBytes(0x0a); // LF
    };

    // ESC @ Initialize printer
    pushBytes(0x1b, 0x40);

    // ESC a 1 Align center
    pushBytes(0x1b, 0x61, 0x01);

    // Double height + bold for business name
    pushBytes(0x1b, 0x21, 0x20); // double height
    pushBytes(0x1b, 0x45, 0x01); // bold on
    pushLine(data.settings.business_name);

    // Reset font size
    pushBytes(0x1b, 0x21, 0x00);
    pushBytes(0x1b, 0x45, 0x00);

    if (data.settings.business_tagline) pushLine(data.settings.business_tagline);
    if (data.settings.business_address) pushLine(data.settings.business_address);
    if (data.settings.business_phone) pushLine(`Phone: ${data.settings.business_phone}`);

    const is80mm = data.settings.thermal_printer_width === '80mm';
    const divider = '-'.repeat(is80mm ? 42 : 32);

    pushLine(divider);
    // Title
    pushBytes(0x1b, 0x45, 0x01); // bold
    pushLine(`*** ${data.title} ***`);
    pushBytes(0x1b, 0x45, 0x00);

    // Align Left
    pushBytes(0x1b, 0x61, 0x00);
    pushLine(`No  : ${data.documentNumber}`);
    pushLine(`Date: ${data.date}  Time: ${data.time}`);
    if (data.customerName && data.customerName !== 'Walk-in Customer') {
      pushLine(`Cust: ${data.customerName}`);
    }
    if (data.customerMobile) {
      pushLine(`Mob : ${data.customerMobile}`);
    }

    pushLine(divider);

    // Table Header
    if (is80mm) {
      pushLine('Item                    Qty   Rate    Amount');
    } else {
      pushLine('Item            Qty   Rate   Amt');
    }
    pushLine(divider);

    // Items
    for (const item of data.items) {
      const name = item.name.length > (is80mm ? 22 : 14) ? item.name.substring(0, is80mm ? 21 : 13) + '.' : item.name;
      const qty = item.quantity.toString().padStart(4, ' ');
      const rate = item.rate.toFixed(2).padStart(7, ' ');
      const amt = item.amount.toFixed(2).padStart(8, ' ');

      if (is80mm) {
        const paddedName = name.padEnd(23, ' ');
        pushLine(`${paddedName} ${qty} ${rate} ${amt}`);
      } else {
        const paddedName = name.padEnd(15, ' ');
        pushLine(`${paddedName} ${qty} ${rate} ${amt}`);
      }
    }

    pushLine(divider);

    // Align Right
    pushBytes(0x1b, 0x61, 0x02);
    pushLine(`Subtotal: ${data.settings.currency_symbol} ${data.subtotal.toFixed(2)}`);
    if (data.discount > 0) {
      pushLine(`Discount: -${data.settings.currency_symbol} ${data.discount.toFixed(2)}`);
    }

    // Bold Total
    pushBytes(0x1b, 0x45, 0x01);
    pushLine(`TOTAL: ${data.settings.currency_symbol} ${data.total.toFixed(2)}`);
    pushBytes(0x1b, 0x45, 0x00);

    if (data.paymentMethod) {
      pushLine(`Payment: ${data.paymentMethod}`);
      if (data.cashTendered && data.cashTendered > 0) {
        pushLine(`Paid: ${data.settings.currency_symbol} ${data.cashTendered.toFixed(2)}`);
      }
      if (data.changeDue && data.changeDue > 0) {
        pushLine(`Change: ${data.settings.currency_symbol} ${data.changeDue.toFixed(2)}`);
      }
    }

    // Center Footer
    pushBytes(0x1b, 0x61, 0x01);
    pushLine(divider);
    if (data.settings.receipt_footer) {
      pushLine(data.settings.receipt_footer);
    }
    pushLine('Power: Offline Desktop Billing');

    // Feed and Cut (GS V 66 0)
    pushBytes(0x0a, 0x0a, 0x0a, 0x0a);
    pushBytes(0x1d, 0x56, 0x42, 0x00);

    return new Uint8Array(bytes);
  }

  /**
   * Browser / System print dialog trigger for thermal paper
   */
  public printViaBrowser(data: PrintableReceiptData): void {
    const is80mm = data.settings.thermal_printer_width === '80mm';
    const widthMm = is80mm ? '80mm' : '58mm';

    const printWindow = window.open('', '_blank', 'width=450,height=650');
    if (!printWindow) {
      window.print();
      return;
    }

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${data.title} - ${data.documentNumber}</title>
        <style>
          @page {
            margin: 0;
            size: ${widthMm} auto;
          }
          body {
            font-family: 'Courier New', Courier, monospace;
            font-size: 12px;
            line-height: 1.3;
            margin: 0;
            padding: 8px;
            color: #000;
            background: #fff;
            width: ${widthMm};
            box-sizing: border-box;
          }
          .text-center { text-align: center; }
          .text-right { text-align: right; }
          .bold { font-weight: bold; }
          .title { font-size: 14px; font-weight: bold; margin: 4px 0; }
          .business-name { font-size: 16px; font-weight: bold; text-transform: uppercase; }
          .divider { border-top: 1px dashed #000; margin: 6px 0; }
          .flex { display: flex; justify-content: space-between; }
          table { width: 100%; border-collapse: collapse; margin: 4px 0; font-size: 11px; }
          th { border-bottom: 1px dashed #000; padding: 2px 0; text-align: left; }
          td { padding: 3px 0; vertical-align: top; }
          .footer { margin-top: 8px; font-size: 10px; text-align: center; }
        </style>
      </head>
      <body>
        <div class="text-center">
          <div class="business-name">${escapeHtml(data.settings.business_name)}</div>
          <div>${escapeHtml(data.settings.business_tagline || '')}</div>
          <div>${escapeHtml(data.settings.business_address || '')}</div>
          <div>Phone: ${escapeHtml(data.settings.business_phone || '')}</div>
        </div>

        <div class="divider"></div>

        <div class="text-center title">*** ${data.title} ***</div>
        <div class="flex">
          <span>No: ${escapeHtml(data.documentNumber)}</span>
          <span>${escapeHtml(data.date)}</span>
        </div>
        <div class="flex">
          <span>Time: ${escapeHtml(data.time)}</span>
          ${data.customerMobile ? `<span>Mob: ${escapeHtml(data.customerMobile)}</span>` : ''}
        </div>
        ${
          data.customerName && data.customerName !== 'Walk-in Customer'
            ? `<div>Cust: ${escapeHtml(data.customerName)}</div>`
            : ''
        }

        <div class="divider"></div>

        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th class="text-right">Qty</th>
              <th class="text-right">Rate</th>
              <th class="text-right">Amt</th>
            </tr>
          </thead>
          <tbody>
            ${data.items
              .map(
                (item) => `
              <tr>
                <td>${escapeHtml(item.name)}</td>
                <td class="text-right">${item.quantity}</td>
                <td class="text-right">${item.rate.toFixed(2)}</td>
                <td class="text-right">${item.amount.toFixed(2)}</td>
              </tr>
            `
              )
              .join('')}
          </tbody>
        </table>

        <div class="divider"></div>

        <div class="text-right">
          <div>Subtotal: ${data.settings.currency_symbol} ${data.subtotal.toFixed(2)}</div>
          ${
            data.discount > 0
              ? `<div>Discount: -${data.settings.currency_symbol} ${data.discount.toFixed(2)}</div>`
              : ''
          }
          <div class="bold" style="font-size: 14px; margin: 4px 0;">
            TOTAL: ${data.settings.currency_symbol} ${data.total.toFixed(2)}
          </div>
          ${data.paymentMethod ? `<div>Payment: ${escapeHtml(data.paymentMethod)}</div>` : ''}
          ${
            data.cashTendered && data.cashTendered > 0
              ? `<div>Paid: ${data.settings.currency_symbol} ${data.cashTendered.toFixed(2)}</div>`
              : ''
          }
          ${
            data.changeDue && data.changeDue > 0
              ? `<div>Change: ${data.settings.currency_symbol} ${data.changeDue.toFixed(2)}</div>`
              : ''
          }
        </div>

        <div class="divider"></div>

        <div class="footer">
          <div>${escapeHtml(data.settings.receipt_footer || 'Thank you!')}</div>
          <div style="margin-top: 4px; color: #555;">Offline Desktop POS</div>
        </div>

        <script>
          window.onload = function() {
            window.focus();
            window.print();
            setTimeout(function() { window.close(); }, 500);
          };
        </script>
      </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
  }

  public downloadEscPosFile(data: PrintableReceiptData): void {
    const escposBytes = this.generateEscPos(data);
    const blob = new Blob([escposBytes], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${data.documentNumber}-escpos.bin`;
    a.click();
    URL.revokeObjectURL(url);
  }
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export const thermalPrinterService = new ThermalPrinterService();
