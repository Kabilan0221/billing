import { sqliteService } from '../database/sqlite-service';
import {
  AppSettings,
  Bill,
  Category,
  Customer,
  DashboardStats,
  DataManagementImpact,
  Estimate,
  InboundReceipt,
  Invoice,
  PaymentMethod,
  PaymentRecord,
  Product,
  SalesReportSummary,
  StockTransaction,
  User,
} from '../types';

declare global {
  interface Window {
    electronAPI?: {
      isElectron: boolean;
      platform: string;
      invoke: (channel: string, ...args: any[]) => Promise<any>;
    };
  }
}

class IPCClientService {
  private initialized = false;

  private async ensureInitialized(): Promise<void> {
    if (!this.initialized) {
      if (!this.isElectronEnvironment()) {
        await sqliteService.init();
      }
      this.initialized = true;
    }
  }

  public isElectronEnvironment(): boolean {
    return typeof window !== 'undefined' && !!window.electronAPI?.isElectron;
  }

  private async invoke<T>(channel: string, ...args: any[]): Promise<T> {
    await this.ensureInitialized();

    if (this.isElectronEnvironment()) {
      return window.electronAPI!.invoke(channel, ...args);
    }

    // Direct SQLite service execution in Browser/Web Preview mode
    switch (channel) {
      case 'db:authenticate':
        return sqliteService.authenticate(args[0], args[1]) as any;
      case 'db:getCategories':
        return sqliteService.getCategories() as any;
      case 'db:addCategory':
        return sqliteService.addCategory(args[0], args[1]) as any;
      case 'db:getProducts':
        return sqliteService.getProducts(args[0], args[1]) as any;
      case 'db:getProductByBarcode':
        return sqliteService.getProductByBarcode(args[0]) as any;
      case 'db:getProductById':
        return sqliteService.getProductById(args[0]) as any;
      case 'db:saveProduct':
        return sqliteService.saveProduct(args[0]) as any;
      case 'db:deleteProduct':
        return sqliteService.deleteProduct(args[0]) as any;
      case 'db:bulkImportProducts':
        return sqliteService.bulkImportProducts(args[0]) as any;
      case 'db:getCustomers':
        return sqliteService.getCustomers(args[0]) as any;
      case 'db:createBill':
        return sqliteService.createBillTransaction(args[0]) as any;
      case 'db:getBillById':
        return sqliteService.getBillById(args[0]) as any;
      case 'db:getBills':
        return sqliteService.getBills(args[0]) as any;
      case 'db:deleteBill':
        return sqliteService.deleteBill(args[0], args[1]) as any;
      case 'db:getPayments':
        return sqliteService.getPayments() as any;
      case 'db:adjustStock':
        return sqliteService.adjustStock(args[0]) as any;
      case 'db:getStockTransactions':
        return sqliteService.getStockTransactions(args[0]) as any;
      case 'db:createInboundReceipt':
        return sqliteService.createInboundReceipt(args[0]) as any;
      case 'db:getInboundReceiptById':
        return sqliteService.getInboundReceiptById(args[0]) as any;
      case 'db:getInboundReceipts':
        return sqliteService.getInboundReceipts(args[0]) as any;
      case 'db:deleteInboundReceipt':
        return sqliteService.deleteInboundReceipt(args[0], args[1]) as any;
      case 'db:createEstimate':
        return sqliteService.createEstimate(args[0]) as any;
      case 'db:getEstimateById':
        return sqliteService.getEstimateById(args[0]) as any;
      case 'db:getEstimates':
        return sqliteService.getEstimates(args[0]) as any;
      case 'db:deleteEstimate':
        return sqliteService.deleteEstimate(args[0]) as any;
      case 'db:convertEstimateToInvoice':
        return sqliteService.convertEstimateToInvoice(args[0], args[1]) as any;
      case 'db:createInvoice':
        return sqliteService.createInvoice(args[0]) as any;
      case 'db:getInvoiceById':
        return sqliteService.getInvoiceById(args[0]) as any;
      case 'db:getInvoices':
        return sqliteService.getInvoices(args[0]) as any;
      case 'db:deleteInvoice':
        return sqliteService.deleteInvoice(args[0], args[1]) as any;
      case 'db:getDashboardStats':
        return sqliteService.getDashboardStats() as any;
      case 'db:getSalesReport':
        return sqliteService.getSalesReport(args[0], args[1]) as any;
      case 'db:getSettings':
        return sqliteService.getSettings() as any;
      case 'db:saveSettings':
        return sqliteService.saveSettings(args[0]) as any;
      case 'db:exportDatabase':
        return sqliteService.exportDatabaseBinary() as any;
      case 'db:restoreDatabase':
        return sqliteService.restoreDatabaseBinary(args[0]) as any;
      case 'db:calculateDataImpact':
        return sqliteService.calculateDataImpact(args[0], args[1]) as any;
      case 'db:purgeDataRange':
        return sqliteService.purgeDataRange(args[0], args[1], args[2]) as any;
      default:
        throw new Error(`Unhandled channel: ${channel}`);
    }
  }

  // --- TYPED IPC METHODS ---
  public async authenticate(username: string, password: string): Promise<User | null> {
    return this.invoke<User | null>('db:authenticate', username, password);
  }

  public async getCategories(): Promise<Category[]> {
    return this.invoke<Category[]>('db:getCategories');
  }

  public async addCategory(name: string, description: string = ''): Promise<Category> {
    return this.invoke<Category>('db:addCategory', name, description);
  }

  public async getProducts(search: string = '', categoryId?: number): Promise<Product[]> {
    return this.invoke<Product[]>('db:getProducts', search, categoryId);
  }

  public async getProductByBarcode(barcode: string): Promise<Product | null> {
    return this.invoke<Product | null>('db:getProductByBarcode', barcode);
  }

  public async getProductById(id: number): Promise<Product | null> {
    return this.invoke<Product | null>('db:getProductById', id);
  }

  public async saveProduct(prod: Partial<Product>): Promise<Product> {
    return this.invoke<Product>('db:saveProduct', prod);
  }

  public async createProduct(prod: Partial<Product>): Promise<Product> {
    return this.saveProduct(prod);
  }

  public async deleteProduct(id: number): Promise<void> {
    return this.invoke<void>('db:deleteProduct', id);
  }

  public async bulkImportProducts(
    rows: Array<{
      name: string;
      category?: string;
      barcode: string;
      purchase_price: number;
      selling_price: number;
      opening_stock: number;
      min_stock_level: number;
    }>
  ): Promise<{ imported: number; errors: string[] }> {
    return this.invoke<{ imported: number; errors: string[] }>('db:bulkImportProducts', rows);
  }

  public async getCustomers(search: string = ''): Promise<Customer[]> {
    return this.invoke<Customer[]>('db:getCustomers', search);
  }

  public async createBill(params: {
    customerName?: string;
    customerMobile?: string;
    customerAddress?: string;
    items: Array<{ product_id: number; quantity: number; rate: number }>;
    discount: number;
    paymentMethod: PaymentMethod;
    cashTendered?: number;
    changeDue?: number;
    splitDetails?: string;
    notes?: string;
  }): Promise<Bill> {
    return this.invoke<Bill>('db:createBill', params);
  }

  public async getBillById(id: number): Promise<Bill | null> {
    return this.invoke<Bill | null>('db:getBillById', id);
  }

  public async getBills(params: { search?: string; startDate?: string; endDate?: string } | string = {}): Promise<Bill[]> {
    const queryParams = typeof params === 'string' ? { search: params } : params;
    return this.invoke<Bill[]>('db:getBills', queryParams);
  }

  public async deleteBill(
    billId: number,
    restoreStock: boolean = true
  ): Promise<{ success: boolean; billNumber: string; restoredItems: number }> {
    return this.invoke('db:deleteBill', billId, restoreStock);
  }

  public async getPayments(): Promise<PaymentRecord[]> {
    return this.invoke<PaymentRecord[]>('db:getPayments');
  }

  public async adjustStock(params: {
    productId: number;
    transactionType: 'INWARD' | 'ADJUSTMENT';
    quantityChange: number;
    notes?: string;
  }): Promise<Product> {
    return this.invoke<Product>('db:adjustStock', params);
  }

  public async getStockTransactions(productId?: number): Promise<StockTransaction[]> {
    return this.invoke<StockTransaction[]>('db:getStockTransactions', productId);
  }

  public async createInboundReceipt(params: {
    referenceNo?: string;
    supplierName: string;
    supplierMobile?: string;
    inboundDate?: string;
    paymentStatus?: 'PAID' | 'CREDIT' | 'PARTIAL';
    extraCharges?: number;
    notes?: string;
    items: Array<{
      product_id: number;
      quantity: number;
      purchase_rate: number;
      selling_rate?: number;
      batch_no?: string;
      expiry_date?: string;
    }>;
  }): Promise<InboundReceipt> {
    return this.invoke<InboundReceipt>('db:createInboundReceipt', params);
  }

  public async getInboundReceiptById(id: number): Promise<InboundReceipt | null> {
    return this.invoke<InboundReceipt | null>('db:getInboundReceiptById', id);
  }

  public async getInboundReceipts(params?: { search?: string; startDate?: string; endDate?: string } | string): Promise<InboundReceipt[]> {
    return this.invoke<InboundReceipt[]>('db:getInboundReceipts', params);
  }

  public async deleteInboundReceipt(id: number, revertStock: boolean = false): Promise<boolean> {
    return this.invoke<boolean>('db:deleteInboundReceipt', id, revertStock);
  }

  public async createEstimate(params: {
    customerName?: string;
    customerMobile?: string;
    customerAddress?: string;
    items: Array<{ product_id: number; quantity: number; rate: number }>;
    discount: number;
    notes?: string;
    status?: 'DRAFT' | 'SAVED';
  }): Promise<Estimate> {
    return this.invoke<Estimate>('db:createEstimate', params);
  }

  public async getEstimateById(id: number): Promise<Estimate | null> {
    return this.invoke<Estimate | null>('db:getEstimateById', id);
  }

  public async getEstimates(search: string = ''): Promise<Estimate[]> {
    return this.invoke<Estimate[]>('db:getEstimates', search);
  }

  public async deleteEstimate(id: number): Promise<void> {
    return this.invoke<void>('db:deleteEstimate', id);
  }

  public async convertEstimateToInvoice(estimateId: number, paymentMethod: PaymentMethod = 'CASH'): Promise<Invoice> {
    return this.invoke<Invoice>('db:convertEstimateToInvoice', estimateId, paymentMethod);
  }

  public async createInvoice(params: {
    customerName?: string;
    customerMobile?: string;
    customerAddress?: string;
    items: Array<{ product_id: number; quantity: number; rate: number }>;
    discount: number;
    paymentMethod: PaymentMethod;
    notes?: string;
  }): Promise<Invoice> {
    return this.invoke<Invoice>('db:createInvoice', params);
  }

  public async getInvoiceById(id: number): Promise<Invoice | null> {
    return this.invoke<Invoice | null>('db:getInvoiceById', id);
  }

  public async getInvoices(search: string = ''): Promise<Invoice[]> {
    return this.invoke<Invoice[]>('db:getInvoices', search);
  }

  public async deleteInvoice(
    invoiceId: number,
    restoreStock: boolean = true
  ): Promise<{ success: boolean; invoiceNumber: string }> {
    return this.invoke('db:deleteInvoice', invoiceId, restoreStock);
  }

  public async getDashboardStats(): Promise<DashboardStats> {
    return this.invoke<DashboardStats>('db:getDashboardStats');
  }

  public async getSalesReport(startDate: string, endDate: string): Promise<SalesReportSummary> {
    return this.invoke<SalesReportSummary>('db:getSalesReport', startDate, endDate);
  }

  public async getSettings(): Promise<AppSettings> {
    return this.invoke<AppSettings>('db:getSettings');
  }

  public async saveSettings(settings: Partial<AppSettings>): Promise<void> {
    return this.invoke<void>('db:saveSettings', settings);
  }

  public async updateSettings(settings: Partial<AppSettings>): Promise<void> {
    return this.saveSettings(settings);
  }

  public async recordStockAdjustment(params: {
    productId: number;
    type: 'INWARD' | 'ADJUSTMENT';
    quantityChange: number;
    notes?: string;
  }): Promise<Product> {
    return this.adjustStock({
      productId: params.productId,
      transactionType: params.type,
      quantityChange: params.quantityChange,
      notes: params.notes,
    });
  }

  public async exportDatabase(): Promise<Uint8Array> {
    return this.invoke<Uint8Array>('db:exportDatabase');
  }

  public async restoreDatabase(binary: Uint8Array): Promise<void> {
    return this.invoke<void>('db:restoreDatabase', binary);
  }

  public async calculateDataImpact(startDateOrBefore: string, endDate?: string): Promise<DataManagementImpact> {
    const start = endDate ? startDateOrBefore : '1970-01-01';
    const end = endDate ? endDate : startDateOrBefore;
    return this.invoke<DataManagementImpact>('db:calculateDataImpact', start, end);
  }

  public async purgeDataRange(
    startDate: string,
    endDate: string,
    purgeAll: boolean
  ): Promise<{ deletedBills: number; deletedInvoices: number; deletedEstimates: number }> {
    return this.invoke('db:purgeDataRange', startDate, endDate, purgeAll);
  }

  public async purgeDataBeforeDate(beforeDate: string): Promise<{ deletedBills: number }> {
    const res = await this.purgeDataRange('1970-01-01', beforeDate, false);
    return { deletedBills: res.deletedBills };
  }
}

export const ipcClient = new IPCClientService();
