import { app, BrowserWindow, ipcMain, dialog } from 'electron';
import path from 'path';
import { sqliteService } from '../database/sqlite-service';

let mainWindow: BrowserWindow | null = null;

async function createWindow() {
  await sqliteService.init();

  mainWindow = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 1024,
    minHeight: 700,
    frame: false, // Custom Windows titlebar
    backgroundColor: '#0f172a',
    webPreferences: {
      preload: path.join(__dirname, '../preload/preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  const isDev = process.env.NODE_ENV !== 'production';
  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// IPC Handlers for secure database operations
function registerIpcHandlers() {
  ipcMain.handle('app:minimize', () => mainWindow?.minimize());
  ipcMain.handle('app:maximize', () => {
    if (mainWindow?.isMaximized()) {
      mainWindow.unmaximize();
    } else {
      mainWindow?.maximize();
    }
  });
  ipcMain.handle('app:close', () => mainWindow?.close());

  // Auth
  ipcMain.handle('db:authenticate', async (_, username, password) => {
    return sqliteService.authenticate(username, password);
  });

  // Categories & Products
  ipcMain.handle('db:getCategories', async () => sqliteService.getCategories());
  ipcMain.handle('db:addCategory', async (_, name, desc) => sqliteService.addCategory(name, desc));
  ipcMain.handle('db:getProducts', async (_, search, catId) => sqliteService.getProducts(search, catId));
  ipcMain.handle('db:getProductByBarcode', async (_, barcode) => sqliteService.getProductByBarcode(barcode));
  ipcMain.handle('db:getProductById', async (_, id) => sqliteService.getProductById(id));
  ipcMain.handle('db:saveProduct', async (_, prod) => sqliteService.saveProduct(prod));
  ipcMain.handle('db:deleteProduct', async (_, id) => sqliteService.deleteProduct(id));
  ipcMain.handle('db:bulkImportProducts', async (_, rows) => sqliteService.bulkImportProducts(rows));

  // Customers
  ipcMain.handle('db:getCustomers', async (_, search) => sqliteService.getCustomers(search));

  // Bills & POS
  ipcMain.handle('db:createBill', async (_, params) => sqliteService.createBillTransaction(params));
  ipcMain.handle('db:getBillById', async (_, id) => sqliteService.getBillById(id));
  ipcMain.handle('db:getBills', async (_, params) => sqliteService.getBills(params));
  ipcMain.handle('db:deleteBill', async (_, billId, restoreStock) => sqliteService.deleteBill(billId, restoreStock));
  ipcMain.handle('db:getPayments', async () => sqliteService.getPayments());

  // Stock
  ipcMain.handle('db:adjustStock', async (_, params) => sqliteService.adjustStock(params));
  ipcMain.handle('db:getStockTransactions', async (_, prodId) => sqliteService.getStockTransactions(prodId));

  // Estimates & Invoices
  ipcMain.handle('db:createEstimate', async (_, params) => sqliteService.createEstimate(params));
  ipcMain.handle('db:getEstimateById', async (_, id) => sqliteService.getEstimateById(id));
  ipcMain.handle('db:getEstimates', async (_, search) => sqliteService.getEstimates(search));
  ipcMain.handle('db:deleteEstimate', async (_, id) => sqliteService.deleteEstimate(id));
  ipcMain.handle('db:convertEstimateToInvoice', async (_, estId, paymentMethod) =>
    sqliteService.convertEstimateToInvoice(estId, paymentMethod)
  );
  ipcMain.handle('db:createInvoice', async (_, params) => sqliteService.createInvoice(params));
  ipcMain.handle('db:getInvoiceById', async (_, id) => sqliteService.getInvoiceById(id));
  ipcMain.handle('db:getInvoices', async (_, search) => sqliteService.getInvoices(search));
  ipcMain.handle('db:deleteInvoice', async (_, id, restoreStock) => sqliteService.deleteInvoice(id, restoreStock));

  // Stats & Reports
  ipcMain.handle('db:getDashboardStats', async () => sqliteService.getDashboardStats());
  ipcMain.handle('db:getSalesReport', async (_, start, end) => sqliteService.getSalesReport(start, end));

  // Settings
  ipcMain.handle('db:getSettings', async () => sqliteService.getSettings());
  ipcMain.handle('db:saveSettings', async (_, settings) => sqliteService.saveSettings(settings));

  // Backup & Restore
  ipcMain.handle('db:exportDatabase', async () => {
    return sqliteService.exportDatabaseBinary();
  });
  ipcMain.handle('db:restoreDatabase', async (_, binary) => {
    return sqliteService.restoreDatabaseBinary(binary);
  });

  // Data management
  ipcMain.handle('db:calculateDataImpact', async (_, start, end) =>
    sqliteService.calculateDataImpact(start, end)
  );
  ipcMain.handle('db:purgeDataRange', async (_, start, end, purgeAll) =>
    sqliteService.purgeDataRange(start, end, purgeAll)
  );
}

app.whenReady().then(() => {
  registerIpcHandlers();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
