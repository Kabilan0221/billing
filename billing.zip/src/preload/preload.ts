import { contextBridge, ipcRenderer } from 'electron';

// Expose safe, isolated Electron API to renderer
contextBridge.exposeInMainWorld('electronAPI', {
  isElectron: true,
  platform: process.platform,

  // Database IPC
  invoke: (channel: string, ...args: any[]) => {
    const validChannels = [
      'db:authenticate',
      'db:getCategories',
      'db:addCategory',
      'db:getProducts',
      'db:getProductByBarcode',
      'db:getProductById',
      'db:saveProduct',
      'db:deleteProduct',
      'db:bulkImportProducts',
      'db:getCustomers',
      'db:createBill',
      'db:getBillById',
      'db:getBills',
      'db:deleteBill',
      'db:getPayments',
      'db:adjustStock',
      'db:getStockTransactions',
      'db:createEstimate',
      'db:getEstimateById',
      'db:getEstimates',
      'db:deleteEstimate',
      'db:convertEstimateToInvoice',
      'db:createInvoice',
      'db:getInvoiceById',
      'db:getInvoices',
      'db:deleteInvoice',
      'db:getDashboardStats',
      'db:getSalesReport',
      'db:getSettings',
      'db:saveSettings',
      'db:exportDatabase',
      'db:restoreDatabase',
      'db:calculateDataImpact',
      'db:purgeDataRange',
      'printer:printThermal',
      'app:minimize',
      'app:maximize',
      'app:close',
    ];

    if (validChannels.includes(channel)) {
      return ipcRenderer.invoke(channel, ...args);
    }
    return Promise.reject(new Error(`Unauthorized IPC channel: ${channel}`));
  },
});
