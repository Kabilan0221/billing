import React, { useEffect, useRef } from 'react';
import JsBarcode from 'jsbarcode';
import { Printer, Download } from 'lucide-react';

interface BarcodeVisualProps {
  value: string;
  width?: number;
  height?: number;
  showText?: boolean;
  fontSize?: number;
  productName?: string;
  price?: number;
  showActions?: boolean;
}

export const BarcodeVisual: React.FC<BarcodeVisualProps> = ({
  value,
  width = 1.6,
  height = 40,
  showText = true,
  fontSize = 12,
  productName,
  price,
  showActions = false,
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!value || !svgRef.current) return;

    try {
      JsBarcode(svgRef.current, value.trim(), {
        format: 'CODE128',
        width,
        height,
        displayValue: showText,
        fontSize,
        font: 'monospace',
        fontOptions: 'bold',
        textMargin: 3,
        margin: 6,
        background: '#ffffff',
        lineColor: '#000000',
      });
    } catch (err) {
      console.warn('JsBarcode render warning for value:', value, err);
    }
  }, [value, width, height, showText, fontSize]);

  if (!value || !value.trim()) {
    return null;
  }

  const handlePrintSticker = () => {
    const printWindow = window.open('', '_blank', 'width=400,height=300');
    if (!printWindow) return;

    const svgHtml = svgRef.current?.outerHTML || '';
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Barcode Sticker - ${value}</title>
          <style>
            @page { size: 50mm 30mm; margin: 0; }
            body {
              font-family: sans-serif;
              margin: 0;
              padding: 6px;
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              text-align: center;
            }
            .name { font-size: 11px; font-weight: bold; margin-bottom: 2px; max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .price { font-size: 12px; font-weight: 800; color: #000; margin-top: 2px; }
            svg { max-width: 100%; height: auto; }
          </style>
        </head>
        <body>
          ${productName ? `<div class="name">${productName}</div>` : ''}
          ${svgHtml}
          ${price !== undefined ? `<div class="price">MRP: ₹${price.toFixed(2)}</div>` : ''}
          <script>
            window.onload = function() {
              window.print();
              setTimeout(function() { window.close(); }, 500);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleDownloadSvg = () => {
    if (!svgRef.current) return;
    const svgData = new XMLSerializer().serializeToString(svgRef.current);
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const svgUrl = URL.createObjectURL(svgBlob);
    const downloadLink = document.createElement('a');
    downloadLink.href = svgUrl;
    downloadLink.download = `barcode-${value}.svg`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    URL.revokeObjectURL(svgUrl);
  };

  return (
    <div className="flex flex-col items-center bg-white p-2 rounded-lg border border-slate-700 shadow-sm max-w-full overflow-hidden">
      {productName && (
        <div className="text-[11px] font-bold text-slate-900 truncate max-w-full text-center px-1">
          {productName}
        </div>
      )}
      <div className="overflow-x-auto max-w-full py-1">
        <svg ref={svgRef} className="block mx-auto" />
      </div>
      {price !== undefined && (
        <div className="text-xs font-bold text-emerald-800">
          ₹{price.toFixed(2)}
        </div>
      )}

      {showActions && (
        <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-200 w-full justify-center">
          <button
            type="button"
            onClick={handlePrintSticker}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white text-[11px] font-medium cursor-pointer transition-colors"
            title="Print Barcode Label"
          >
            <Printer className="w-3 h-3 text-cyan-400" />
            <span>Print Label</span>
          </button>
          <button
            type="button"
            onClick={handleDownloadSvg}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-800 text-[11px] font-medium cursor-pointer border border-slate-300 transition-colors"
            title="Download SVG"
          >
            <Download className="w-3 h-3 text-slate-600" />
            <span>SVG</span>
          </button>
        </div>
      )}
    </div>
  );
};
