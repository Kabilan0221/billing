import React, { useEffect, useState } from 'react';
import {
  Minus,
  Square,
  X,
  Database,
  WifiOff,
  User as UserIcon,
  Globe,
  Clock,
  LogOut,
  Sun,
  Moon,
} from 'lucide-react';
import { User } from '../types';
import { Language, translations } from '../i18n/translations';
import { useTheme } from '../context/ThemeContext';

interface DesktopHeaderProps {
  currentUser: User | null;
  currentLang: Language;
  onToggleLang: () => void;
  onLogout: () => void;
}

export const DesktopHeader: React.FC<DesktopHeaderProps> = ({
  currentUser,
  currentLang,
  onToggleLang,
  onLogout,
}) => {
  const { isLight, toggleTheme } = useTheme();
  const [timeStr, setTimeStr] = useState('');
  const t = translations[currentLang];

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleDateString(currentLang === 'ta' ? 'ta-IN' : 'en-US', {
          weekday: 'short',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [currentLang]);

  const handleWindowControl = (action: 'minimize' | 'maximize' | 'close') => {
    if (window.electronAPI) {
      window.electronAPI.invoke(`app:${action}`);
    }
  };

  return (
    <header
      id="desktop-titlebar"
      className={`h-11 border-b flex items-center justify-between px-3 select-none text-xs font-medium z-50 shrink-0 transition-colors duration-200 ${
        isLight
          ? 'bg-white border-slate-200 text-slate-700 shadow-sm'
          : 'bg-slate-900 border-slate-800 text-slate-300'
      }`}
    >
      {/* Left branding */}
      <div className="flex items-center gap-2.5">
        <div className="w-6 h-6 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-xs shadow-sm shadow-blue-500/30">
          TD
        </div>
        <span className={`font-bold tracking-tight ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
          {t.appName}
        </span>
        <div
          className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-semibold ${
            isLight
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : 'bg-emerald-950/70 border border-emerald-800/80 text-emerald-400'
          }`}
        >
          <WifiOff className="w-3 h-3 text-emerald-500" />
          <span>{t.offlineMode}</span>
        </div>
      </div>

      {/* Middle info */}
      <div className="hidden md:flex items-center gap-4 text-slate-400">
        <div className="flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span className={isLight ? 'text-slate-600 font-medium' : 'text-slate-400'}>{timeStr}</span>
        </div>
        <div className="flex items-center gap-1.5 text-[11px]">
          <Database className="w-3 h-3 text-blue-500" />
          <span className={isLight ? 'text-slate-500' : 'text-slate-400'}>Authoritative Local SQLite</span>
        </div>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-2.5">
        {/* Theme Toggle Button (White Mode / Dark Mode) */}
        <button
          id="theme-toggle-btn"
          onClick={toggleTheme}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-all cursor-pointer border text-xs font-semibold ${
            isLight
              ? 'bg-amber-50/80 border-amber-200 text-amber-900 hover:bg-amber-100'
              : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-750'
          }`}
          title={isLight ? 'Switch to Dark Mode' : 'Switch to White Mode'}
        >
          {isLight ? (
            <>
              <Sun className="w-3.5 h-3.5 text-amber-600" />
              <span>{t.lightMode || 'White Mode'}</span>
            </>
          ) : (
            <>
              <Moon className="w-3.5 h-3.5 text-blue-400" />
              <span>{t.darkMode || 'Dark Mode'}</span>
            </>
          )}
        </button>

        {/* Language selector */}
        <button
          id="lang-toggle-btn"
          onClick={onToggleLang}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-colors cursor-pointer border font-semibold ${
            isLight
              ? 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'
              : 'bg-slate-800/80 border-slate-700 hover:bg-slate-800 text-slate-300'
          }`}
          title="Switch Language (English / தமிழ்)"
        >
          <Globe className="w-3.5 h-3.5 text-blue-600" />
          <span>{currentLang === 'en' ? 'தமிழ்' : 'English'}</span>
        </button>

        {/* User profile & Logout */}
        {currentUser && (
          <div
            className={`flex items-center gap-2 pl-2 border-l ${
              isLight ? 'border-slate-200' : 'border-slate-800'
            }`}
          >
            <div
              className={`flex items-center gap-1.5 px-2 py-0.5 rounded-lg border ${
                isLight
                  ? 'bg-slate-100 border-slate-200 text-slate-800'
                  : 'bg-slate-800/80 border-slate-700 text-slate-200'
              }`}
            >
              <UserIcon className="w-3 h-3 text-blue-600" />
              <span className="truncate max-w-[110px] font-semibold">{currentUser.full_name}</span>
              <span
                className={`text-[10px] px-1 rounded font-mono ${
                  isLight ? 'bg-slate-200 text-slate-700' : 'bg-slate-700 text-slate-300'
                }`}
              >
                {currentUser.role}
              </span>
            </div>
            <button
              id="logout-btn"
              onClick={onLogout}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                isLight
                  ? 'hover:bg-red-50 text-red-600'
                  : 'hover:bg-red-950/60 hover:text-red-400 text-slate-400'
              }`}
              title={t.logout}
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Windows style control buttons */}
        <div
          className={`flex items-center ml-1 border-l ${
            isLight ? 'border-slate-200' : 'border-slate-800'
          }`}
        >
          <button
            id="win-minimize-btn"
            onClick={() => handleWindowControl('minimize')}
            className={`w-7 h-7 flex items-center justify-center rounded transition-colors ${
              isLight
                ? 'hover:bg-slate-100 text-slate-500 hover:text-slate-900'
                : 'hover:bg-slate-800 text-slate-400 hover:text-slate-100'
            }`}
            title="Minimize"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button
            id="win-maximize-btn"
            onClick={() => handleWindowControl('maximize')}
            className={`w-7 h-7 flex items-center justify-center rounded transition-colors ${
              isLight
                ? 'hover:bg-slate-100 text-slate-500 hover:text-slate-900'
                : 'hover:bg-slate-800 text-slate-400 hover:text-slate-100'
            }`}
            title="Maximize / Restore"
          >
            <Square className="w-3 h-3" />
          </button>
          <button
            id="win-close-btn"
            onClick={() => handleWindowControl('close')}
            className="w-7 h-7 flex items-center justify-center rounded hover:bg-red-600 text-slate-400 hover:text-white transition-colors"
            title="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
