import React from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Truck,
  QrCode,
  CreditCard,
  History,
  Users,
  Boxes,
  FileSpreadsheet,
  BarChart3,
  HardDriveDownload,
  Trash2,
  Settings as SettingsIcon,
  LogOut,
} from 'lucide-react';
import { Language, translations } from '../i18n/translations';
import { useTheme } from '../context/ThemeContext';

export type NavTab =
  | 'dashboard'
  | 'pos'
  | 'products'
  | 'inbound'
  | 'barcode'
  | 'payments'
  | 'history'
  | 'customers'
  | 'stock'
  | 'estimates_invoices'
  | 'reports'
  | 'backup'
  | 'data_management'
  | 'settings';

interface SidebarNavProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onLogout: () => void;
  currentLang: Language;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeTab,
  onSelectTab,
  onLogout,
  currentLang,
}) => {
  const { isLight } = useTheme();
  const t = translations[currentLang];

  const menuItems: Array<{
    id: NavTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    hotkey?: string;
  }> = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
    { id: 'pos', label: t.posBilling, icon: ShoppingCart, hotkey: 'F1' },
    { id: 'products', label: t.products, icon: Package, hotkey: 'F2' },
    { id: 'inbound', label: t.inbound, icon: Truck, hotkey: 'F9' },
    { id: 'barcode', label: t.barcodeHub, icon: QrCode, hotkey: 'F10' },
    { id: 'payments', label: t.payments, icon: CreditCard, hotkey: 'F3' },
    { id: 'history', label: t.billHistory, icon: History, hotkey: 'F4' },
    { id: 'customers', label: t.customers, icon: Users, hotkey: 'F5' },
    { id: 'stock', label: t.stock, icon: Boxes, hotkey: 'F6' },
    { id: 'estimates_invoices', label: t.estimateInvoice, icon: FileSpreadsheet, hotkey: 'F7' },
    { id: 'reports', label: t.reports, icon: BarChart3, hotkey: 'F8' },
    { id: 'backup', label: t.backupRestore, icon: HardDriveDownload },
    { id: 'data_management', label: t.dataManagement, icon: Trash2 },
    { id: 'settings', label: t.settings, icon: SettingsIcon },
  ];

  return (
    <aside
      id="desktop-sidebar"
      className={`w-64 border-r flex flex-col justify-between shrink-0 select-none overflow-y-auto transition-colors duration-200 ${
        isLight
          ? 'bg-white border-slate-200 text-slate-800'
          : 'bg-slate-900 border-slate-800 text-slate-100'
      }`}
    >
      <div className="p-3 space-y-1">
        <div
          className={`px-3 py-2 text-[11px] font-semibold uppercase tracking-wider ${
            isLight ? 'text-slate-400' : 'text-slate-500'
          }`}
        >
          {currentLang === 'ta' ? 'முதன்மை பட்டியல்' : 'Main Menu'}
        </div>
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-${item.id}`}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium transition-all cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20 font-semibold'
                  : isLight
                  ? 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-slate-100'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 ${
                    isActive
                      ? 'text-white'
                      : isLight
                      ? 'text-slate-500'
                      : 'text-slate-400'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>
              {item.hotkey && (
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                    isActive
                      ? 'bg-blue-700 text-blue-100'
                      : isLight
                      ? 'bg-slate-100 text-slate-500'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {item.hotkey}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className={`p-3 border-t ${isLight ? 'border-slate-200' : 'border-slate-800'}`}>
        <button
          id="sidebar-logout-btn"
          onClick={onLogout}
          className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
            isLight
              ? 'text-red-600 hover:bg-red-50 hover:text-red-700'
              : 'text-red-400 hover:bg-red-950/40 hover:text-red-300'
          }`}
        >
          <LogOut className="w-4 h-4" />
          <span>{t.logout}</span>
        </button>
      </div>
    </aside>
  );
};
