import React, { useState } from 'react';
import { X, Printer, Download, CheckCircle2 } from 'lucide-react';
import { PrintableReceiptData, thermalPrinterService } from '../printing/thermal-printer';
import { Language, translations } from '../i18n/translations';
import { useTheme } from '../context/ThemeContext';

interface ReceiptModalProps {
  receiptData: PrintableReceiptData | null;
  onClose: () => void;
  currentLang: Language;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  receiptData,
  onClose,
  currentLang,
}) => {
  const { isLight } = useTheme();
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>(
    receiptData?.settings.thermal_printer_width || '80mm'
  );
  const t = translations[currentLang];

  if (!receiptData) return null;

  const handlePrint = () => {
    thermalPrinterService.printViaBrowser({
      ...receiptData,
      settings: {
        ...receiptData.settings,
        thermal_printer_width: paperWidth,
      },
    });
  };

  const handleDownloadEscPos = () => {
    thermalPrinterService.downloadEscPosFile({
      ...receiptData,
      settings: {
        ...receiptData.settings,
        thermal_printer_width: paperWidth,
      },
    });
  };

  return (
    <div
      id="receipt-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        id="receipt-modal-card"
        className={`border rounded-xl max-w-lg w-full shadow-2xl flex flex-col max-h-[90vh] overflow-hidden ${
          isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-slate-900 border-slate-700 text-slate-100'
        }`}
      >
        {/* Header */}
        <div className={`flex items-center justify-between px-5 py-4 border-b ${
          isLight ? 'bg-slate-50 border-slate-200' : 'border-slate-800'
        }`}>
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              isLight ? 'bg-emerald-100 border border-emerald-200 text-emerald-600' : 'bg-emerald-900/50 border border-emerald-700/60 text-emerald-400'
            }`}>
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className={`text-base font-semibold ${isLight ? 'text-slate-900' : 'text-slate-100'}`}>
                {receiptData.title} #{receiptData.documentNumber}
              </h3>
              <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                Thermal Print Preview & ESC-POS Generator
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* 58mm / 80mm switch */}
            <div className={`flex rounded-lg p-0.5 text-xs ${isLight ? 'bg-slate-200' : 'bg-slate-800'}`}>
              <button
                id="btn-switch-58mm"
                onClick={() => setPaperWidth('58mm')}
                className={`px-2 py-1 rounded cursor-pointer ${
                  paperWidth === '58mm'
                    ? 'bg-blue-600 text-white font-medium'
                    : isLight ? 'text-slate-600 hover:text-slate-900' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                58mm
              </button>
              <button
                id="btn-switch-80mm"
                onClick={() => setPaperWidth('80mm')}
                className={`px-2 py-1 rounded cursor-pointer ${
                  paperWidth === '80mm'
                    ? 'bg-blue-600 text-white font-medium'
                    : isLight ? 'text-slate-600 hover:text-slate-900' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                80mm
              </button>
            </div>

            <button
              id="btn-close-receipt-modal"
              onClick={onClose}
              className={`p-1 rounded-lg cursor-pointer transition-colors ${
                isLight ? 'text-slate-400 hover:text-slate-700 hover:bg-slate-100' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Paper visual container */}
        <div className={`p-4 overflow-y-auto flex-1 flex justify-center ${
          isLight ? 'bg-slate-100' : 'bg-slate-950/60'
        }`}>
          <div
            id="receipt-paper"
            style={{ width: paperWidth === '80mm' ? '340px' : '260px' }}
            className="bg-white text-black font-mono text-[12px] leading-tight p-4 shadow-xl border border-slate-300 rounded-xs select-text"
          >
            <div className="text-center">
              <div className="font-bold text-sm uppercase tracking-wide">
                {receiptData.settings.business_name}
              </div>
              {receiptData.settings.business_tagline && (
                <div className="text-[11px] text-gray-600">
                  {receiptData.settings.business_tagline}
                </div>
              )}
              {receiptData.settings.business_address && (
                <div className="text-[10px] text-gray-700">
                  {receiptData.settings.business_address}
                </div>
              )}
              {receiptData.settings.business_phone && (
                <div className="text-[10px] text-gray-700">
                  Ph: {receiptData.settings.business_phone}
                </div>
              )}
            </div>

            <div className="border-t border-dashed border-gray-400 my-2" />

            <div className="text-center font-bold text-xs">
              *** {receiptData.title} ***
            </div>
            <div className="flex justify-between text-[11px] mt-1">
              <span>No: {receiptData.documentNumber}</span>
              <span>{receiptData.date}</span>
            </div>
            <div className="flex justify-between text-[11px]">
              <span>Time: {receiptData.time}</span>
              {receiptData.customerMobile && <span>Mob: {receiptData.customerMobile}</span>}
            </div>
            {receiptData.customerName && receiptData.customerName !== 'Walk-in Customer' && (
              <div className="text-[11px]">Cust: {receiptData.customerName}</div>
            )}

            <div className="border-t border-dashed border-gray-400 my-2" />

            <table className="w-full text-left text-[11px] border-collapse">
              <thead>
                <tr className="border-b border-dashed border-gray-400">
                  <th className="py-1">Item</th>
                  <th className="py-1 text-right">Qty</th>
                  <th className="py-1 text-right">Rate</th>
                  <th className="py-1 text-right">Amt</th>
                </tr>
              </thead>
              <tbody>
                {receiptData.items.map((item, i) => (
                  <tr key={i} className="border-b border-gray-100">
                    <td className="py-1 pr-1 truncate max-w-[120px]">{item.name}</td>
                    <td className="py-1 text-right">{item.quantity}</td>
                    <td className="py-1 text-right">{item.rate.toFixed(2)}</td>
                    <td className="py-1 text-right font-medium">{item.amount.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="border-t border-dashed border-gray-400 my-2" />

            <div className="text-right text-[11px] space-y-0.5">
              <div>
                Subtotal: {receiptData.settings.currency_symbol}{' '}
                {receiptData.subtotal.toFixed(2)}
              </div>
              {receiptData.discount > 0 && (
                <div className="text-red-600">
                  Discount: -{receiptData.settings.currency_symbol}{' '}
                  {receiptData.discount.toFixed(2)}
                </div>
              )}
              <div className="font-bold text-sm border-t border-b border-gray-400 py-1 my-1">
                TOTAL: {receiptData.settings.currency_symbol}{' '}
                {receiptData.total.toFixed(2)}
              </div>
              {receiptData.paymentMethod && (
                <div>Payment: {receiptData.paymentMethod}</div>
              )}
              {receiptData.cashTendered !== undefined && receiptData.cashTendered > 0 && (
                <div>
                  Paid: {receiptData.settings.currency_symbol}{' '}
                  {receiptData.cashTendered.toFixed(2)}
                </div>
              )}
              {receiptData.changeDue !== undefined && receiptData.changeDue > 0 && (
                <div className="font-semibold text-emerald-700">
                  Change: {receiptData.settings.currency_symbol}{' '}
                  {receiptData.changeDue.toFixed(2)}
                </div>
              )}
            </div>

            <div className="border-t border-dashed border-gray-400 my-2" />

            <div className="text-center text-[10px] text-gray-600 space-y-0.5">
              <div>{receiptData.settings.receipt_footer}</div>
              <div className="text-[9px] text-gray-400">Offline Desktop Billing (SQLite)</div>
            </div>
          </div>
        </div>

        {/* Action buttons footer */}
        <div className={`flex items-center justify-between px-5 py-3 border-t ${
          isLight ? 'bg-slate-50 border-slate-200' : 'bg-slate-900 border-slate-800'
        }`}>
          <button
            id="btn-download-escpos"
            onClick={handleDownloadEscPos}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium cursor-pointer transition-colors border ${
              isLight
                ? 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
            }`}
            title="Download raw ESC/POS binary bytes for direct thermal printer port"
          >
            <Download className="w-4 h-4 text-blue-600 dark:text-cyan-400" />
            <span>Download ESC/POS (.bin)</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              id="btn-close-preview"
              onClick={onClose}
              className={`px-4 py-2 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
                isLight ? 'text-slate-600 hover:bg-slate-200' : 'text-slate-400 hover:bg-slate-800'
              }`}
            >
              {t.close}
            </button>
            <button
              id="btn-print-receipt"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer shadow-md transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>{t.print}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
