import React, { useState, useEffect } from 'react';
import { User } from './types';
import { Language } from './i18n/translations';
import { DesktopHeader } from './components/DesktopHeader';
import { SidebarNav, NavTab } from './components/SidebarNav';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { PosBillingPage } from './pages/PosBillingPage';
import { ProductsPage } from './pages/ProductsPage';
import { PaymentsPage } from './pages/PaymentsPage';
import { BillHistoryPage } from './pages/BillHistoryPage';
import { CustomersPage } from './pages/CustomersPage';
import { StockPage } from './pages/StockPage';
import { EstimateInvoicePage } from './pages/EstimateInvoicePage';
import { ReportsPage } from './pages/ReportsPage';
import { BackupRestorePage } from './pages/BackupRestorePage';
import { DataManagementPage } from './pages/DataManagementPage';
import { SettingsPage } from './pages/SettingsPage';
import { ipcClient } from './services/ipc-client';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('billing_current_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  const [currentLang, setCurrentLang] = useState<Language>(() => {
    const saved = localStorage.getItem('billing_language');
    return (saved as Language) || 'en';
  });

  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');

  // Sync settings language
  useEffect(() => {
    ipcClient.getSettings().then((s) => {
      if (s?.language) {
        setCurrentLang(s.language as Language);
      }
    }).catch(() => {});
  }, []);

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('billing_current_user', JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('billing_current_user');
  };

  const handleToggleLang = () => {
    const nextLang: Language = currentLang === 'en' ? 'ta' : 'en';
    setCurrentLang(nextLang);
    localStorage.setItem('billing_language', nextLang);
    ipcClient.updateSettings({ language: nextLang }).catch(() => {});
  };

  // Keyboard shortcut listener for F1 - F8 tabs
  useEffect(() => {
    const handleGlobalShortcuts = (e: KeyboardEvent) => {
      if (!currentUser) return;
      if (e.key === 'F1') {
        e.preventDefault();
        setActiveTab('pos');
      } else if (e.key === 'F2') {
        e.preventDefault();
        setActiveTab('products');
      } else if (e.key === 'F3') {
        e.preventDefault();
        setActiveTab('payments');
      } else if (e.key === 'F4') {
        e.preventDefault();
        setActiveTab('history');
      } else if (e.key === 'F5') {
        e.preventDefault();
        setActiveTab('customers');
      } else if (e.key === 'F6') {
        e.preventDefault();
        setActiveTab('stock');
      } else if (e.key === 'F7') {
        e.preventDefault();
        setActiveTab('estimates_invoices');
      } else if (e.key === 'F8') {
        e.preventDefault();
        setActiveTab('reports');
      }
    };

    window.addEventListener('keydown', handleGlobalShortcuts);
    return () => window.removeEventListener('keydown', handleGlobalShortcuts);
  }, [currentUser]);

  if (!currentUser) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} currentLang={currentLang} />;
  }

  return (
    <div id="desktop-app-root" className="h-screen w-screen flex flex-col bg-slate-950 text-slate-100 overflow-hidden select-none font-sans">
      {/* Desktop Window Titlebar */}
      <DesktopHeader
        currentUser={currentUser}
        currentLang={currentLang}
        onToggleLang={handleToggleLang}
        onLogout={handleLogout}
      />

      {/* Main Workspace: Sidebar + Dynamic Workspace Body */}
      <div className="flex-1 flex overflow-hidden">
        <SidebarNav
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          onLogout={handleLogout}
          currentLang={currentLang}
        />

        <main id="main-content-area" className="flex-1 overflow-y-auto bg-slate-950 select-text">
          {activeTab === 'dashboard' && (
            <DashboardPage onNavigate={setActiveTab} currentLang={currentLang} />
          )}
          {activeTab === 'pos' && <PosBillingPage currentLang={currentLang} />}
          {activeTab === 'products' && <ProductsPage currentLang={currentLang} />}
          {activeTab === 'payments' && <PaymentsPage currentLang={currentLang} />}
          {activeTab === 'history' && <BillHistoryPage currentLang={currentLang} />}
          {activeTab === 'customers' && <CustomersPage currentLang={currentLang} />}
          {activeTab === 'stock' && <StockPage currentLang={currentLang} />}
          {activeTab === 'estimates_invoices' && (
            <EstimateInvoicePage currentLang={currentLang} />
          )}
          {activeTab === 'reports' && <ReportsPage currentLang={currentLang} />}
          {activeTab === 'backup' && <BackupRestorePage currentLang={currentLang} />}
          {activeTab === 'data_management' && (
            <DataManagementPage currentLang={currentLang} />
          )}
          {activeTab === 'settings' && (
            <SettingsPage
              currentLang={currentLang}
              onLanguageChanged={(l) => setCurrentLang(l)}
            />
          )}
        </main>
      </div>
    </div>
  );
}
