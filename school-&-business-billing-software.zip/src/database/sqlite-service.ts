// @ts-ignore
import initSqlJsAsm from 'sql.js/dist/sql-asm.js';
import initSqlJsWasm, { Database, SqlJsStatic } from 'sql.js';
import bcrypt from 'bcryptjs';
import {
  AppSettings,
  Bill,
  BillItem,
  Category,
  Customer,
  DashboardStats,
  DataManagementImpact,
  Estimate,
  EstimateItem,
  Invoice,
  InvoiceItem,
  PaymentMethod,
  PaymentRecord,
  Product,
  SalesReportSummary,
  StockTransaction,
  User,
} from '../types';

const DB_STORAGE_KEY = 'tdw_sqlite_db_binary';
const DB_VERSION = 1;

class SQLiteDatabaseService {
  private db: Database | null = null;
  private sqlEngine: SqlJsStatic | null = null;
  private isInitialized = false;
  private initPromise: Promise<void> | null = null;

  public async init(): Promise<void> {
    if (this.isInitialized && this.db) return;
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      try {
        this.sqlEngine = await this.loadSqlEngine();
        const SQL = this.sqlEngine;

        // Try to load existing database from storage
        const savedData = this.loadFromStorage();
        if (savedData) {
          try {
            this.db = new SQL.Database(savedData);
          } catch (err) {
            console.warn('Corrupted database binary, creating new:', err);
            this.db = new SQL.Database();
          }
        } else {
          this.db = new SQL.Database();
        }

        this.applySchema();
        await this.seedDefaults();
        this.saveToStorage();
        this.isInitialized = true;
      } catch (error) {
        console.error('Failed to initialize SQLite database:', error);
        throw error;
      }
    })();

    return this.initPromise;
  }

  private async loadSqlEngine(): Promise<SqlJsStatic> {
    // Strategy 1: Pure JavaScript ASM.JS build
    // This is 100% self-contained in JS, requiring no external .wasm fetch or special MIME types.
    // Prevents "Incorrect response MIME type" and "WebAssembly.instantiate expected magic word" errors in iframes/web previews.
    try {
      const initFn =
        typeof initSqlJsAsm === 'function'
          ? initSqlJsAsm
          : (initSqlJsAsm as any)?.default;
      if (typeof initFn === 'function') {
        const SQL = await initFn();
        if (SQL && typeof SQL.Database === 'function') {
          console.info('SQLite engine loaded successfully via self-contained JS (asm.js)');
          return SQL as SqlJsStatic;
        }
      }
    } catch (asmErr) {
      console.warn('asm.js SQLite loader encountered error, attempting WASM fallback:', asmErr);
    }

    // Strategy 2: WebAssembly with root path fallback
    try {
      const initWasmFn =
        typeof initSqlJsWasm === 'function'
          ? initSqlJsWasm
          : (initSqlJsWasm as any)?.default;
      const SQL = await initWasmFn({
        locateFile: (file: string) => `/${file}`,
      });
      console.info('SQLite engine loaded via WebAssembly');
      return SQL as SqlJsStatic;
    } catch (wasmErr) {
      console.error('Both asm.js and wasm SQLite initialization strategies failed:', wasmErr);
      throw wasmErr;
    }
  }

  private getNativeFsPath(): { fs: any; path: string } | null {
    if (typeof window === 'undefined' && typeof process !== 'undefined' && (process as any).versions?.node) {
      try {
        const fsModule = eval('require("fs")');
        const pathModule = eval('require("path")');
        const osModule = eval('require("os")');
        const baseDir =
          process.env.APPDATA ||
          (process.env.HOME ? pathModule.join(process.env.HOME, '.config') : osModule.homedir());
        const dir = pathModule.join(baseDir, 'TinyDeamonWorksBilling');
        if (!fsModule.existsSync(dir)) {
          fsModule.mkdirSync(dir, { recursive: true });
        }
        return { fs: fsModule, path: pathModule.join(dir, 'billing_offline.sqlite') };
      } catch (e) {
        return null;
      }
    }
    return null;
  }

  private loadFromStorage(): Uint8Array | null {
    try {
      const nativeFs = this.getNativeFsPath();
      if (nativeFs && nativeFs.fs.existsSync(nativeFs.path)) {
        const fileBuffer = nativeFs.fs.readFileSync(nativeFs.path);
        return new Uint8Array(fileBuffer);
      }

      if (typeof window === 'undefined' || !window.localStorage) return null;
      const b64 = localStorage.getItem(DB_STORAGE_KEY);
      if (!b64) return null;
      const binaryString = window.atob(b64);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      return bytes;
    } catch (e) {
      console.error('Error loading SQLite from storage:', e);
      return null;
    }
  }

  public saveToStorage(): void {
    if (!this.db) return;
    try {
      const data = this.db.export();

      const nativeFs = this.getNativeFsPath();
      if (nativeFs) {
        nativeFs.fs.writeFileSync(nativeFs.path, Buffer.from(data));
        return;
      }

      if (typeof window !== 'undefined' && window.localStorage) {
        let binary = '';
        const len = data.byteLength;
        for (let i = 0; i < len; i++) {
          binary += String.fromCharCode(data[i]);
        }
        const b64 = window.btoa(binary);
        localStorage.setItem(DB_STORAGE_KEY, b64);
      }
    } catch (e) {
      console.error('Failed to persist SQLite database:', e);
    }
  }

  private applySchema(): void {
    if (!this.db) throw new Error('Database not ready');

    this.db.run('PRAGMA foreign_keys = ON;');

    this.db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'CASHIER',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_login DATETIME
      );

      CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category_id INTEGER,
        barcode TEXT UNIQUE NOT NULL,
        purchase_price REAL NOT NULL DEFAULT 0.0,
        selling_price REAL NOT NULL,
        opening_stock INTEGER NOT NULL DEFAULT 0,
        current_stock INTEGER NOT NULL DEFAULT 0,
        min_stock_level INTEGER NOT NULL DEFAULT 5,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
      );

      CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        mobile TEXT UNIQUE NOT NULL,
        address TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS bills (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_number TEXT UNIQUE NOT NULL,
        customer_id INTEGER,
        customer_name TEXT,
        customer_mobile TEXT,
        subtotal REAL NOT NULL,
        discount REAL NOT NULL DEFAULT 0.0,
        total_amount REAL NOT NULL,
        payment_method TEXT NOT NULL,
        payment_status TEXT NOT NULL DEFAULT 'PAID',
        cash_tendered REAL,
        change_due REAL,
        split_details TEXT,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL
      );

      CREATE TABLE IF NOT EXISTS bill_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        barcode TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        rate REAL NOT NULL,
        amount REAL NOT NULL,
        FOREIGN KEY (bill_id) REFERENCES bills(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id)
      );

      CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_id INTEGER,
        invoice_id INTEGER,
        payment_method TEXT NOT NULL,
        amount REAL NOT NULL,
        cash_tendered REAL,
        change_due REAL,
        split_details TEXT,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (bill_id) REFERENCES bills(id) ON DELETE CASCADE,
        FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS stock_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        transaction_type TEXT NOT NULL,
        quantity_change INTEGER NOT NULL,
        previous_stock INTEGER NOT NULL,
        new_stock INTEGER NOT NULL,
        reference_id TEXT,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS estimates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        estimate_number TEXT UNIQUE NOT NULL,
        customer_name TEXT,
        customer_mobile TEXT,
        customer_address TEXT,
        subtotal REAL NOT NULL,
        discount REAL NOT NULL DEFAULT 0.0,
        total_amount REAL NOT NULL,
        status TEXT NOT NULL DEFAULT 'SAVED',
        notes TEXT,
        converted_invoice_id INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS estimate_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        estimate_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        barcode TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        rate REAL NOT NULL,
        amount REAL NOT NULL,
        FOREIGN KEY (estimate_id) REFERENCES estimates(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id)
      );

      CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_number TEXT UNIQUE NOT NULL,
        estimate_id INTEGER,
        customer_name TEXT,
        customer_mobile TEXT,
        customer_address TEXT,
        subtotal REAL NOT NULL,
        discount REAL NOT NULL DEFAULT 0.0,
        total_amount REAL NOT NULL,
        payment_method TEXT NOT NULL,
        payment_status TEXT NOT NULL DEFAULT 'PAID',
        cash_tendered REAL,
        change_due REAL,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (estimate_id) REFERENCES estimates(id) ON DELETE SET NULL
      );

      CREATE TABLE IF NOT EXISTS invoice_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        barcode TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        rate REAL NOT NULL,
        amount REAL NOT NULL,
        FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id)
      );

      CREATE TABLE IF NOT EXISTS backups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        file_name TEXT NOT NULL,
        file_path TEXT NOT NULL,
        file_size INTEGER NOT NULL,
        record_count INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      );

      -- Indexes for fast offline POS lookup and reporting
      CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
      CREATE INDEX IF NOT EXISTS idx_products_name ON products(name);
      CREATE INDEX IF NOT EXISTS idx_bills_number ON bills(bill_number);
      CREATE INDEX IF NOT EXISTS idx_bills_created_at ON bills(created_at);
      CREATE INDEX IF NOT EXISTS idx_customers_mobile ON customers(mobile);
      CREATE INDEX IF NOT EXISTS idx_estimates_number ON estimates(estimate_number);
      CREATE INDEX IF NOT EXISTS idx_invoices_number ON invoices(invoice_number);
      CREATE INDEX IF NOT EXISTS idx_stock_product ON stock_transactions(product_id);
    `);
  }

  private async seedDefaults(): Promise<void> {
    if (!this.db) return;

    // Check if users exist
    const userRes = this.db.exec('SELECT COUNT(*) as count FROM users');
    const userCount = userRes.length > 0 ? (userRes[0].values[0][0] as number) : 0;

    if (userCount === 0) {
      // Seed default admin and cashier with secure bcrypt hashing
      const adminHash = bcrypt.hashSync('admin123', 10);
      const cashierHash = bcrypt.hashSync('cashier123', 10);

      this.db.run(
        'INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)',
        ['admin', adminHash, 'System Administrator', 'ADMIN']
      );
      this.db.run(
        'INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)',
        ['cashier', cashierHash, 'Main Billing Cashier', 'CASHIER']
      );
    }

    // Seed categories if empty
    const catRes = this.db.exec('SELECT COUNT(*) as count FROM categories');
    const catCount = catRes.length > 0 ? (catRes[0].values[0][0] as number) : 0;
    if (catCount === 0) {
      const defaultCats = [
        ['Stationery & Books', 'Notebooks, pens, registers, diaries'],
        ['Uniforms & Wear', 'School uniforms, ties, belts, badges'],
        ['Electronics & Accessories', 'Calculators, USB, cables, adapters'],
        ['Sports & Games', 'Sports kits, balls, racquets'],
        ['Snacks & Beverages', 'Water bottles, juice, biscuits, snacks'],
        ['General Supplies', 'Daily office and school requirements'],
      ];
      for (const [name, desc] of defaultCats) {
        this.db.run('INSERT INTO categories (name, description) VALUES (?, ?)', [name, desc]);
      }
    }

    // Seed sample products if empty
    const prodRes = this.db.exec('SELECT COUNT(*) as count FROM products');
    const prodCount = prodRes.length > 0 ? (prodRes[0].values[0][0] as number) : 0;
    if (prodCount === 0) {
      const sampleProducts = [
        { name: 'Classmate Notebook 192 Pgs', category_id: 1, barcode: 'NB101', purchase: 45, sell: 60, stock: 150, min: 20 },
        { name: 'Reynolds 045 Ball Pen (Blue)', category_id: 1, barcode: 'PEN001', purchase: 7, sell: 10, stock: 500, min: 50 },
        { name: 'Camlin Geometry Box Deluxe', category_id: 1, barcode: 'GEO202', purchase: 90, sell: 130, stock: 45, min: 10 },
        { name: 'School Water Bottle 750ml', category_id: 5, barcode: 'WB001', purchase: 110, sell: 160, stock: 4, min: 10 }, // low stock
        { name: 'School Backpack Standard', category_id: 2, barcode: 'BAG303', purchase: 450, sell: 699, stock: 30, min: 5 },
        { name: 'Oxford English Dictionary Mini', category_id: 1, barcode: 'DIC404', purchase: 160, sell: 220, stock: 18, min: 5 },
        { name: 'A4 Copier Paper 75GSM 500S', category_id: 1, barcode: 'A4750', purchase: 240, sell: 320, stock: 80, min: 15 },
        { name: 'School Tie & Belt Set (M)', category_id: 2, barcode: 'UNF01', purchase: 85, sell: 140, stock: 3, min: 10 }, // low stock
        { name: 'Casio Scientific Calculator fx-82MS', category_id: 3, barcode: 'CAL505', purchase: 520, sell: 675, stock: 12, min: 5 },
        { name: 'Fruit Juice Box 200ml', category_id: 5, barcode: 'JUC002', purchase: 22, sell: 30, stock: 95, min: 20 },
      ];

      for (const p of sampleProducts) {
        this.db.run(
          `INSERT INTO products (name, category_id, barcode, purchase_price, selling_price, opening_stock, current_stock, min_stock_level)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [p.name, p.category_id, p.barcode, p.purchase, p.sell, p.stock, p.stock, p.min]
        );
        // Record initial opening stock transaction
        const lastIdRes = this.db.exec('SELECT last_insert_rowid() as id');
        const prodId = lastIdRes[0].values[0][0] as number;
        this.db.run(
          `INSERT INTO stock_transactions (product_id, transaction_type, quantity_change, previous_stock, new_stock, notes)
           VALUES (?, 'OPENING', ?, 0, ?, 'Initial opening stock')`,
          [prodId, p.stock, p.stock]
        );
      }
    }

    // Seed default settings if empty
    const setRes = this.db.exec('SELECT COUNT(*) as count FROM settings');
    const setCount = setRes.length > 0 ? (setRes[0].values[0][0] as number) : 0;
    if (setCount === 0) {
      const defaultSettings: Record<string, string> = {
        business_name: 'TINY DEAMON WORKS',
        business_tagline: 'School & Business Billing Systems',
        business_address: '14, Anna Salai, Main Road, Chennai - 600002',
        business_phone: '+91 98765 43210',
        business_email: 'tinydeamonworks@gmail.com',
        receipt_footer: 'Thank you for your business! Visit Again!',
        currency_symbol: '₹',
        thermal_printer_width: '80mm',
        auto_print_receipt: 'true',
        low_stock_warning_threshold: '10',
        language: 'en',
      };
      for (const [k, v] of Object.entries(defaultSettings)) {
        this.db.run('INSERT INTO settings (key, value) VALUES (?, ?)', [k, v]);
      }
    }
  }

  // --- QUERY HELPERS ---
  public query<T = any>(sql: string, params: any[] = []): T[] {
    if (!this.db) throw new Error('Database not initialized');
    const stmt = this.db.prepare(sql);
    stmt.bind(params);
    const results: T[] = [];
    while (stmt.step()) {
      results.push(stmt.getAsObject() as T);
    }
    stmt.free();
    return results;
  }

  public queryOne<T = any>(sql: string, params: any[] = []): T | null {
    const list = this.query<T>(sql, params);
    return list.length > 0 ? list[0] : null;
  }

  public run(sql: string, params: any[] = []): { lastInsertRowId: number; changes: number } {
    if (!this.db) throw new Error('Database not initialized');
    this.db.run(sql, params);
    const lastId = this.queryOne<{ id: number }>('SELECT last_insert_rowid() as id')?.id || 0;
    const changes = this.queryOne<{ c: number }>('SELECT changes() as c')?.c || 0;
    this.saveToStorage();
    return { lastInsertRowId: lastId, changes };
  }

  public transaction<T>(action: () => T): T {
    if (!this.db) throw new Error('Database not initialized');
    this.db.run('BEGIN TRANSACTION;');
    try {
      const result = action();
      this.db.run('COMMIT;');
      this.saveToStorage();
      return result;
    } catch (err) {
      this.db.run('ROLLBACK;');
      console.error('Transaction rolled back due to error:', err);
      throw err;
    }
  }

  // --- AUTH METHODS ---
  public authenticate(username: string, plainPassword: string): User | null {
    const user = this.queryOne<User>('SELECT * FROM users WHERE username = ?', [username.trim()]);
    if (!user) return null;

    const matches = bcrypt.compareSync(plainPassword, user.password_hash);
    if (!matches) return null;

    // Update last login
    this.run("UPDATE users SET last_login = datetime('now', 'localtime') WHERE id = ?", [user.id]);
    return user;
  }

  // --- PRODUCTS & CATEGORIES ---
  public getCategories(): Category[] {
    let list = this.query<Category>('SELECT * FROM categories ORDER BY name ASC');
    if (list.length === 0) {
      this.ensureDefaultCategories();
      list = this.query<Category>('SELECT * FROM categories ORDER BY name ASC');
    }
    return list;
  }

  public ensureDefaultCategories(): void {
    const defaultCats = [
      ['Stationery & Books', 'Notebooks, pens, registers, diaries'],
      ['Uniforms & Wear', 'School uniforms, ties, belts, badges'],
      ['Electronics & Accessories', 'Calculators, USB, cables, adapters'],
      ['Sports & Games', 'Sports kits, balls, racquets'],
      ['Snacks & Beverages', 'Water bottles, juice, biscuits, snacks'],
      ['General Supplies', 'Daily office and school requirements'],
    ];
    for (const [name, desc] of defaultCats) {
      const exists = this.queryOne<{ id: number }>('SELECT id FROM categories WHERE name = ?', [name]);
      if (!exists) {
        this.run('INSERT INTO categories (name, description) VALUES (?, ?)', [name, desc]);
      }
    }
  }

  public addCategory(name: string, description: string = ''): Category {
    const { lastInsertRowId } = this.run(
      'INSERT INTO categories (name, description) VALUES (?, ?)',
      [name.trim(), description.trim()]
    );
    return this.queryOne<Category>('SELECT * FROM categories WHERE id = ?', [lastInsertRowId])!;
  }

  public getProducts(search: string | { search?: string } = '', categoryId?: number): Product[] {
    let sql = `
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE 1=1
    `;
    const params: any[] = [];
    const searchStr = typeof search === 'string' ? search.trim() : (typeof (search as any)?.search === 'string' ? (search as any).search.trim() : '');

    if (searchStr) {
      sql += ' AND (p.name LIKE ? OR p.barcode LIKE ?)';
      params.push(`%${searchStr}%`, `%${searchStr}%`);
    }

    if (categoryId) {
      sql += ' AND p.category_id = ?';
      params.push(categoryId);
    }

    sql += ' ORDER BY p.name ASC';
    return this.query<Product>(sql, params);
  }

  public getProductByBarcode(barcode: string): Product | null {
    return this.queryOne<Product>(
      `SELECT p.*, c.name as category_name 
       FROM products p 
       LEFT JOIN categories c ON p.category_id = c.id 
       WHERE LOWER(p.barcode) = LOWER(?)`,
      [barcode.trim()]
    );
  }

  public getProductById(id: number): Product | null {
    return this.queryOne<Product>(
      `SELECT p.*, c.name as category_name 
       FROM products p 
       LEFT JOIN categories c ON p.category_id = c.id 
       WHERE p.id = ?`,
      [id]
    );
  }

  public saveProduct(prod: Partial<Product>): Product {
    if (prod.id) {
      // Update
      this.run(
        `UPDATE products 
         SET name = ?, category_id = ?, barcode = ?, purchase_price = ?, selling_price = ?, 
             min_stock_level = ?, updated_at = datetime('now', 'localtime')
         WHERE id = ?`,
        [
          prod.name,
          prod.category_id || null,
          prod.barcode?.trim(),
          prod.purchase_price ?? 0,
          prod.selling_price,
          prod.min_stock_level ?? 5,
          prod.id,
        ]
      );
      return this.getProductById(prod.id)!;
    } else {
      // Create new
      return this.transaction(() => {
        const openingStock = prod.opening_stock ?? 0;
        const { lastInsertRowId } = this.run(
          `INSERT INTO products (name, category_id, barcode, purchase_price, selling_price, opening_stock, current_stock, min_stock_level)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            prod.name,
            prod.category_id || null,
            prod.barcode?.trim(),
            prod.purchase_price ?? 0,
            prod.selling_price,
            openingStock,
            openingStock,
            prod.min_stock_level ?? 5,
          ]
        );

        if (openingStock > 0) {
          this.run(
            `INSERT INTO stock_transactions (product_id, transaction_type, quantity_change, previous_stock, new_stock, notes)
             VALUES (?, 'OPENING', ?, 0, ?, 'Opening Stock')`,
            [lastInsertRowId, openingStock, openingStock]
          );
        }

        return this.getProductById(lastInsertRowId)!;
      });
    }
  }

  public deleteProduct(id: number): void {
    this.run('DELETE FROM products WHERE id = ?', [id]);
  }

  // --- BULK PRODUCT IMPORT ---
  public bulkImportProducts(
    rows: Array<{
      name: string;
      category?: string;
      barcode: string;
      purchase_price: number;
      selling_price: number;
      opening_stock: number;
      min_stock_level: number;
    }>
  ): { imported: number; errors: string[] } {
    const errors: string[] = [];
    let imported = 0;

    // Pre-fetch all existing barcodes and categories
    const existingProducts = this.query<{ barcode: string }>('SELECT barcode FROM products');
    const existingBarcodes = new Set(existingProducts.map((p) => p.barcode.toLowerCase()));

    const categories = this.getCategories();
    const categoryMap = new Map<string, number>();
    for (const c of categories) {
      categoryMap.set(c.name.toLowerCase(), c.id);
    }

    this.transaction(() => {
      for (let idx = 0; idx < rows.length; idx++) {
        const row = rows[idx];
        const rowNum = idx + 2;

        if (!row.name || !row.name.trim()) {
          errors.push(`Row ${rowNum}: Product Name is missing.`);
          continue;
        }

        const barcode = (row.barcode || '').toString().trim();
        if (!barcode) {
          errors.push(`Row ${rowNum}: Barcode is missing for '${row.name}'.`);
          continue;
        }

        if (existingBarcodes.has(barcode.toLowerCase())) {
          errors.push(`Row ${rowNum}: Duplicate barcode '${barcode}' for '${row.name}'. Already in database.`);
          continue;
        }

        if (isNaN(row.selling_price) || row.selling_price < 0) {
          errors.push(`Row ${rowNum}: Invalid selling price for '${row.name}'.`);
          continue;
        }

        let categoryId: number | null = null;
        if (row.category && row.category.trim()) {
          const catNameLower = row.category.trim().toLowerCase();
          if (categoryMap.has(catNameLower)) {
            categoryId = categoryMap.get(catNameLower)!;
          } else {
            // Auto create category
            const newCat = this.addCategory(row.category.trim());
            categoryId = newCat.id;
            categoryMap.set(catNameLower, newCat.id);
          }
        }

        const purchasePrice = Number(row.purchase_price) || 0;
        const sellingPrice = Number(row.selling_price);
        const stock = Math.max(0, parseInt(String(row.opening_stock || 0), 10) || 0);
        const minStock = Math.max(1, parseInt(String(row.min_stock_level || 5), 10) || 5);

        const { lastInsertRowId } = this.run(
          `INSERT INTO products (name, category_id, barcode, purchase_price, selling_price, opening_stock, current_stock, min_stock_level)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [row.name.trim(), categoryId, barcode, purchasePrice, sellingPrice, stock, stock, minStock]
        );

        if (stock > 0) {
          this.run(
            `INSERT INTO stock_transactions (product_id, transaction_type, quantity_change, previous_stock, new_stock, notes)
             VALUES (?, 'OPENING', ?, 0, ?, 'Bulk Import Initial Stock')`,
            [lastInsertRowId, stock, stock]
          );
        }

        existingBarcodes.add(barcode.toLowerCase());
        imported++;
      }
    });

    return { imported, errors };
  }

  // --- CUSTOMERS ---
  public getCustomers(search: string | { search?: string } = ''): Customer[] {
    let sql = `
      SELECT c.*, 
             COUNT(b.id) as total_bills,
             COALESCE(SUM(b.total_amount), 0) as total_spent
      FROM customers c
      LEFT JOIN bills b ON c.id = b.customer_id
      WHERE 1=1
    `;
    const params: any[] = [];
    const searchStr = typeof search === 'string' ? search.trim() : (typeof (search as any)?.search === 'string' ? (search as any).search.trim() : '');
    if (searchStr) {
      sql += ' AND (c.name LIKE ? OR c.mobile LIKE ?)';
      params.push(`%${searchStr}%`, `%${searchStr}%`);
    }
    sql += ' GROUP BY c.id ORDER BY c.name ASC';
    return this.query<Customer>(sql, params);
  }

  public getOrCreateCustomer(name: string, mobile: string, address: string = ''): Customer {
    const cleanMobile = mobile.trim();
    if (!cleanMobile) throw new Error('Mobile number is required');

    const existing = this.queryOne<Customer>('SELECT * FROM customers WHERE mobile = ?', [cleanMobile]);
    if (existing) {
      if (name && name !== existing.name) {
        this.run('UPDATE customers SET name = ? WHERE id = ?', [name.trim(), existing.id]);
      }
      return this.queryOne<Customer>('SELECT * FROM customers WHERE id = ?', [existing.id])!;
    }

    const { lastInsertRowId } = this.run(
      'INSERT INTO customers (name, mobile, address) VALUES (?, ?, ?)',
      [name.trim() || 'Valued Customer', cleanMobile, address.trim()]
    );
    return this.queryOne<Customer>('SELECT * FROM customers WHERE id = ?', [lastInsertRowId])!;
  }

  // --- POS BILLING & COMPLETED SALE TRANSACTION ---
  public createBillTransaction(params: {
    customerName?: string;
    customerMobile?: string;
    customerAddress?: string;
    items: Array<{ product_id: number; quantity: number; rate: number }>;
    discount: number;
    paymentMethod: PaymentMethod;
    cashTendered?: number;
    changeDue?: number;
    splitDetails?: string;
    notes?: string;
  }): Bill {
    if (!params.items || params.items.length === 0) {
      throw new Error('Cannot create bill with 0 items');
    }

    return this.transaction(() => {
      // 1. Resolve Customer
      let customerId: number | undefined = undefined;
      if (params.customerMobile && params.customerMobile.trim()) {
        const cust = this.getOrCreateCustomer(
          params.customerName || 'Customer',
          params.customerMobile,
          params.customerAddress || ''
        );
        customerId = cust.id;
      }

      // 2. Generate unique Bill Number (e.g., BILL-YYYYMMDD-XXXX)
      const datePrefix = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const countRes = this.queryOne<{ c: number }>(
        "SELECT COUNT(*) as c FROM bills WHERE bill_number LIKE 'BILL-' || ? || '-%'",
        [datePrefix]
      );
      const nextSeq = (countRes?.c || 0) + 1;
      const billNumber = `BILL-${datePrefix}-${String(nextSeq).padStart(4, '0')}`;

      // 3. Calculate Totals and Validate Products
      let subtotal = 0;
      const verifiedItems: Array<{
        product: Product;
        quantity: number;
        rate: number;
        amount: number;
      }> = [];

      for (const itm of params.items) {
        const prod = this.getProductById(itm.product_id);
        if (!prod) throw new Error(`Product with ID ${itm.product_id} not found.`);
        if (itm.quantity <= 0) throw new Error(`Invalid quantity ${itm.quantity} for '${prod.name}'`);

        const amount = itm.quantity * itm.rate;
        subtotal += amount;
        verifiedItems.push({
          product: prod,
          quantity: itm.quantity,
          rate: itm.rate,
          amount,
        });
      }

      const totalAmount = Math.max(0, subtotal - (params.discount || 0));

      // 4. Insert Bill record
      const { lastInsertRowId: billId } = this.run(
        `INSERT INTO bills (
          bill_number, customer_id, customer_name, customer_mobile, subtotal, discount,
          total_amount, payment_method, payment_status, cash_tendered, change_due, split_details, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PAID', ?, ?, ?, ?)`,
        [
          billNumber,
          customerId || null,
          params.customerName || 'Walk-in Customer',
          params.customerMobile || '',
          subtotal,
          params.discount || 0,
          totalAmount,
          params.paymentMethod,
          params.cashTendered || totalAmount,
          params.changeDue || 0,
          params.splitDetails || null,
          params.notes || '',
        ]
      );

      // 5. Insert Bill Items and Atomically Deduct Stock
      for (const item of verifiedItems) {
        this.run(
          `INSERT INTO bill_items (bill_id, product_id, product_name, barcode, quantity, rate, amount)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            billId,
            item.product.id,
            item.product.name,
            item.product.barcode,
            item.quantity,
            item.rate,
            item.amount,
          ]
        );

        // Deduct stock
        const prevStock = item.product.current_stock;
        const newStock = prevStock - item.quantity;

        this.run(
          `UPDATE products 
           SET current_stock = ?, updated_at = datetime('now', 'localtime') 
           WHERE id = ?`,
          [newStock, item.product.id]
        );

        // Record stock transaction
        this.run(
          `INSERT INTO stock_transactions (
            product_id, transaction_type, quantity_change, previous_stock, new_stock, reference_id, notes
          ) VALUES (?, 'SALE', ?, ?, ?, ?, ?)`,
          [
            item.product.id,
            -item.quantity,
            prevStock,
            newStock,
            billNumber,
            `POS Sale: ${billNumber}`,
          ]
        );
      }

      // 6. Save Payment entry
      this.run(
        `INSERT INTO payments (
          bill_id, payment_method, amount, cash_tendered, change_due, split_details, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          billId,
          params.paymentMethod,
          totalAmount,
          params.cashTendered || totalAmount,
          params.changeDue || 0,
          params.splitDetails || null,
          `POS Bill payment for ${billNumber}`,
        ]
      );

      return this.getBillById(billId)!;
    });
  }

  public getBillById(id: number): Bill | null {
    const bill = this.queryOne<Bill>('SELECT * FROM bills WHERE id = ?', [id]);
    if (!bill) return null;
    bill.items = this.query<BillItem>('SELECT * FROM bill_items WHERE bill_id = ?', [id]);
    return bill;
  }

  public getBills(params: { search?: string; startDate?: string; endDate?: string } | string = {}): Bill[] {
    const normalized =
      typeof params === 'string'
        ? { search: params }
        : params && typeof params === 'object'
        ? params
        : {};

    let sql = 'SELECT * FROM bills WHERE 1=1';
    const sqlParams: any[] = [];

    const searchStr = typeof normalized.search === 'string' ? normalized.search.trim() : '';
    if (searchStr) {
      sql += ' AND (bill_number LIKE ? OR customer_name LIKE ? OR customer_mobile LIKE ?)';
      sqlParams.push(`%${searchStr}%`, `%${searchStr}%`, `%${searchStr}%`);
    }

    if (typeof normalized.startDate === 'string' && normalized.startDate) {
      sql += " AND date(created_at) >= date(?)";
      sqlParams.push(normalized.startDate);
    }

    if (typeof normalized.endDate === 'string' && normalized.endDate) {
      sql += " AND date(created_at) <= date(?)";
      sqlParams.push(normalized.endDate);
    }

    sql += ' ORDER BY id DESC LIMIT 500';
    const bills = this.query<Bill>(sql, sqlParams);

    // Fetch items for each bill
    for (const b of bills) {
      b.items = this.query<BillItem>('SELECT * FROM bill_items WHERE bill_id = ?', [b.id]);
    }

    return bills;
  }

  public deleteBill(billId: number, restoreStock: boolean = true): { success: boolean; billNumber: string; restoredItems: number } {
    return this.transaction(() => {
      const bill = this.getBillById(billId);
      if (!bill) {
        throw new Error(`Bill #${billId} not found`);
      }

      let restoredCount = 0;
      if (restoreStock && bill.items && bill.items.length > 0) {
        for (const item of bill.items) {
          if (item.product_id) {
            const currentProd = this.getProductById(item.product_id);
            if (currentProd) {
              const newStock = currentProd.current_stock + item.quantity;
              this.run(
                "UPDATE products SET current_stock = ?, updated_at = datetime('now', 'localtime') WHERE id = ?",
                [newStock, item.product_id]
              );
              this.run(
                `INSERT INTO stock_transactions (product_id, transaction_type, quantity_change, previous_stock, new_stock, notes)
                 VALUES (?, 'RESTORE', ?, ?, ?, ?)`,
                [
                  item.product_id,
                  item.quantity,
                  currentProd.current_stock,
                  newStock,
                  `Stock restored upon deletion of Bill #${bill.bill_number}`,
                ]
              );
              restoredCount++;
            }
          }
        }
      }

      this.run('DELETE FROM payments WHERE bill_id = ?', [billId]);
      this.run('DELETE FROM bill_items WHERE bill_id = ?', [billId]);
      this.run('DELETE FROM bills WHERE id = ?', [billId]);

      return { success: true, billNumber: bill.bill_number, restoredItems: restoredCount };
    });
  }

  public getPayments(): PaymentRecord[] {
    return this.query<PaymentRecord>('SELECT * FROM payments ORDER BY id DESC LIMIT 500');
  }

  // --- STOCK MANAGEMENT ---
  public adjustStock(params: {
    productId: number;
    transactionType: 'INWARD' | 'ADJUSTMENT';
    quantityChange: number;
    notes?: string;
  }): Product {
    return this.transaction(() => {
      const prod = this.getProductById(params.productId);
      if (!prod) throw new Error(`Product ${params.productId} not found`);

      const prevStock = prod.current_stock;
      const newStock = prevStock + params.quantityChange;

      if (newStock < 0) {
        throw new Error(`Stock adjustment cannot result in negative stock (Attempted: ${newStock})`);
      }

      this.run(
        "UPDATE products SET current_stock = ?, updated_at = datetime('now', 'localtime') WHERE id = ?",
        [newStock, prod.id]
      );

      this.run(
        `INSERT INTO stock_transactions (
          product_id, transaction_type, quantity_change, previous_stock, new_stock, reference_id, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          prod.id,
          params.transactionType,
          params.quantityChange,
          prevStock,
          newStock,
          'MANUAL',
          params.notes || `${params.transactionType} stock update`,
        ]
      );

      return this.getProductById(prod.id)!;
    });
  }

  public getStockTransactions(productId?: number): StockTransaction[] {
    let sql = `
      SELECT st.*, p.name as product_name
      FROM stock_transactions st
      JOIN products p ON st.product_id = p.id
      WHERE 1=1
    `;
    const params: any[] = [];
    if (productId) {
      sql += ' AND st.product_id = ?';
      params.push(productId);
    }
    sql += ' ORDER BY st.id DESC LIMIT 500';
    return this.query<StockTransaction>(sql, params);
  }

  // --- ESTIMATES & INVOICES ---
  // IMPORTANT: Creating/editing Estimate does NOT deduct stock and does NOT save payment.
  public createEstimate(params: {
    customerName?: string;
    customerMobile?: string;
    customerAddress?: string;
    items: Array<{ product_id: number; quantity: number; rate: number }>;
    discount: number;
    notes?: string;
    status?: 'DRAFT' | 'SAVED';
  }): Estimate {
    if (!params.items || params.items.length === 0) {
      throw new Error('Cannot create estimate with 0 items');
    }

    return this.transaction(() => {
      const datePrefix = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const countRes = this.queryOne<{ c: number }>(
        "SELECT COUNT(*) as c FROM estimates WHERE estimate_number LIKE 'EST-' || ? || '-%'",
        [datePrefix]
      );
      const nextSeq = (countRes?.c || 0) + 1;
      const estimateNumber = `EST-${datePrefix}-${String(nextSeq).padStart(4, '0')}`;

      let subtotal = 0;
      const verifiedItems: Array<{
        product: Product;
        quantity: number;
        rate: number;
        amount: number;
      }> = [];

      for (const itm of params.items) {
        const prod = this.getProductById(itm.product_id);
        if (!prod) throw new Error(`Product ${itm.product_id} not found`);
        const amount = itm.quantity * itm.rate;
        subtotal += amount;
        verifiedItems.push({ product: prod, quantity: itm.quantity, rate: itm.rate, amount });
      }

      const totalAmount = Math.max(0, subtotal - (params.discount || 0));

      const { lastInsertRowId: estId } = this.run(
        `INSERT INTO estimates (
          estimate_number, customer_name, customer_mobile, customer_address,
          subtotal, discount, total_amount, status, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          estimateNumber,
          params.customerName || 'Walk-in Customer',
          params.customerMobile || '',
          params.customerAddress || '',
          subtotal,
          params.discount || 0,
          totalAmount,
          params.status || 'SAVED',
          params.notes || '',
        ]
      );

      for (const itm of verifiedItems) {
        this.run(
          `INSERT INTO estimate_items (estimate_id, product_id, product_name, barcode, quantity, rate, amount)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [estId, itm.product.id, itm.product.name, itm.product.barcode, itm.quantity, itm.rate, itm.amount]
        );
      }

      // NO stock deduction! NO payment entry!
      return this.getEstimateById(estId)!;
    });
  }

  public getEstimateById(id: number): Estimate | null {
    const est = this.queryOne<Estimate>('SELECT * FROM estimates WHERE id = ?', [id]);
    if (!est) return null;
    est.items = this.query<EstimateItem>('SELECT * FROM estimate_items WHERE estimate_id = ?', [id]);
    return est;
  }

  public getEstimates(search: string | { search?: string } = ''): Estimate[] {
    let sql = 'SELECT * FROM estimates WHERE 1=1';
    const params: any[] = [];
    const searchStr = typeof search === 'string' ? search.trim() : (typeof (search as any)?.search === 'string' ? (search as any).search.trim() : '');
    if (searchStr) {
      sql += ' AND (estimate_number LIKE ? OR customer_name LIKE ? OR customer_mobile LIKE ?)';
      params.push(`%${searchStr}%`, `%${searchStr}%`, `%${searchStr}%`);
    }
    sql += ' ORDER BY id DESC LIMIT 500';
    const list = this.query<Estimate>(sql, params);
    for (const est of list) {
      est.items = this.query<EstimateItem>('SELECT * FROM estimate_items WHERE estimate_id = ?', [est.id]);
    }
    return list;
  }

  public deleteEstimate(id: number): void {
    this.run('DELETE FROM estimates WHERE id = ?', [id]);
  }

  // --- CONVERT ESTIMATE TO INVOICE (TRANSACTIONAL) ---
  public convertEstimateToInvoice(estimateId: number, paymentMethod: PaymentMethod = 'CASH'): Invoice {
    return this.transaction(() => {
      const estimate = this.getEstimateById(estimateId);
      if (!estimate) throw new Error(`Estimate #${estimateId} not found`);
      if (estimate.status === 'CONVERTED') {
        throw new Error(`Estimate ${estimate.estimate_number} has already been converted to Invoice!`);
      }
      if (!estimate.items || estimate.items.length === 0) {
        throw new Error('Cannot convert empty estimate to invoice.');
      }

      // 1. Generate unique invoice number
      const datePrefix = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const countRes = this.queryOne<{ c: number }>(
        "SELECT COUNT(*) as c FROM invoices WHERE invoice_number LIKE 'INV-' || ? || '-%'",
        [datePrefix]
      );
      const nextSeq = (countRes?.c || 0) + 1;
      const invoiceNumber = `INV-${datePrefix}-${String(nextSeq).padStart(4, '0')}`;

      // 2. Insert Invoice
      const { lastInsertRowId: invoiceId } = this.run(
        `INSERT INTO invoices (
          invoice_number, estimate_id, customer_name, customer_mobile, customer_address,
          subtotal, discount, total_amount, payment_method, payment_status, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'PAID', ?)`,
        [
          invoiceNumber,
          estimate.id,
          estimate.customer_name || 'Customer',
          estimate.customer_mobile || '',
          estimate.customer_address || '',
          estimate.subtotal,
          estimate.discount,
          estimate.total_amount,
          paymentMethod,
          `Converted from Estimate ${estimate.estimate_number}`,
        ]
      );

      // 3. Insert Invoice Items and Atomically Deduct Stock
      for (const itm of estimate.items) {
        this.run(
          `INSERT INTO invoice_items (invoice_id, product_id, product_name, barcode, quantity, rate, amount)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [invoiceId, itm.product_id, itm.product_name, itm.barcode, itm.quantity, itm.rate, itm.amount]
        );

        // Deduct Stock
        const prod = this.getProductById(itm.product_id);
        if (prod) {
          const prevStock = prod.current_stock;
          const newStock = prevStock - itm.quantity;
          this.run(
            "UPDATE products SET current_stock = ?, updated_at = datetime('now', 'localtime') WHERE id = ?",
            [newStock, prod.id]
          );

          this.run(
            `INSERT INTO stock_transactions (
              product_id, transaction_type, quantity_change, previous_stock, new_stock, reference_id, notes
            ) VALUES (?, 'INVOICE_SALE', ?, ?, ?, ?, ?)`,
            [
              prod.id,
              -itm.quantity,
              prevStock,
              newStock,
              invoiceNumber,
              `Converted from Estimate ${estimate.estimate_number}`,
            ]
          );
        }
      }

      // 4. Save Payment record
      this.run(
        `INSERT INTO payments (invoice_id, payment_method, amount, notes)
         VALUES (?, ?, ?, ?)`,
        [invoiceId, paymentMethod, estimate.total_amount, `Payment for Invoice ${invoiceNumber}`]
      );

      // 5. Update Estimate status to CONVERTED and link invoice
      this.run(
        "UPDATE estimates SET status = 'CONVERTED', converted_invoice_id = ?, updated_at = datetime('now', 'localtime') WHERE id = ?",
        [invoiceId, estimate.id]
      );

      return this.getInvoiceById(invoiceId)!;
    });
  }

  // Direct Invoice Creation
  public createInvoice(params: {
    customerName?: string;
    customerMobile?: string;
    customerAddress?: string;
    items: Array<{ product_id: number; quantity: number; rate: number }>;
    discount: number;
    paymentMethod: PaymentMethod;
    notes?: string;
  }): Invoice {
    return this.transaction(() => {
      const datePrefix = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const countRes = this.queryOne<{ c: number }>(
        "SELECT COUNT(*) as c FROM invoices WHERE invoice_number LIKE 'INV-' || ? || '-%'",
        [datePrefix]
      );
      const nextSeq = (countRes?.c || 0) + 1;
      const invoiceNumber = `INV-${datePrefix}-${String(nextSeq).padStart(4, '0')}`;

      let subtotal = 0;
      const verifiedItems: Array<{
        product: Product;
        quantity: number;
        rate: number;
        amount: number;
      }> = [];

      for (const itm of params.items) {
        const prod = this.getProductById(itm.product_id);
        if (!prod) throw new Error(`Product ${itm.product_id} not found`);
        const amount = itm.quantity * itm.rate;
        subtotal += amount;
        verifiedItems.push({ product: prod, quantity: itm.quantity, rate: itm.rate, amount });
      }

      const totalAmount = Math.max(0, subtotal - (params.discount || 0));

      const { lastInsertRowId: invId } = this.run(
        `INSERT INTO invoices (
          invoice_number, customer_name, customer_mobile, customer_address,
          subtotal, discount, total_amount, payment_method, payment_status, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PAID', ?)`,
        [
          invoiceNumber,
          params.customerName || 'Customer',
          params.customerMobile || '',
          params.customerAddress || '',
          subtotal,
          params.discount || 0,
          totalAmount,
          params.paymentMethod,
          params.notes || '',
        ]
      );

      for (const itm of verifiedItems) {
        this.run(
          `INSERT INTO invoice_items (invoice_id, product_id, product_name, barcode, quantity, rate, amount)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [invId, itm.product.id, itm.product.name, itm.product.barcode, itm.quantity, itm.rate, itm.amount]
        );

        // Deduct stock
        const prevStock = itm.product.current_stock;
        const newStock = prevStock - itm.quantity;
        this.run(
          "UPDATE products SET current_stock = ?, updated_at = datetime('now', 'localtime') WHERE id = ?",
          [newStock, itm.product.id]
        );

        this.run(
          `INSERT INTO stock_transactions (
            product_id, transaction_type, quantity_change, previous_stock, new_stock, reference_id, notes
          ) VALUES (?, 'INVOICE_SALE', ?, ?, ?, ?, ?)`,
          [
            itm.product.id,
            -itm.quantity,
            prevStock,
            newStock,
            invoiceNumber,
            `Invoice Sale: ${invoiceNumber}`,
          ]
        );
      }

      // Save Payment
      this.run(
        `INSERT INTO payments (invoice_id, payment_method, amount, notes)
         VALUES (?, ?, ?, ?)`,
        [invId, params.paymentMethod, totalAmount, `Direct Invoice ${invoiceNumber}`]
      );

      return this.getInvoiceById(invId)!;
    });
  }

  public getInvoiceById(id: number): Invoice | null {
    const inv = this.queryOne<Invoice>('SELECT * FROM invoices WHERE id = ?', [id]);
    if (!inv) return null;
    inv.items = this.query<InvoiceItem>('SELECT * FROM invoice_items WHERE invoice_id = ?', [id]);
    return inv;
  }

  public getInvoices(search: string | { search?: string } = ''): Invoice[] {
    let sql = `
      SELECT inv.*, est.estimate_number 
      FROM invoices inv
      LEFT JOIN estimates est ON inv.estimate_id = est.id
      WHERE 1=1
    `;
    const params: any[] = [];
    const searchStr = typeof search === 'string' ? search.trim() : (typeof (search as any)?.search === 'string' ? (search as any).search.trim() : '');
    if (searchStr) {
      sql += ' AND (inv.invoice_number LIKE ? OR inv.customer_name LIKE ? OR inv.customer_mobile LIKE ?)';
      params.push(`%${searchStr}%`, `%${searchStr}%`, `%${searchStr}%`);
    }
    sql += ' ORDER BY inv.id DESC LIMIT 500';
    const list = this.query<Invoice>(sql, params);
    for (const inv of list) {
      inv.items = this.query<InvoiceItem>('SELECT * FROM invoice_items WHERE invoice_id = ?', [inv.id]);
    }
    return list;
  }

  public deleteInvoice(invoiceId: number, restoreStock: boolean = true): { success: boolean; invoiceNumber: string } {
    return this.transaction(() => {
      const inv = this.getInvoiceById(invoiceId);
      if (!inv) {
        throw new Error(`Invoice #${invoiceId} not found`);
      }

      if (restoreStock && inv.items && inv.items.length > 0) {
        for (const item of inv.items) {
          if (item.product_id) {
            const currentProd = this.getProductById(item.product_id);
            if (currentProd) {
              const newStock = currentProd.current_stock + item.quantity;
              this.run(
                "UPDATE products SET current_stock = ?, updated_at = datetime('now', 'localtime') WHERE id = ?",
                [newStock, item.product_id]
              );
              this.run(
                `INSERT INTO stock_transactions (product_id, transaction_type, quantity_change, previous_stock, new_stock, notes)
                 VALUES (?, 'RESTORE', ?, ?, ?, ?)`,
                [
                  item.product_id,
                  item.quantity,
                  currentProd.current_stock,
                  newStock,
                  `Stock restored upon deletion of Invoice #${inv.invoice_number}`,
                ]
              );
            }
          }
        }
      }

      this.run('DELETE FROM payments WHERE invoice_id = ?', [invoiceId]);
      this.run('DELETE FROM invoice_items WHERE invoice_id = ?', [invoiceId]);
      this.run('DELETE FROM invoices WHERE id = ?', [invoiceId]);

      return { success: true, invoiceNumber: inv.invoice_number };
    });
  }

  // --- DASHBOARD STATISTICS ---
  public getDashboardStats(): DashboardStats {
    const todayStr = new Date().toISOString().slice(0, 10);

    const salesRes = this.queryOne<{ total: number; count: number }>(
      "SELECT COALESCE(SUM(total_amount), 0) as total, COUNT(*) as count FROM bills WHERE date(created_at) = date(?)",
      [todayStr]
    );

    const qtyRes = this.queryOne<{ qty: number }>(
      `SELECT COALESCE(SUM(bi.quantity), 0) as qty 
       FROM bill_items bi 
       JOIN bills b ON bi.bill_id = b.id 
       WHERE date(b.created_at) = date(?)`,
      [todayStr]
    );

    const lowStockRes = this.queryOne<{ count: number }>(
      'SELECT COUNT(*) as count FROM products WHERE current_stock <= min_stock_level'
    );

    const pendingEstRes = this.queryOne<{ count: number }>(
      "SELECT COUNT(*) as count FROM estimates WHERE status = 'SAVED'"
    );

    const todayEstRes = this.queryOne<{ count: number }>(
      "SELECT COUNT(*) as count FROM estimates WHERE date(created_at) = date(?)",
      [todayStr]
    );

    const todayInvRes = this.queryOne<{ count: number }>(
      "SELECT COUNT(*) as count FROM invoices WHERE date(created_at) = date(?)",
      [todayStr]
    );

    return {
      todaySales: salesRes?.total || 0,
      todayBills: salesRes?.count || 0,
      totalQtySold: qtyRes?.qty || 0,
      lowStockCount: lowStockRes?.count || 0,
      pendingEstimates: pendingEstRes?.count || 0,
      todayEstimates: todayEstRes?.count || 0,
      todayInvoices: todayInvRes?.count || 0,
    };
  }

  // --- LOCAL SALES REPORTS ---
  public getSalesReport(startDate: string, endDate: string): SalesReportSummary {
    const summaryRes = this.queryOne<{
      total_sales: number;
      bill_count: number;
      cash_sales: number;
      upi_sales: number;
      card_sales: number;
      split_sales: number;
      paytm_sales: number;
    }>(
      `SELECT 
        COALESCE(SUM(total_amount), 0) as total_sales,
        COUNT(*) as bill_count,
        COALESCE(SUM(CASE WHEN payment_method = 'CASH' THEN total_amount ELSE 0 END), 0) as cash_sales,
        COALESCE(SUM(CASE WHEN payment_method = 'UPI' THEN total_amount ELSE 0 END), 0) as upi_sales,
        COALESCE(SUM(CASE WHEN payment_method = 'CARD' THEN total_amount ELSE 0 END), 0) as card_sales,
        COALESCE(SUM(CASE WHEN payment_method = 'SPLIT' THEN total_amount ELSE 0 END), 0) as split_sales,
        COALESCE(SUM(CASE WHEN payment_method = 'PAYTM_MANUAL' THEN total_amount ELSE 0 END), 0) as paytm_sales
       FROM bills 
       WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)`,
      [startDate, endDate]
    );

    const qtyRes = this.queryOne<{ qty: number }>(
      `SELECT COALESCE(SUM(bi.quantity), 0) as qty
       FROM bill_items bi
       JOIN bills b ON bi.bill_id = b.id
       WHERE date(b.created_at) >= date(?) AND date(b.created_at) <= date(?)`,
      [startDate, endDate]
    );

    const invRes = this.queryOne<{ count: number; total: number }>(
      `SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total
       FROM invoices
       WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)`,
      [startDate, endDate]
    );

    const estRes = this.queryOne<{ count: number }>(
      `SELECT COUNT(*) as count
       FROM estimates
       WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)`,
      [startDate, endDate]
    );

    const productSales = this.query<{
      product_name: string;
      barcode: string;
      total_quantity: number;
      total_revenue: number;
    }>(
      `SELECT 
        bi.product_name,
        bi.barcode,
        SUM(bi.quantity) as total_quantity,
        SUM(bi.amount) as total_revenue
       FROM bill_items bi
       JOIN bills b ON bi.bill_id = b.id
       WHERE date(b.created_at) >= date(?) AND date(b.created_at) <= date(?)
       GROUP BY bi.barcode, bi.product_name
       ORDER BY total_quantity DESC
       LIMIT 50`,
      [startDate, endDate]
    );

    const dailySales = this.query<{
      date: string;
      bill_count: number;
      total_amount: number;
    }>(
      `SELECT 
        date(created_at) as date,
        COUNT(*) as bill_count,
        SUM(total_amount) as total_amount
       FROM bills
       WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)
       GROUP BY date(created_at)
       ORDER BY date ASC`,
      [startDate, endDate]
    );

    return {
      totalSales: summaryRes?.total_sales || 0,
      totalBills: summaryRes?.bill_count || 0,
      totalQuantity: qtyRes?.qty || 0,
      cashSales: summaryRes?.cash_sales || 0,
      upiSales: summaryRes?.upi_sales || 0,
      cardSales: summaryRes?.card_sales || 0,
      splitSales: summaryRes?.split_sales || 0,
      paytmSales: summaryRes?.paytm_sales || 0,
      invoiceCount: invRes?.count || 0,
      invoiceTotal: invRes?.total || 0,
      estimateCount: estRes?.count || 0,
      productSales: productSales || [],
      dailySales: dailySales || [],
    };
  }

  // --- SETTINGS ---
  public getSettings(): AppSettings {
    const rows = this.query<{ key: string; value: string }>('SELECT key, value FROM settings');
    const map: Record<string, string> = {};
    for (const r of rows) {
      map[r.key] = r.value;
    }

    return {
      business_name: map.business_name || 'TINY DEAMON WORKS',
      business_tagline: map.business_tagline || 'School & Business Billing Systems',
      business_address: map.business_address || '14, Anna Salai, Main Road, Chennai',
      business_phone: map.business_phone || '+91 98765 43210',
      business_email: map.business_email || 'tinydeamonworks@gmail.com',
      receipt_footer: map.receipt_footer || 'Thank you for your business! Visit Again!',
      currency_symbol: map.currency_symbol || '₹',
      thermal_printer_width: (map.thermal_printer_width as any) || '80mm',
      auto_print_receipt: map.auto_print_receipt === 'true',
      low_stock_warning_threshold: parseInt(map.low_stock_warning_threshold || '10', 10),
      language: (map.language as any) || 'en',
    };
  }

  public saveSettings(settings: Partial<AppSettings>): void {
    this.transaction(() => {
      for (const [k, v] of Object.entries(settings)) {
        this.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [k, String(v)]);
      }
    });
  }

  // --- BACKUP & RESTORE ---
  public exportDatabaseBinary(): Uint8Array {
    if (!this.db) throw new Error('Database not initialized');
    return this.db.export();
  }

  public async restoreDatabaseBinary(data: Uint8Array): Promise<void> {
    if (!this.sqlEngine) {
      this.sqlEngine = await this.loadSqlEngine();
    }
    this.db?.close();
    this.db = new this.sqlEngine.Database(data);
    this.saveToStorage();
  }

  // --- DATA MANAGEMENT & PURGE IMPACT ---
  public calculateDataImpact(startDate: string, endDate: string): DataManagementImpact {
    const billRes = this.queryOne<{ count: number; total: number }>(
      'SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total FROM bills WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)',
      [startDate, endDate]
    );

    const payRes = this.queryOne<{ count: number }>(
      'SELECT COUNT(*) as count FROM payments WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)',
      [startDate, endDate]
    );

    const stockRes = this.queryOne<{ count: number }>(
      'SELECT COUNT(*) as count FROM stock_transactions WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)',
      [startDate, endDate]
    );

    const estRes = this.queryOne<{ count: number }>(
      'SELECT COUNT(*) as count FROM estimates WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)',
      [startDate, endDate]
    );

    const invRes = this.queryOne<{ count: number }>(
      'SELECT COUNT(*) as count FROM invoices WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)',
      [startDate, endDate]
    );

    return {
      billCount: billRes?.count || 0,
      totalSales: billRes?.total || 0,
      paymentCount: payRes?.count || 0,
      stockTransactionsCount: stockRes?.count || 0,
      estimateCount: estRes?.count || 0,
      invoiceCount: invRes?.count || 0,
    };
  }

  public purgeDataRange(
    startDate: string,
    endDate: string,
    purgeEstimatesAndInvoices: boolean = false
  ): { deletedBills: number; deletedInvoices: number; deletedEstimates: number } {
    let deletedBills = 0;
    let deletedInvoices = 0;
    let deletedEstimates = 0;

    this.transaction(() => {
      // Find bill ids to delete
      const bills = this.query<{ id: number }>(
        'SELECT id FROM bills WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)',
        [startDate, endDate]
      );
      const billIds = bills.map((b) => b.id);
      deletedBills = billIds.length;

      if (billIds.length > 0) {
        const placeholders = billIds.map(() => '?').join(',');
        this.run(`DELETE FROM payments WHERE bill_id IN (${placeholders})`, billIds);
        this.run(`DELETE FROM bill_items WHERE bill_id IN (${placeholders})`, billIds);
        this.run(`DELETE FROM bills WHERE id IN (${placeholders})`, billIds);
      }

      if (purgeEstimatesAndInvoices) {
        const invs = this.query<{ id: number }>(
          'SELECT id FROM invoices WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)',
          [startDate, endDate]
        );
        const invIds = invs.map((i) => i.id);
        deletedInvoices = invIds.length;
        if (invIds.length > 0) {
          const invPlaceholders = invIds.map(() => '?').join(',');
          this.run(`DELETE FROM payments WHERE invoice_id IN (${invPlaceholders})`, invIds);
          this.run(`DELETE FROM invoice_items WHERE invoice_id IN (${invPlaceholders})`, invIds);
          this.run(`DELETE FROM invoices WHERE id IN (${invPlaceholders})`, invIds);
        }

        const ests = this.query<{ id: number }>(
          'SELECT id FROM estimates WHERE date(created_at) >= date(?) AND date(created_at) <= date(?)',
          [startDate, endDate]
        );
        const estIds = ests.map((e) => e.id);
        deletedEstimates = estIds.length;
        if (estIds.length > 0) {
          const estPlaceholders = estIds.map(() => '?').join(',');
          this.run(`DELETE FROM estimate_items WHERE estimate_id IN (${estPlaceholders})`, estIds);
          this.run(`DELETE FROM estimates WHERE id IN (${estPlaceholders})`, estIds);
        }
      }
    });

    return { deletedBills, deletedInvoices, deletedEstimates };
  }
}

export const sqliteService = new SQLiteDatabaseService();
