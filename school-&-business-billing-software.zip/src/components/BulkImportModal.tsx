import React, { useState } from 'react';
import { X, UploadCloud, AlertTriangle, CheckCircle, FileSpreadsheet, Download } from 'lucide-react';
import * as XLSX from 'xlsx';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';

interface BulkImportModalProps {
  onSuccess: (count: number) => void;
  onClose: () => void;
  currentLang: Language;
}

interface ParsedRow {
  rowNumber: number;
  name: string;
  barcode: string;
  category: string;
  purchase_price: number;
  selling_price: number;
  opening_stock: number;
  min_stock_level: number;
  isValid: boolean;
  errors: string[];
}

export const BulkImportModal: React.FC<BulkImportModalProps> = ({
  onSuccess,
  onClose,
  currentLang,
}) => {
  const [parsedRows, setParsedRows] = useState<ParsedRow[]>([]);
  const [fileName, setFileName] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importSummary, setImportSummary] = useState<{ imported: number; errors: string[] } | null>(null);

  const t = translations[currentLang];

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setIsProcessing(true);
    setImportSummary(null);

    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data, { type: 'array' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const json: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

      const existingProducts = await ipcClient.getProducts();
      const existingBarcodes = new Set(existingProducts.map((p) => p.barcode.toLowerCase()));
      const fileBarcodes = new Set<string>();

      const rows: ParsedRow[] = [];

      for (let i = 0; i < json.length; i++) {
        const item = json[i];
        const rowNum = i + 2;
        const errors: string[] = [];

        // Flexible key matching
        const name = (item['Product Name'] || item['name'] || item['Name'] || item['Product'] || '').toString().trim();
        const barcode = (item['Barcode'] || item['barcode'] || item['Code'] || item['QR'] || '').toString().trim();
        const category = (item['Category'] || item['category'] || 'General').toString().trim();
        const sellRaw = item['Selling Price'] ?? item['selling_price'] ?? item['Price'] ?? item['Rate'];
        const purchaseRaw = item['Purchase Price'] ?? item['purchase_price'] ?? item['Cost'] ?? 0;
        const stockRaw = item['Opening Stock'] ?? item['opening_stock'] ?? item['Stock'] ?? item['Qty'] ?? 0;
        const minRaw = item['Minimum Stock Level'] ?? item['min_stock_level'] ?? item['Min Stock'] ?? 5;

        const sellingPrice = parseFloat(sellRaw);
        const purchasePrice = parseFloat(purchaseRaw) || 0;
        const openingStock = parseInt(stockRaw, 10) || 0;
        const minStockLevel = parseInt(minRaw, 10) || 5;

        if (!name) {
          errors.push('Missing product name');
        }

        if (!barcode) {
          errors.push('Missing barcode');
        } else {
          const lowerBarcode = barcode.toLowerCase();
          if (existingBarcodes.has(lowerBarcode)) {
            errors.push(`Barcode '${barcode}' already exists in SQLite DB`);
          } else if (fileBarcodes.has(lowerBarcode)) {
            errors.push(`Duplicate barcode '${barcode}' in spreadsheet`);
          } else {
            fileBarcodes.add(lowerBarcode);
          }
        }

        if (isNaN(sellingPrice) || sellingPrice < 0) {
          errors.push('Invalid selling price');
        }

        if (openingStock < 0) {
          errors.push('Stock cannot be negative');
        }

        rows.push({
          rowNumber: rowNum,
          name,
          barcode,
          category,
          purchase_price: purchasePrice,
          selling_price: sellingPrice || 0,
          opening_stock: openingStock,
          min_stock_level: minStockLevel,
          isValid: errors.length === 0,
          errors,
        });
      }

      setParsedRows(rows);
    } catch (err) {
      console.error('File parsing error:', err);
      alert('Failed to parse file. Please verify it is a valid .xlsx, .xls, or .csv file.');
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadSampleTemplate = () => {
    const sampleData = [
      {
        'Product Name': 'Classmate Notebook A4',
        'Category': 'Stationery',
        'Barcode': 'SAM001',
        'Purchase Price': 50,
        'Selling Price': 70,
        'Opening Stock': 100,
        'Minimum Stock Level': 15,
      },
      {
        'Product Name': 'Reynolds Ball Pen Blue',
        'Category': 'Stationery',
        'Barcode': 'SAM002',
        'Purchase Price': 7,
        'Selling Price': 10,
        'Opening Stock': 250,
        'Minimum Stock Level': 30,
      },
      {
        'Product Name': 'School Backpack Medium',
        'Category': 'Uniforms & Bags',
        'Barcode': 'SAM003',
        'Purchase Price': 380,
        'Selling Price': 599,
        'Opening Stock': 25,
        'Minimum Stock Level': 5,
      },
    ];

    const ws = XLSX.utils.json_to_sheet(sampleData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Products');
    XLSX.writeFile(wb, 'Products_Bulk_Import_Template.xlsx');
  };

  const handleProceedImport = async () => {
    const validRows = parsedRows.filter((r) => r.isValid);
    if (validRows.length === 0) return;

    try {
      setIsImporting(true);
      const res = await ipcClient.bulkImportProducts(
        validRows.map((r) => ({
          name: r.name,
          barcode: r.barcode,
          category: r.category,
          purchase_price: r.purchase_price,
          selling_price: r.selling_price,
          opening_stock: r.opening_stock,
          min_stock_level: r.min_stock_level,
        }))
      );
      setImportSummary(res);
      onSuccess(res.imported);
    } catch (err: any) {
      alert(`Import error: ${err?.message || 'Transaction failed'}`);
    } finally {
      setIsImporting(false);
    }
  };

  const validCount = parsedRows.filter((r) => r.isValid).length;
  const errorCount = parsedRows.filter((r) => !r.isValid).length;

  return (
    <div
      id="bulk-import-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        id="bulk-import-modal-card"
        className="bg-slate-900 border border-slate-700 rounded-xl max-w-4xl w-full shadow-2xl flex flex-col max-h-[92vh] overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-indigo-900/50 border border-indigo-700/60 flex items-center justify-center text-indigo-400">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100">
                {t.bulkImportTitle}
              </h3>
              <p className="text-xs text-slate-400">
                Fast import for 3000+ products into local SQLite database
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {/* Backup Reminder Banner (Explicitly required before major import) */}
          <div className="flex items-start gap-3 p-3 rounded-lg bg-amber-950/40 border border-amber-800/80 text-amber-300 text-xs">
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
            <div>
              <span className="font-semibold">Recommended Backup Reminder:</span> Before importing a large batch of items, consider saving a fresh SQLite database backup from the "Backup & Restore" menu.
            </div>
          </div>

          {/* Upload and Sample Template */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-xl border-2 border-dashed border-slate-700 bg-slate-950/60">
            <div className="flex items-center gap-3">
              <UploadCloud className="w-8 h-8 text-blue-400" />
              <div>
                <p className="text-sm font-medium text-slate-200">
                  {fileName ? fileName : t.dropFilePrompt}
                </p>
                <p className="text-xs text-slate-500">Supports .xlsx, .xls, and .csv files</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={downloadSampleTemplate}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium cursor-pointer transition-colors border border-slate-700"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span>Sample Template (.xlsx)</span>
              </button>

              <label className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer shadow-md transition-colors">
                <span>Browse File</span>
                <input
                  type="file"
                  accept=".xlsx, .xls, .csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {isProcessing && (
            <div className="text-center py-6 text-slate-400 text-sm">
              Analyzing and validating spreadsheet rows...
            </div>
          )}

          {/* Validation Stats */}
          {parsedRows.length > 0 && !isProcessing && (
            <div className="space-y-3">
              <div className="flex items-center gap-4 text-xs">
                <span className="text-slate-400">Total Rows: {parsedRows.length}</span>
                <span className="text-emerald-400 font-medium">Valid: {validCount}</span>
                {errorCount > 0 && (
                  <span className="text-red-400 font-medium">Errors: {errorCount}</span>
                )}
              </div>

              {/* Table Preview */}
              <div className="border border-slate-800 rounded-lg overflow-hidden max-h-60 overflow-y-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider sticky top-0 border-b border-slate-800">
                    <tr>
                      <th className="p-2.5">Row</th>
                      <th className="p-2.5">Status</th>
                      <th className="p-2.5">Product Name</th>
                      <th className="p-2.5">Barcode</th>
                      <th className="p-2.5">Category</th>
                      <th className="p-2.5 text-right">Sell Price</th>
                      <th className="p-2.5 text-right">Stock</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {parsedRows.slice(0, 50).map((row) => (
                      <tr
                        key={row.rowNumber}
                        className={row.isValid ? 'hover:bg-slate-800/30' : 'bg-red-950/20'}
                      >
                        <td className="p-2.5 font-mono text-slate-500">#{row.rowNumber}</td>
                        <td className="p-2.5">
                          {row.isValid ? (
                            <span className="inline-flex items-center gap-1 text-emerald-400 text-[11px]">
                              <CheckCircle className="w-3.5 h-3.5" />
                              Valid
                            </span>
                          ) : (
                            <div className="text-red-400 text-[11px]">
                              {row.errors.join('; ')}
                            </div>
                          )}
                        </td>
                        <td className="p-2.5 font-medium text-slate-200">{row.name || '—'}</td>
                        <td className="p-2.5 font-mono text-slate-300">{row.barcode || '—'}</td>
                        <td className="p-2.5 text-slate-400">{row.category}</td>
                        <td className="p-2.5 text-right font-medium text-emerald-400">
                          ₹{row.selling_price.toFixed(2)}
                        </td>
                        <td className="p-2.5 text-right text-slate-300">{row.opening_stock}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {parsedRows.length > 50 && (
                <p className="text-[11px] text-slate-500 text-center">
                  Showing first 50 rows of {parsedRows.length} total rows.
                </p>
              )}
            </div>
          )}

          {importSummary && (
            <div className="p-4 rounded-lg bg-emerald-950/40 border border-emerald-800 text-emerald-300 text-xs space-y-1">
              <div className="font-semibold text-sm">
                Import Completed: {importSummary.imported} products added to SQLite database!
              </div>
              {importSummary.errors.length > 0 && (
                <div className="text-red-400 mt-2">
                  <p className="font-medium">Skipped with errors:</p>
                  <ul className="list-disc pl-4 space-y-0.5">
                    {importSummary.errors.map((err, i) => (
                      <li key={i}>{err}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-900">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-slate-400 hover:bg-slate-800 text-xs font-medium cursor-pointer"
          >
            {t.close}
          </button>

          <button
            type="button"
            disabled={isImporting || validCount === 0}
            onClick={handleProceedImport}
            className="flex items-center gap-2 px-6 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer shadow-md transition-colors"
          >
            <CheckCircle className="w-4 h-4" />
            <span>
              {isImporting ? 'Importing into SQLite...' : `${t.importConfirm} (${validCount} Products)`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
