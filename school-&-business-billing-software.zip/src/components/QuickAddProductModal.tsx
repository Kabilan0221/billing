import React, { useState, useEffect } from 'react';
import { X, Plus, PackagePlus, Camera, Sparkles, FolderPlus } from 'lucide-react';
import { Category, Product } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { generateUniqueBarcode } from '../utils/barcode';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import { BarcodeVisual } from './BarcodeVisual';

interface QuickAddProductModalProps {
  initialBarcode: string;
  categories: Category[];
  onSuccess: (product: Product) => void;
  onClose: () => void;
  currentLang: Language;
}

export const QuickAddProductModal: React.FC<QuickAddProductModalProps> = ({
  initialBarcode,
  categories: initialCategories,
  onSuccess,
  onClose,
  currentLang,
}) => {
  const [name, setName] = useState('');
  const [barcode, setBarcode] = useState(initialBarcode || '');
  const [categories, setCategories] = useState<Category[]>(initialCategories);
  const [categoryId, setCategoryId] = useState<number | undefined>(
    initialCategories[0]?.id
  );
  const [sellingPrice, setSellingPrice] = useState('');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [openingStock, setOpeningStock] = useState('50');
  const [minStock, setMinStock] = useState('5');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Scanner modal & inline category
  const [showScanner, setShowScanner] = useState(false);
  const [showInlineAddCat, setShowInlineAddCat] = useState(false);
  const [newCatName, setNewCatName] = useState('');

  const t = translations[currentLang];

  // Auto-fetch categories if empty
  useEffect(() => {
    if (categories.length === 0) {
      ipcClient.getCategories().then((cats) => {
        if (cats && cats.length > 0) {
          setCategories(cats);
          if (!categoryId) {
            setCategoryId(cats[0].id);
          }
        }
      }).catch(console.error);
    }
  }, [categories]);

  // If initialBarcode was not provided, auto-suggest or generate one
  const handleGenerateBarcode = () => {
    const newCode = generateUniqueBarcode();
    setBarcode(newCode);
  };

  const handleQuickAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    try {
      const added = await ipcClient.addCategory(newCatName.trim());
      setCategories((prev) => [...prev, added]);
      setCategoryId(added.id);
      setNewCatName('');
      setShowInlineAddCat(false);
    } catch (err: any) {
      setError(`Failed to add category: ${err?.message}`);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Product name is required');
      return;
    }
    const finalBarcode = barcode.trim() || generateUniqueBarcode();
    const sell = parseFloat(sellingPrice);
    if (isNaN(sell) || sell < 0) {
      setError('Please provide a valid selling price');
      return;
    }

    try {
      setIsSubmitting(true);
      setError('');
      const newProd = await ipcClient.saveProduct({
        name: name.trim(),
        barcode: finalBarcode,
        category_id: categoryId,
        selling_price: sell,
        purchase_price: parseFloat(purchasePrice) || 0,
        opening_stock: parseInt(openingStock, 10) || 0,
        min_stock_level: parseInt(minStock, 10) || 5,
      });
      onSuccess(newProd);
    } catch (err: any) {
      setError(err?.message || 'Failed to add product');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <div
        id="quick-add-modal-backdrop"
        className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4"
      >
        <div
          id="quick-add-modal-card"
          className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        >
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-900/40 border border-blue-700/60 flex items-center justify-center text-blue-400">
                <PackagePlus className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-slate-100">
                  {t.quickAddProduct}
                </h3>
                <p className="text-xs text-slate-400">
                  Add product and continue billing immediately
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
            {error && (
              <div className="p-2.5 rounded-lg bg-red-950/60 border border-red-800 text-red-300 text-xs">
                {error}
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.productName} *
              </label>
              <input
                type="text"
                required
                autoFocus
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Classmate Notebook 192 Pgs"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-slate-100 focus:outline-hidden focus:border-blue-500"
              />
            </div>

            {/* Barcode field with Scan and Generate buttons */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-medium text-slate-300">
                  {t.barcode} (பார்கோடு) *
                </label>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setShowScanner(true)}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-950 hover:bg-blue-900 text-blue-300 text-[11px] font-medium border border-blue-800/80 cursor-pointer transition-colors"
                    title="Scan barcode with camera"
                  >
                    <Camera className="w-3 h-3 text-blue-400" />
                    <span>Scan (ஸ்கேன்)</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleGenerateBarcode}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-950 hover:bg-emerald-900 text-emerald-300 text-[11px] font-medium border border-emerald-800/80 cursor-pointer transition-colors"
                    title="Generate new unique barcode"
                  >
                    <Sparkles className="w-3 h-3 text-emerald-400" />
                    <span>Generate (உருவாக்கு)</span>
                  </button>
                </div>
              </div>
              <input
                type="text"
                required
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                placeholder="Enter or scan barcode..."
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-slate-100 font-mono focus:outline-hidden focus:border-blue-500"
              />

              {barcode.trim() && (
                <div className="mt-2">
                  <BarcodeVisual
                    value={barcode.trim()}
                    height={32}
                    showText={true}
                    fontSize={10}
                    productName={name.trim() || undefined}
                    price={parseFloat(sellingPrice) || undefined}
                  />
                </div>
              )}
            </div>

            {/* Category selection & inline creation */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-medium text-slate-300">
                  {t.category} (வகை)
                </label>
                <button
                  type="button"
                  onClick={() => setShowInlineAddCat(!showInlineAddCat)}
                  className="inline-flex items-center gap-1 text-[11px] text-blue-400 hover:text-blue-300 cursor-pointer"
                >
                  <FolderPlus className="w-3 h-3" />
                  <span>{showInlineAddCat ? 'Close' : '+ New Category'}</span>
                </button>
              </div>

              {showInlineAddCat ? (
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 space-y-2 mb-2">
                  <input
                    type="text"
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    placeholder="New category name..."
                    className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded text-xs text-white"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowInlineAddCat(false)}
                      className="px-2 py-1 text-[11px] text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleQuickAddCategory}
                      className="px-3 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-medium"
                    >
                      Save Category
                    </button>
                  </div>
                </div>
              ) : (
                <select
                  value={categoryId || ''}
                  onChange={(e) => setCategoryId(e.target.value ? Number(e.target.value) : undefined)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-slate-100 focus:outline-hidden focus:border-blue-500"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {t.sellingPrice} (₹) *
                </label>
                <input
                  type="number"
                  step="any"
                  min="0"
                  required
                  value={sellingPrice}
                  onChange={(e) => setSellingPrice(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-slate-100 font-medium text-emerald-400 focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {t.purchasePrice} (₹)
                </label>
                <input
                  type="number"
                  step="any"
                  min="0"
                  value={purchasePrice}
                  onChange={(e) => setPurchasePrice(e.target.value)}
                  placeholder="0.00"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-slate-100 focus:outline-hidden focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {t.openingStock}
                </label>
                <input
                  type="number"
                  min="0"
                  value={openingStock}
                  onChange={(e) => setOpeningStock(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-slate-100 focus:outline-hidden focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {t.minStock}
                </label>
                <input
                  type="number"
                  min="1"
                  value={minStock}
                  onChange={(e) => setMinStock(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-slate-100 focus:outline-hidden focus:border-blue-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg text-slate-400 hover:bg-slate-800 text-xs font-medium cursor-pointer"
              >
                {t.cancel}
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer shadow-md transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>{isSubmitting ? 'Adding...' : t.quickAddProduct}</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Barcode Camera Scanner Modal */}
      {showScanner && (
        <BarcodeScannerModal
          isOpen={showScanner}
          onScan={(scannedCode) => {
            setBarcode(scannedCode);
            setShowScanner(false);
          }}
          onClose={() => setShowScanner(false)}
          title="Scan Product Barcode"
          instruction="Position product barcode in front of the camera"
        />
      )}
    </>
  );
};
