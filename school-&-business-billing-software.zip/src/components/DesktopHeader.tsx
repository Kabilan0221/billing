import React, { useEffect, useState } from 'react';
import {
  Minus,
  Square,
  X,
  Database,
  WifiOff,
  User as UserIcon,
  Globe,
  Clock,
  LogOut,
} from 'lucide-react';
import { User } from '../types';
import { Language, translations } from '../i18n/translations';

interface DesktopHeaderProps {
  currentUser: User | null;
  currentLang: Language;
  onToggleLang: () => void;
  onLogout: () => void;
}

export const DesktopHeader: React.FC<DesktopHeaderProps> = ({
  currentUser,
  currentLang,
  onToggleLang,
  onLogout,
}) => {
  const [timeStr, setTimeStr] = useState('');
  const t = translations[currentLang];

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleDateString(currentLang === 'ta' ? 'ta-IN' : 'en-US', {
          weekday: 'short',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [currentLang]);

  const handleWindowControl = (action: 'minimize' | 'maximize' | 'close') => {
    if (window.electronAPI) {
      window.electronAPI.invoke(`app:${action}`);
    }
  };

  return (
    <header
      id="desktop-titlebar"
      className="h-10 bg-slate-900 border-b border-slate-800 text-slate-300 flex items-center justify-between px-3 select-none text-xs font-medium z-50 shrink-0"
    >
      {/* Left branding */}
      <div className="flex items-center gap-2.5">
        <div className="w-5 h-5 rounded bg-blue-600 flex items-center justify-center text-white font-bold text-[10px] shadow-sm">
          TD
        </div>
        <span className="font-semibold text-slate-100 tracking-wide">
          {t.appName}
        </span>
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-950/70 border border-emerald-800/80 text-emerald-400 text-[11px]">
          <WifiOff className="w-3 h-3 text-emerald-400" />
          <span>{t.offlineMode}</span>
        </div>
      </div>

      {/* Middle info */}
      <div className="hidden md:flex items-center gap-4 text-slate-400">
        <div className="flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>{timeStr}</span>
        </div>
        <div className="flex items-center gap-1 text-[11px] text-slate-500">
          <Database className="w-3 h-3 text-cyan-400" />
          <span>Authoritative Local SQLite</span>
        </div>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-3">
        {/* Language selector */}
        <button
          id="lang-toggle-btn"
          onClick={onToggleLang}
          className="flex items-center gap-1 px-2 py-1 rounded hover:bg-slate-800 text-slate-300 transition-colors cursor-pointer border border-slate-700/60"
          title="Switch Language (English / தமிழ்)"
        >
          <Globe className="w-3.5 h-3.5 text-indigo-400" />
          <span className="font-semibold">{currentLang === 'en' ? 'தமிழ்' : 'English'}</span>
        </button>

        {/* User profile & Logout */}
        {currentUser && (
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
            <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-slate-800/80 text-slate-200">
              <UserIcon className="w-3 h-3 text-blue-400" />
              <span className="truncate max-w-[110px]">{currentUser.full_name}</span>
              <span className="text-[10px] px-1 py-0.2 rounded bg-slate-700 text-slate-300 font-mono">
                {currentUser.role}
              </span>
            </div>
            <button
              id="logout-btn"
              onClick={onLogout}
              className="p-1 rounded hover:bg-red-950/60 hover:text-red-400 text-slate-400 transition-colors cursor-pointer"
              title={t.logout}
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Windows style control buttons */}
        <div className="flex items-center ml-2 border-l border-slate-800">
          <button
            id="win-minimize-btn"
            onClick={() => handleWindowControl('minimize')}
            className="w-8 h-8 flex items-center justify-center hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
            title="Minimize"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button
            id="win-maximize-btn"
            onClick={() => handleWindowControl('maximize')}
            className="w-8 h-8 flex items-center justify-center hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
            title="Maximize / Restore"
          >
            <Square className="w-3 h-3" />
          </button>
          <button
            id="win-close-btn"
            onClick={() => handleWindowControl('close')}
            className="w-8 h-8 flex items-center justify-center hover:bg-red-600 text-slate-400 hover:text-white transition-colors"
            title="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
