import React from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  CreditCard,
  History,
  Users,
  Boxes,
  FileSpreadsheet,
  BarChart3,
  HardDriveDownload,
  Trash2,
  Settings as SettingsIcon,
  LogOut,
} from 'lucide-react';
import { Language, translations } from '../i18n/translations';

export type NavTab =
  | 'dashboard'
  | 'pos'
  | 'products'
  | 'payments'
  | 'history'
  | 'customers'
  | 'stock'
  | 'estimates_invoices'
  | 'reports'
  | 'backup'
  | 'data_management'
  | 'settings';

interface SidebarNavProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onLogout: () => void;
  currentLang: Language;
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeTab,
  onSelectTab,
  onLogout,
  currentLang,
}) => {
  const t = translations[currentLang];

  const menuItems: Array<{
    id: NavTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    hotkey?: string;
  }> = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
    { id: 'pos', label: t.posBilling, icon: ShoppingCart, hotkey: 'F1' },
    { id: 'products', label: t.products, icon: Package, hotkey: 'F2' },
    { id: 'payments', label: t.payments, icon: CreditCard, hotkey: 'F3' },
    { id: 'history', label: t.billHistory, icon: History, hotkey: 'F4' },
    { id: 'customers', label: t.customers, icon: Users, hotkey: 'F5' },
    { id: 'stock', label: t.stock, icon: Boxes, hotkey: 'F6' },
    { id: 'estimates_invoices', label: t.estimateInvoice, icon: FileSpreadsheet, hotkey: 'F7' },
    { id: 'reports', label: t.reports, icon: BarChart3, hotkey: 'F8' },
    { id: 'backup', label: t.backupRestore, icon: HardDriveDownload },
    { id: 'data_management', label: t.dataManagement, icon: Trash2 },
    { id: 'settings', label: t.settings, icon: SettingsIcon },
  ];

  return (
    <aside
      id="desktop-sidebar"
      className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col justify-between shrink-0 select-none overflow-y-auto"
    >
      <div className="p-3 space-y-1">
        <div className="px-3 py-2 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
          Main Menu
        </div>
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-${item.id}`}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30'
                  : 'text-slate-300 hover:bg-slate-800/80 hover:text-slate-100'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 ${
                    isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>
              {item.hotkey && (
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                    isActive ? 'bg-blue-700 text-blue-100' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {item.hotkey}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className="p-3 border-t border-slate-800">
        <button
          id="sidebar-logout-btn"
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-red-400 hover:bg-red-950/40 hover:text-red-300 transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>{t.logout}</span>
        </button>
      </div>
    </aside>
  );
};
