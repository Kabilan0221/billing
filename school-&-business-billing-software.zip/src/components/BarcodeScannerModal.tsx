import React, { useEffect, useState, useRef } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { Camera, X, RefreshCw, AlertCircle, CheckCircle2 } from 'lucide-react';
import { playScanBeep } from '../utils/barcode';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onScan: (barcode: string) => void;
  onClose: () => void;
  title?: string;
  instruction?: string;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onScan,
  onClose,
  title = 'Scan Product Barcode',
  instruction = 'Position the barcode or QR code in front of the camera',
}) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [cameras, setCameras] = useState<Array<{ id: string; label: string }>>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  const [isScanning, setIsScanning] = useState(false);
  const [lastScanned, setLastScanned] = useState<string | null>(null);

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const isComponentMounted = useRef(true);

  useEffect(() => {
    isComponentMounted.current = true;
    if (isOpen) {
      initCameras();
    } else {
      stopScanner();
    }

    return () => {
      isComponentMounted.current = false;
      stopScanner();
    };
  }, [isOpen]);

  const initCameras = async () => {
    try {
      setErrorMessage(null);
      const devices = await Html5Qrcode.getCameras();
      if (!isComponentMounted.current) return;

      if (devices && devices.length > 0) {
        setCameras(devices);
        // Prefer back camera if labeled, otherwise first device
        const backCam = devices.find((d) =>
          d.label.toLowerCase().includes('back') || d.label.toLowerCase().includes('rear') || d.label.toLowerCase().includes('environment')
        );
        const chosenId = backCam ? backCam.id : devices[0].id;
        setSelectedCameraId(chosenId);
        startScannerWithCamera(chosenId);
      } else {
        setErrorMessage('No camera devices detected. You can enter or generate the barcode manually.');
      }
    } catch (err: any) {
      console.error('Failed to get cameras:', err);
      if (isComponentMounted.current) {
        setErrorMessage(
          err?.message || 'Camera permission denied or camera not available. Please allow camera access.'
        );
      }
    }
  };

  const startScannerWithCamera = async (cameraId: string) => {
    try {
      await stopScanner();
      if (!isComponentMounted.current) return;

      const html5QrCode = new Html5Qrcode('barcode-scanner-viewport', {
        formatsToSupport: [
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.EAN_8,
          Html5QrcodeSupportedFormats.UPC_A,
          Html5QrcodeSupportedFormats.UPC_E,
          Html5QrcodeSupportedFormats.CODE_39,
          Html5QrcodeSupportedFormats.QR_CODE,
          Html5QrcodeSupportedFormats.DATA_MATRIX,
        ],
        verbose: false,
      });

      scannerRef.current = html5QrCode;

      await html5QrCode.start(
        cameraId,
        {
          fps: 15,
          qrbox: { width: 280, height: 160 },
          aspectRatio: 1.333,
        },
        (decodedText) => {
          const cleanText = decodedText.trim();
          if (cleanText) {
            playScanBeep(true);
            setLastScanned(cleanText);
            stopScanner();
            onScan(cleanText);
            onClose();
          }
        },
        () => {
          // ignore frame decode misses
        }
      );

      if (isComponentMounted.current) {
        setIsScanning(true);
      }
    } catch (err: any) {
      console.error('Failed to start camera scanner:', err);
      if (isComponentMounted.current) {
        setErrorMessage('Could not open camera stream: ' + (err?.message || 'Check camera permissions'));
        setIsScanning(false);
      }
    }
  };

  const stopScanner = async () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.isScanning) {
          await scannerRef.current.stop();
        }
        scannerRef.current.clear();
      } catch (err) {
        console.warn('Error clearing scanner instance:', err);
      } finally {
        scannerRef.current = null;
        if (isComponentMounted.current) {
          setIsScanning(false);
        }
      }
    }
  };

  const handleCameraChange = (cameraId: string) => {
    setSelectedCameraId(cameraId);
    startScannerWithCamera(cameraId);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-900/40 border border-blue-700/60 flex items-center justify-center text-blue-400">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-100">{title}</h3>
              <p className="text-[11px] text-slate-400">{instruction}</p>
            </div>
          </div>
          <button
            onClick={() => {
              stopScanner();
              onClose();
            }}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewport */}
        <div className="p-4 bg-slate-950 flex flex-col items-center justify-center relative min-h-[280px]">
          {errorMessage ? (
            <div className="p-4 text-center max-w-xs space-y-3">
              <AlertCircle className="w-10 h-10 text-amber-400 mx-auto" />
              <p className="text-xs text-slate-300">{errorMessage}</p>
              <button
                onClick={initCameras}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium cursor-pointer border border-slate-700"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry Camera</span>
              </button>
            </div>
          ) : (
            <div className="w-full relative overflow-hidden rounded-xl border border-slate-800 bg-black">
              <div id="barcode-scanner-viewport" className="w-full h-auto overflow-hidden" />
              {isScanning && (
                <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                  <div className="w-64 h-36 border-2 border-emerald-400/80 rounded-lg relative shadow-[0_0_15px_rgba(52,211,153,0.3)]">
                    <div className="absolute top-0 left-0 right-0 h-0.5 bg-emerald-400 animate-pulse shadow-[0_0_8px_#34d399]" />
                    <div className="absolute bottom-1 left-0 right-0 text-center text-[10px] text-emerald-400 font-mono tracking-wider">
                      AIM AT BARCODE
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {lastScanned && (
            <div className="mt-3 flex items-center gap-1.5 text-xs text-emerald-400 font-mono bg-emerald-950/60 px-3 py-1 rounded-full border border-emerald-800">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Scanned: {lastScanned}</span>
            </div>
          )}
        </div>

        {/* Footer controls */}
        <div className="p-3 border-t border-slate-800 bg-slate-900/90 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          {cameras.length > 1 && (
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-slate-400 text-[11px] whitespace-nowrap">Camera:</span>
              <select
                value={selectedCameraId}
                onChange={(e) => handleCameraChange(e.target.value)}
                className="w-full sm:w-44 px-2 py-1 bg-slate-950 border border-slate-700 rounded text-slate-200 text-xs"
              >
                {cameras.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label || `Camera ${c.id.slice(0, 5)}`}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="flex items-center justify-end w-full sm:w-auto ml-auto">
            <button
              onClick={() => {
                stopScanner();
                onClose();
              }}
              className="px-4 py-1.5 rounded-lg text-slate-300 hover:bg-slate-800 text-xs font-medium cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
