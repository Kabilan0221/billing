/// <reference types="vite/client" />

declare module '*.wasm?url' {
  const content: string;
  export default content;
}

declare module '*.wasm' {
  const content: string;
  export default content;
}

declare module 'sql.js/dist/sql-asm.js' {
  import { SqlJsStatic } from 'sql.js';
  const initSqlJs: (config?: any) => Promise<SqlJsStatic>;
  export default initSqlJs;
}
