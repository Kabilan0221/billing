import React, { useEffect, useState } from 'react';
import {
  DollarSign,
  Receipt,
  Boxes,
  AlertTriangle,
  FileClock,
  FileCheck,
  ShoppingCart,
  PlusCircle,
  FilePlus,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { DashboardStats } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { NavTab } from '../components/SidebarNav';

interface DashboardPageProps {
  onNavigate: (tab: NavTab) => void;
  currentLang: Language;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate, currentLang }) => {
  const [stats, setStats] = useState<DashboardStats>({
    todaySales: 0,
    todayBills: 0,
    totalQtySold: 0,
    lowStockCount: 0,
    pendingEstimates: 0,
    todayEstimates: 0,
    todayInvoices: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  const t = translations[currentLang];

  const loadStats = async () => {
    try {
      setIsLoading(true);
      const data = await ipcClient.getDashboardStats();
      setStats(data);
    } catch (err) {
      console.error('Failed to load dashboard stats:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, []);

  const statCards = [
    {
      title: t.todaySales,
      value: `₹${stats.todaySales.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: DollarSign,
      color: 'emerald',
      bg: 'bg-emerald-950/40 border-emerald-800/60 text-emerald-400',
      iconBg: 'bg-emerald-900/50 text-emerald-400',
    },
    {
      title: t.todayBills,
      value: stats.todayBills.toString(),
      icon: Receipt,
      color: 'blue',
      bg: 'bg-blue-950/40 border-blue-800/60 text-blue-400',
      iconBg: 'bg-blue-900/50 text-blue-400',
    },
    {
      title: t.totalQtySold,
      value: stats.totalQtySold.toString(),
      icon: Boxes,
      color: 'indigo',
      bg: 'bg-indigo-950/40 border-indigo-800/60 text-indigo-400',
      iconBg: 'bg-indigo-900/50 text-indigo-400',
    },
    {
      title: t.lowStockItems,
      value: stats.lowStockCount.toString(),
      icon: AlertTriangle,
      color: 'amber',
      bg: 'bg-amber-950/40 border-amber-800/60 text-amber-400',
      iconBg: 'bg-amber-900/50 text-amber-400',
      action: () => onNavigate('stock'),
    },
    {
      title: t.pendingEstimates,
      value: stats.pendingEstimates.toString(),
      icon: FileClock,
      color: 'purple',
      bg: 'bg-purple-950/40 border-purple-800/60 text-purple-400',
      iconBg: 'bg-purple-900/50 text-purple-400',
      action: () => onNavigate('estimates_invoices'),
    },
    {
      title: t.todayEstimates,
      value: stats.todayEstimates.toString(),
      icon: FilePlus,
      color: 'cyan',
      bg: 'bg-cyan-950/40 border-cyan-800/60 text-cyan-400',
      iconBg: 'bg-cyan-900/50 text-cyan-400',
    },
    {
      title: t.todayInvoices,
      value: stats.todayInvoices.toString(),
      icon: FileCheck,
      color: 'teal',
      bg: 'bg-teal-950/40 border-teal-800/60 text-teal-400',
      iconBg: 'bg-teal-900/50 text-teal-400',
    },
  ];

  return (
    <div id="dashboard-container" className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Welcome banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-blue-950/60 border border-slate-800 shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-white tracking-tight">
              {t.dashboard}
            </h2>
            <span className="px-2 py-0.5 text-[11px] font-medium rounded-full bg-blue-900/60 text-blue-300 border border-blue-700/50">
              Live SQLite Local
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Real-time local POS metrics and inventory overview directly computed from SQLite
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('pos')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-lg shadow-blue-900/40 cursor-pointer transition-all"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>{t.newSale} (F1)</span>
          </button>
          <button
            onClick={() => onNavigate('estimates_invoices')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 cursor-pointer transition-colors"
          >
            <FilePlus className="w-4 h-4 text-cyan-400" />
            <span>{t.newEstimate} (F7)</span>
          </button>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div
              key={i}
              onClick={card.action}
              className={`p-5 rounded-xl border ${card.bg} shadow-md flex items-center justify-between ${
                card.action ? 'cursor-pointer hover:border-slate-600 transition-all' : ''
              }`}
            >
              <div className="space-y-1">
                <p className="text-xs font-medium text-slate-400">{card.title}</p>
                <p className="text-2xl font-bold tracking-tight text-white">{card.value}</p>
              </div>
              <div className={`w-11 h-11 rounded-xl ${card.iconBg} flex items-center justify-center shadow-inner`}>
                <Icon className="w-5 h-5" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Action Navigation Panels */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">
          {t.quickActions}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div
            onClick={() => onNavigate('pos')}
            className="p-5 rounded-xl bg-slate-900 border border-slate-800 hover:border-blue-600/50 hover:bg-slate-800/40 transition-all cursor-pointer group space-y-2"
          >
            <div className="w-10 h-10 rounded-lg bg-blue-900/40 border border-blue-700/60 flex items-center justify-center text-blue-400">
              <ShoppingCart className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-semibold text-white group-hover:text-blue-400 transition-colors flex items-center justify-between">
              <span>{t.posBilling}</span>
              <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-blue-400 transition-transform group-hover:translate-x-1" />
            </h4>
            <p className="text-xs text-slate-400">
              Instant barcode scanning, cart management, cash change calculation, and thermal printing.
            </p>
          </div>

          <div
            onClick={() => onNavigate('products')}
            className="p-5 rounded-xl bg-slate-900 border border-slate-800 hover:border-emerald-600/50 hover:bg-slate-800/40 transition-all cursor-pointer group space-y-2"
          >
            <div className="w-10 h-10 rounded-lg bg-emerald-900/40 border border-emerald-700/60 flex items-center justify-center text-emerald-400">
              <Boxes className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-semibold text-white group-hover:text-emerald-400 transition-colors flex items-center justify-between">
              <span>{t.products} & {t.bulkImport}</span>
              <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 transition-transform group-hover:translate-x-1" />
            </h4>
            <p className="text-xs text-slate-400">
              Manage product pricing, barcodes, categories, and bulk import 3000+ items via Excel/CSV.
            </p>
          </div>

          <div
            onClick={() => onNavigate('reports')}
            className="p-5 rounded-xl bg-slate-900 border border-slate-800 hover:border-indigo-600/50 hover:bg-slate-800/40 transition-all cursor-pointer group space-y-2"
          >
            <div className="w-10 h-10 rounded-lg bg-indigo-900/40 border border-indigo-700/60 flex items-center justify-center text-indigo-400">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-semibold text-white group-hover:text-indigo-400 transition-colors flex items-center justify-between">
              <span>{t.reports} (Local SQLite)</span>
              <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 transition-transform group-hover:translate-x-1" />
            </h4>
            <p className="text-xs text-slate-400">
              Generate offline date-wise sales, payment breakdowns (Cash, UPI, Card, Split), and item metrics.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
