import React, { useState, useEffect } from 'react';
import {
  Boxes,
  PlusCircle,
  SlidersHorizontal,
  History,
  AlertTriangle,
  Search,
  CheckCircle2,
} from 'lucide-react';
import { Product, StockTransaction } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';

interface StockPageProps {
  currentLang: Language;
}

export const StockPage: React.FC<StockPageProps> = ({ currentLang }) => {
  const [activeSubTab, setActiveSubTab] = useState<'inventory' | 'history'>('inventory');
  const [products, setProducts] = useState<Product[]>([]);
  const [history, setHistory] = useState<StockTransaction[]>([]);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  // Stock action modal
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [actionType, setActionType] = useState<'INWARD' | 'ADJUSTMENT'>('INWARD');
  const [qtyChange, setQtyChange] = useState('');
  const [reasonNotes, setReasonNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const t = translations[currentLang];

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [prods, txs] = await Promise.all([
        ipcClient.getProducts(),
        ipcClient.getStockTransactions(),
      ]);
      setProducts(prods);
      setHistory(txs);
    } catch (err) {
      console.error('Failed to load stock data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleStockUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;
    const qty = parseInt(qtyChange, 10);
    if (isNaN(qty) || qty === 0) {
      alert('Please enter a non-zero quantity change');
      return;
    }

    try {
      setIsSubmitting(true);
      await ipcClient.recordStockAdjustment({
        productId: selectedProduct.id,
        quantityChange: actionType === 'INWARD' ? Math.abs(qty) : qty,
        type: actionType,
        notes: reasonNotes.trim() || undefined,
      });

      setFeedback(
        `Successfully recorded ${actionType.toLowerCase()} for '${selectedProduct.name}'`
      );
      setSelectedProduct(null);
      setQtyChange('');
      setReasonNotes('');
      loadData();
    } catch (err: any) {
      alert(`Stock update failed: ${err?.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.barcode.toLowerCase().includes(search.toLowerCase())
  );

  const lowStockItems = products.filter((p) => p.current_stock <= p.min_stock_level);

  return (
    <div id="stock-page-container" className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Boxes className="w-6 h-6 text-blue-400" />
            <span>{t.stock}</span>
          </h2>
          <p className="text-xs text-slate-400">
            Real-time SQLite inventory balances, stock inward entries, and audit trail logs
          </p>
        </div>

        {/* Subtab switcher */}
        <div className="flex bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs">
          <button
            onClick={() => setActiveSubTab('inventory')}
            className={`px-4 py-1.5 rounded-lg font-medium cursor-pointer transition-colors ${
              activeSubTab === 'inventory'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Inventory Balances ({products.length})
          </button>
          <button
            onClick={() => setActiveSubTab('history')}
            className={`px-4 py-1.5 rounded-lg font-medium cursor-pointer transition-colors ${
              activeSubTab === 'history'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t.transactionHistory} ({history.length})
          </button>
        </div>
      </div>

      {feedback && (
        <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>{feedback}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-white">
            ✕
          </button>
        </div>
      )}

      {/* Low Stock Warning Banner if any */}
      {lowStockItems.length > 0 && activeSubTab === 'inventory' && (
        <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-800/80 text-amber-300 text-xs flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold text-sm">
              {lowStockItems.length} product(s) have reached or fallen below minimum stock thresholds!
            </p>
            <p className="text-amber-400/90 text-xs">
              Items:{' '}
              {lowStockItems
                .slice(0, 5)
                .map((p) => `${p.name} (${p.current_stock} left)`)
                .join(', ')}
              {lowStockItems.length > 5 && ` and ${lowStockItems.length - 5} more.`}
            </p>
          </div>
        </div>
      )}

      {activeSubTab === 'inventory' ? (
        <div className="space-y-4">
          {/* Search bar */}
          <div className="relative bg-slate-900 p-3 rounded-xl border border-slate-800">
            <Search className="w-4 h-4 absolute left-6 top-5.5 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search inventory by product name or barcode..."
              className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-blue-500"
            />
          </div>

          {/* Table */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900 shadow-xl">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="p-3.5">#</th>
                  <th className="p-3.5">Product Name</th>
                  <th className="p-3.5">Barcode</th>
                  <th className="p-3.5 text-center">Opening Stock</th>
                  <th className="p-3.5 text-center">Current Stock</th>
                  <th className="p-3.5 text-center">Min Level</th>
                  <th className="p-3.5 text-center">Quick Adjust</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {isLoading ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-500">
                      Loading inventory levels...
                    </td>
                  </tr>
                ) : filteredProducts.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-500">
                      No products found.
                    </td>
                  </tr>
                ) : (
                  filteredProducts.map((p, idx) => {
                    const isLow = p.current_stock <= p.min_stock_level;
                    return (
                      <tr key={p.id} className="hover:bg-slate-800/40">
                        <td className="p-3.5 font-mono text-slate-500">{idx + 1}</td>
                        <td className="p-3.5 font-medium text-slate-100">{p.name}</td>
                        <td className="p-3.5 font-mono text-slate-400">{p.barcode}</td>
                        <td className="p-3.5 text-center text-slate-400 font-mono">
                          {p.opening_stock}
                        </td>
                        <td className="p-3.5 text-center font-bold font-mono">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full ${
                              isLow
                                ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                : 'bg-emerald-950/60 text-emerald-300'
                            }`}
                          >
                            {isLow && <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />}
                            {p.current_stock}
                          </span>
                        </td>
                        <td className="p-3.5 text-center text-slate-400 font-mono">
                          {p.min_stock_level}
                        </td>
                        <td className="p-3.5 text-center">
                          <div className="flex items-center justify-center gap-2">
                            <button
                              onClick={() => {
                                setSelectedProduct(p);
                                setActionType('INWARD');
                                setQtyChange('');
                              }}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-950/70 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 text-[11px] font-medium cursor-pointer transition-colors"
                              title="Stock Inward (+)"
                            >
                              <PlusCircle className="w-3.5 h-3.5" />
                              <span>{t.stockInward}</span>
                            </button>
                            <button
                              onClick={() => {
                                setSelectedProduct(p);
                                setActionType('ADJUSTMENT');
                                setQtyChange('');
                              }}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-[11px] font-medium cursor-pointer transition-colors"
                              title="Manual Adjustment (±)"
                            >
                              <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-400" />
                              <span>{t.stockAdjustment}</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Stock Movement History Table */
        <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900 shadow-xl">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3.5">#</th>
                <th className="p-3.5">Product</th>
                <th className="p-3.5">Movement Type</th>
                <th className="p-3.5 text-center">Change (±)</th>
                <th className="p-3.5 text-center">Previous</th>
                <th className="p-3.5 text-center">New Stock</th>
                <th className="p-3.5">Reference / Reason Notes</th>
                <th className="p-3.5">Date & Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {history.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500">
                    No stock transactions recorded yet. Sales, inward additions, and manual adjustments are logged automatically.
                  </td>
                </tr>
              ) : (
                history.map((tx, idx) => (
                  <tr key={tx.id} className="hover:bg-slate-800/40">
                    <td className="p-3.5 font-mono text-slate-500">{idx + 1}</td>
                    <td className="p-3.5 font-medium text-slate-100">{tx.product_name}</td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase ${
                          tx.type === 'SALE' || tx.type === 'INVOICE'
                            ? 'bg-red-950/60 text-red-400 border border-red-800/70'
                            : tx.type === 'INWARD'
                            ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/70'
                            : 'bg-indigo-950/60 text-indigo-400 border border-indigo-800/70'
                        }`}
                      >
                        {tx.type}
                      </span>
                    </td>
                    <td
                      className={`p-3.5 text-center font-bold font-mono ${
                        tx.quantity_change > 0 ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {tx.quantity_change > 0 ? `+${tx.quantity_change}` : tx.quantity_change}
                    </td>
                    <td className="p-3.5 text-center font-mono text-slate-400">
                      {tx.previous_stock}
                    </td>
                    <td className="p-3.5 text-center font-mono font-semibold text-slate-200">
                      {tx.new_stock}
                    </td>
                    <td className="p-3.5 text-slate-400">{tx.notes || '—'}</td>
                    <td className="p-3.5 text-slate-400">
                      {new Date(tx.created_at).toLocaleString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Stock Inward / Adjustment Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-xl max-w-md w-full shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
              <h3 className="text-sm font-semibold text-slate-100">
                {actionType === 'INWARD' ? t.stockInward : t.stockAdjustment}
              </h3>
              <button
                onClick={() => setSelectedProduct(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleStockUpdate} className="p-5 space-y-4">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
                <p className="text-xs font-semibold text-white">{selectedProduct.name}</p>
                <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                  <span>Barcode: {selectedProduct.barcode}</span>
                  <span>Current Stock: {selectedProduct.current_stock}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {actionType === 'INWARD'
                    ? 'Quantity to Add (+)'
                    : 'Quantity Change (Enter positive to add, negative to deduct)'}
                </label>
                <input
                  type="number"
                  required
                  autoFocus
                  value={qtyChange}
                  onChange={(e) => setQtyChange(e.target.value)}
                  placeholder={actionType === 'INWARD' ? 'e.g. 50' : 'e.g. -5 or 10'}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {t.reasonNotes}
                </label>
                <input
                  type="text"
                  value={reasonNotes}
                  onChange={(e) => setReasonNotes(e.target.value)}
                  placeholder="e.g. Supplier delivery PO-448, damaged box write-off..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setSelectedProduct(null)}
                  className="px-4 py-2 rounded-lg text-slate-400 hover:bg-slate-800 text-xs font-medium cursor-pointer"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold cursor-pointer shadow-md"
                >
                  {isSubmitting ? 'Updating...' : t.saveStock}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
