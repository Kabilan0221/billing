import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  FileClock,
  FileCheck,
  Plus,
  ArrowRightLeft,
  Printer,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  Barcode,
  Search,
  Camera,
  PackagePlus,
  Calendar,
  X,
  AlertCircle,
} from 'lucide-react';
import { Estimate, Invoice, Product, PaymentMethod, Category } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { ReceiptModal } from '../components/ReceiptModal';
import { PrintableReceiptData } from '../printing/thermal-printer';
import { BarcodeScannerModal } from '../components/BarcodeScannerModal';
import { QuickAddProductModal } from '../components/QuickAddProductModal';

interface EstimateInvoicePageProps {
  currentLang: Language;
}

export const EstimateInvoicePage: React.FC<EstimateInvoicePageProps> = ({ currentLang }) => {
  const [activeTab, setActiveTab] = useState<'estimates' | 'invoices'>('estimates');
  const [estimates, setEstimates] = useState<Estimate[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Form creation modal
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createType, setCreateType] = useState<'ESTIMATE' | 'INVOICE'>('ESTIMATE');
  const [customerName, setCustomerName] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [formItems, setFormItems] = useState<Array<{ product: Product; quantity: number; rate: number }>>([]);
  const [discount, setDiscount] = useState('0');
  const [invoicePaymentMethod, setInvoicePaymentMethod] = useState<PaymentMethod>('CASH');
  const [formNotes, setFormNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // In-modal Product Search / Scan
  const [productSearch, setProductSearch] = useState('');
  const [productCategoryFilter, setProductCategoryFilter] = useState<number | undefined>(undefined);
  const [matchedProducts, setMatchedProducts] = useState<Product[]>([]);
  const [showScanner, setShowScanner] = useState(false);
  const [quickAddBarcode, setQuickAddBarcode] = useState<string | null>(null);

  // Delete Modals
  const [deleteInvoiceTarget, setDeleteInvoiceTarget] = useState<Invoice | null>(null);
  const [restoreStockOnInvoiceDelete, setRestoreStockOnInvoiceDelete] = useState(true);
  const [isDeleting, setIsDeleting] = useState(false);

  // Thermal receipt modal
  const [printableReceipt, setPrintableReceipt] = useState<PrintableReceiptData | null>(null);

  const t = translations[currentLang];

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [ests, invs, prods, cats] = await Promise.all([
        ipcClient.getEstimates(searchQuery || undefined),
        ipcClient.getInvoices(searchQuery || undefined),
        ipcClient.getProducts(),
        ipcClient.getCategories(),
      ]);
      setEstimates(ests);
      setInvoices(invs);
      setProducts(prods);
      setCategories(cats);
    } catch (err) {
      console.error('Failed to load estimates/invoices:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [searchQuery]);

  // Product Search in Modal
  const handleSearchProduct = (text: string) => {
    setProductSearch(text);
    if (!text.trim()) {
      setMatchedProducts([]);
      return;
    }
    const q = text.toLowerCase();
    const matches = products.filter((p) => {
      const matchCat = productCategoryFilter ? p.category_id === productCategoryFilter : true;
      return (
        matchCat &&
        (p.name.toLowerCase().includes(q) || p.barcode.toLowerCase().includes(q))
      );
    });
    setMatchedProducts(matches.slice(0, 8));
  };

  const handleAddItemToForm = (prod: Product) => {
    setFormItems((prev) => {
      const existing = prev.find((i) => i.product.id === prod.id);
      if (existing) {
        return prev.map((i) =>
          i.product.id === prod.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      return [...prev, { product: prod, quantity: 1, rate: prod.selling_price }];
    });
    setProductSearch('');
    setMatchedProducts([]);
  };

  const handleBarcodeScanned = async (scannedCode: string) => {
    setShowScanner(false);
    const exact = await ipcClient.getProductByBarcode(scannedCode);
    if (exact) {
      handleAddItemToForm(exact);
    } else {
      setQuickAddBarcode(scannedCode);
    }
  };

  const handleRemoveFormItem = (productId: number) => {
    setFormItems(formItems.filter((i) => i.product.id !== productId));
  };

  const formSubtotal = formItems.reduce((acc, i) => acc + i.quantity * i.rate, 0);
  const formDiscount = parseFloat(discount) || 0;
  const formTotal = Math.max(0, formSubtotal - formDiscount);

  const handleCreateDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formItems.length === 0) {
      alert('Please add at least one product item');
      return;
    }

    try {
      setIsSubmitting(true);
      setFeedback(null);
      const settings = await ipcClient.getSettings();

      if (createType === 'ESTIMATE') {
        const est = await ipcClient.createEstimate({
          customerName: customerName.trim() || undefined,
          customerMobile: customerMobile.trim() || undefined,
          customerAddress: customerAddress.trim() || undefined,
          items: formItems.map((i) => ({
            product_id: i.product.id,
            quantity: i.quantity,
            rate: i.rate,
          })),
          discount: formDiscount,
          notes: formNotes.trim() || undefined,
        });

        setFeedback({
          type: 'success',
          text: `Estimate #${est.estimate_number} created successfully! (Stock was not deducted)`,
        });

        // Prepare print preview
        setPrintableReceipt({
          title: 'ESTIMATE / QUOTATION',
          documentNumber: est.estimate_number,
          date: new Date(est.created_at).toLocaleDateString(),
          time: new Date(est.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          customerName: est.customer_name,
          customerMobile: est.customer_mobile,
          items: formItems.map((i) => ({
            name: i.product.name,
            quantity: i.quantity,
            rate: i.rate,
            amount: i.quantity * i.rate,
          })),
          subtotal: est.subtotal,
          discount: est.discount,
          total: est.total_amount,
          settings,
        });
      } else {
        const inv = await ipcClient.createInvoice({
          customerName: customerName.trim() || undefined,
          customerMobile: customerMobile.trim() || undefined,
          customerAddress: customerAddress.trim() || undefined,
          items: formItems.map((i) => ({
            product_id: i.product.id,
            quantity: i.quantity,
            rate: i.rate,
          })),
          discount: formDiscount,
          paymentMethod: invoicePaymentMethod,
          notes: formNotes.trim() || undefined,
        });

        setFeedback({
          type: 'success',
          text: `Tax Invoice #${inv.invoice_number} created! Inventory stock updated.`,
        });

        setPrintableReceipt({
          title: 'TAX INVOICE',
          documentNumber: inv.invoice_number,
          date: new Date(inv.created_at).toLocaleDateString(),
          time: new Date(inv.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          customerName: inv.customer_name,
          customerMobile: inv.customer_mobile,
          items: formItems.map((i) => ({
            name: i.product.name,
            quantity: i.quantity,
            rate: i.rate,
            amount: i.quantity * i.rate,
          })),
          subtotal: inv.subtotal,
          discount: inv.discount,
          total: inv.total_amount,
          paymentMethod: inv.payment_method,
          settings,
        });
      }

      setShowCreateModal(false);
      resetForm();
      loadData();
    } catch (err: any) {
      setFeedback({
        type: 'error',
        text: err?.message || 'Error generating document',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setCustomerName('');
    setCustomerMobile('');
    setCustomerAddress('');
    setFormItems([]);
    setDiscount('0');
    setFormNotes('');
    setProductSearch('');
    setMatchedProducts([]);
  };

  const handleConvertToInvoice = async (estId: number, estNumber: string) => {
    const method = window.prompt(
      `Convert Estimate #${estNumber} to Tax Invoice.\nEnter payment method (CASH, UPI, CARD, PAYTM_MANUAL):`,
      'CASH'
    );
    if (!method) return;

    try {
      const inv = await ipcClient.convertEstimateToInvoice(estId, method.trim().toUpperCase() as any);
      alert(`Successfully converted Estimate #${estNumber} to Invoice #${inv.invoice_number}!`);
      loadData();
    } catch (err: any) {
      alert(`Conversion error: ${err?.message}`);
    }
  };

  const handleDeleteEstimate = async (est: Estimate) => {
    if (window.confirm(`Are you sure you want to delete Estimate #${est.estimate_number}?`)) {
      try {
        await ipcClient.deleteEstimate(est.id);
        alert(`Estimate #${est.estimate_number} deleted.`);
        loadData();
      } catch (err: any) {
        alert(`Failed to delete estimate: ${err?.message}`);
      }
    }
  };

  const handleDeleteInvoice = async () => {
    if (!deleteInvoiceTarget) return;
    try {
      setIsDeleting(true);
      const res = await ipcClient.deleteInvoice(deleteInvoiceTarget.id, restoreStockOnInvoiceDelete);
      alert(`Invoice #${res.invoiceNumber} deleted successfully.${restoreStockOnInvoiceDelete ? ' Inventory stock was restored.' : ''}`);
      setDeleteInvoiceTarget(null);
      loadData();
    } catch (err: any) {
      alert(`Failed to delete invoice: ${err?.message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  // Filter by date range
  const filteredEstimates = estimates.filter((e) => {
    if (!startDate && !endDate) return true;
    const dateStr = e.created_at.slice(0, 10);
    if (startDate && dateStr < startDate) return false;
    if (endDate && dateStr > endDate) return false;
    return true;
  });

  const filteredInvoices = invoices.filter((inv) => {
    if (!startDate && !endDate) return true;
    const dateStr = inv.created_at.slice(0, 10);
    if (startDate && dateStr < startDate) return false;
    if (endDate && dateStr > endDate) return false;
    return true;
  });

  return (
    <div id="estimate-invoice-container" className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6 text-purple-400" />
            <span>{t.estimatesAndInvoices}</span>
          </h2>
          <p className="text-xs text-slate-400">
            Create quotations (no stock impact) and tax invoices with barcode scanning
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setCreateType('ESTIMATE');
              resetForm();
              setShowCreateModal(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-md cursor-pointer transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>{t.createEstimateBtn}</span>
          </button>

          <button
            onClick={() => {
              setCreateType('INVOICE');
              resetForm();
              setShowCreateModal(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md cursor-pointer transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>{t.createInvoiceBtn}</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
            feedback.type === 'success'
              ? 'bg-emerald-950/60 border border-emerald-800 text-emerald-300'
              : 'bg-red-950/60 border border-red-800 text-red-300'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
          ) : (
            <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Tabs & Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900 p-3 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2 border-b sm:border-b-0 border-slate-800 pb-2 sm:pb-0">
          <button
            onClick={() => setActiveTab('estimates')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
              activeTab === 'estimates'
                ? 'bg-purple-950 text-purple-300 border border-purple-800'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileClock className="w-3.5 h-3.5" />
            <span>{t.estimatesList}</span>
            <span className="ml-1 px-1.5 py-0.2 rounded-full bg-slate-800 text-[10px] font-mono">
              {filteredEstimates.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('invoices')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-medium cursor-pointer transition-colors ${
              activeTab === 'invoices'
                ? 'bg-blue-950 text-blue-300 border border-blue-800'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>{t.invoicesList}</span>
            <span className="ml-1 px-1.5 py-0.2 rounded-full bg-slate-800 text-[10px] font-mono">
              {filteredInvoices.length}
            </span>
          </button>
        </div>

        {/* Search & Date Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search #, customer..."
              className="pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-blue-500 w-44"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              title="Start Date"
              className="px-2 py-1 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200"
            />
            <span className="text-xs text-slate-500">to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              title="End Date"
              className="px-2 py-1 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200"
            />
            {(startDate || endDate) && (
              <button
                onClick={() => {
                  setStartDate('');
                  setEndDate('');
                }}
                className="p-1 text-slate-400 hover:text-white"
                title="Clear Dates"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Content: Tables */}
      {activeTab === 'estimates' ? (
        <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900 shadow-xl">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3.5">Estimate #</th>
                <th className="p-3.5">Date</th>
                <th className="p-3.5">Customer</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Subtotal (₹)</th>
                <th className="p-3.5 text-right">Discount (₹)</th>
                <th className="p-3.5 text-right">Total (₹)</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {isLoading ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500">
                    Loading estimates...
                  </td>
                </tr>
              ) : filteredEstimates.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500">
                    No estimates found matching your filters.
                  </td>
                </tr>
              ) : (
                filteredEstimates.map((est) => (
                  <tr key={est.id} className="hover:bg-slate-800/40">
                    <td className="p-3.5 font-mono font-semibold text-purple-400">
                      #{est.estimate_number}
                    </td>
                    <td className="p-3.5 text-slate-400">
                      {new Date(est.created_at).toLocaleDateString()}
                    </td>
                    <td className="p-3.5">
                      <div className="font-medium text-slate-200">{est.customer_name || 'Walk-in'}</div>
                      {est.customer_mobile && (
                        <div className="text-[10px] text-slate-500 font-mono">{est.customer_mobile}</div>
                      )}
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono ${
                          est.status === 'CONVERTED'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : 'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}
                      >
                        {est.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-right font-mono text-slate-400">
                      ₹{est.subtotal.toFixed(2)}
                    </td>
                    <td className="p-3.5 text-right font-mono text-slate-400">
                      {est.discount > 0 ? `₹${est.discount.toFixed(2)}` : '—'}
                    </td>
                    <td className="p-3.5 text-right font-mono font-bold text-white">
                      ₹{est.total_amount.toFixed(2)}
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {est.status !== 'CONVERTED' && (
                          <button
                            onClick={() => handleConvertToInvoice(est.id, est.estimate_number)}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 text-[11px] font-medium cursor-pointer transition-colors"
                            title="Convert to Invoice"
                          >
                            <ArrowRightLeft className="w-3.5 h-3.5" />
                            <span>{t.convertToInvoice}</span>
                          </button>
                        )}
                        <button
                          onClick={async () => {
                            const full = await ipcClient.getEstimateById(est.id);
                            if (!full) return;
                            const settings = await ipcClient.getSettings();
                            setPrintableReceipt({
                              title: 'ESTIMATE / QUOTATION',
                              documentNumber: full.estimate_number,
                              date: new Date(full.created_at).toLocaleDateString(),
                              time: new Date(full.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                              customerName: full.customer_name,
                              customerMobile: full.customer_mobile,
                              items: (full.items || []).map((i) => ({
                                name: i.product_name,
                                quantity: i.quantity,
                                rate: i.rate,
                                amount: i.amount,
                              })),
                              subtotal: full.subtotal,
                              discount: full.discount,
                              total: full.total_amount,
                              settings,
                            });
                          }}
                          className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded cursor-pointer"
                          title="Print Estimate"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteEstimate(est)}
                          className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded cursor-pointer"
                          title="Delete Estimate"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      ) : (
        /* Invoices Table */
        <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900 shadow-xl">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3.5">Invoice #</th>
                <th className="p-3.5">Date</th>
                <th className="p-3.5">Customer</th>
                <th className="p-3.5">Payment</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Subtotal (₹)</th>
                <th className="p-3.5 text-right">Discount (₹)</th>
                <th className="p-3.5 text-right">Total Net (₹)</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {isLoading ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-500">
                    Loading invoices...
                  </td>
                </tr>
              ) : filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-500">
                    No invoices found matching your filters.
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-800/40">
                    <td className="p-3.5 font-mono font-semibold text-blue-400">
                      #{inv.invoice_number}
                    </td>
                    <td className="p-3.5 text-slate-400">
                      {new Date(inv.created_at).toLocaleDateString()}
                    </td>
                    <td className="p-3.5">
                      <div className="font-medium text-slate-200">{inv.customer_name || 'Walk-in'}</div>
                      {inv.customer_mobile && (
                        <div className="text-[10px] text-slate-500 font-mono">{inv.customer_mobile}</div>
                      )}
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
                        {inv.payment_method}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800">
                        {inv.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-right font-mono text-slate-400">
                      ₹{inv.subtotal.toFixed(2)}
                    </td>
                    <td className="p-3.5 text-right font-mono text-slate-400">
                      {inv.discount > 0 ? `₹${inv.discount.toFixed(2)}` : '—'}
                    </td>
                    <td className="p-3.5 text-right font-mono font-bold text-emerald-400">
                      ₹{inv.total_amount.toFixed(2)}
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={async () => {
                            const full = await ipcClient.getInvoiceById(inv.id);
                            if (!full) return;
                            const settings = await ipcClient.getSettings();
                            setPrintableReceipt({
                              title: 'TAX INVOICE',
                              documentNumber: full.invoice_number,
                              date: new Date(full.created_at).toLocaleDateString(),
                              time: new Date(full.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                              customerName: full.customer_name,
                              customerMobile: full.customer_mobile,
                              items: (full.items || []).map((i) => ({
                                name: i.product_name,
                                quantity: i.quantity,
                                rate: i.rate,
                                amount: i.amount,
                              })),
                              subtotal: full.subtotal,
                              discount: full.discount,
                              total: full.total_amount,
                              paymentMethod: full.payment_method,
                              settings,
                            });
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium cursor-pointer"
                          title="Print Tax Invoice"
                        >
                          <Printer className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Print</span>
                        </button>
                        <button
                          onClick={() => setDeleteInvoiceTarget(inv)}
                          className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded cursor-pointer"
                          title="Delete Invoice"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Create Modal with Fast Barcode Scan & Search */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
              <h3 className="text-base font-semibold text-slate-100">
                {createType === 'ESTIMATE' ? t.createEstimateBtn : t.createInvoiceBtn}
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateDocument} className="p-5 space-y-4 overflow-y-auto flex-1">
              <div
                className={`p-3 rounded-lg text-xs border ${
                  createType === 'ESTIMATE'
                    ? 'bg-purple-950/40 border-purple-800 text-purple-300'
                    : 'bg-blue-950/40 border-blue-800 text-blue-300'
                }`}
              >
                {createType === 'ESTIMATE' ? t.estimateNoStockNotice : t.invoiceStockNotice}
              </div>

              {/* Customer fields */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Customer Name
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Walk-in Customer"
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-hidden focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Mobile Number
                  </label>
                  <input
                    type="text"
                    value={customerMobile}
                    onChange={(e) => setCustomerMobile(e.target.value)}
                    placeholder="9876543210"
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white font-mono focus:outline-hidden focus:border-blue-500"
                  />
                </div>
              </div>

              {/* Enhanced Product Selector with Barcode Scan & Quick Add */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                    <Barcode className="w-4 h-4 text-blue-400" />
                    <span>Scan or Search Product (பார்கோடு அல்லது தேடல்)</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setQuickAddBarcode('NEW')}
                    className="text-[11px] text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
                  >
                    <PackagePlus className="w-3.5 h-3.5" />
                    <span>+ Quick Add Item</span>
                  </button>
                </div>

                <div className="relative flex items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="text"
                      value={productSearch}
                      onChange={(e) => handleSearchProduct(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          const found = products.find(
                            (p) => p.barcode.toLowerCase() === productSearch.trim().toLowerCase()
                          );
                          if (found) {
                            handleAddItemToForm(found);
                          } else if (matchedProducts.length > 0) {
                            handleAddItemToForm(matchedProducts[0]);
                          } else if (productSearch.trim()) {
                            setQuickAddBarcode(productSearch.trim());
                          }
                        }
                      }}
                      placeholder="Type product name or scan barcode..."
                      className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-blue-500"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowScanner(true)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-blue-950 hover:bg-blue-900 border border-blue-800 text-blue-300 text-xs font-medium cursor-pointer shrink-0 transition-colors"
                    title="Scan Barcode with Camera"
                  >
                    <Camera className="w-4 h-4 text-blue-400" />
                    <span>Scan (கேமரா)</span>
                  </button>
                </div>

                {/* Autocomplete dropdown */}
                {matchedProducts.length > 0 && (
                  <div className="bg-slate-950 border border-slate-700 rounded-xl shadow-2xl overflow-hidden divide-y divide-slate-800 max-h-48 overflow-y-auto z-20">
                    {matchedProducts.map((p) => (
                      <div
                        key={p.id}
                        onClick={() => handleAddItemToForm(p)}
                        className="p-2.5 hover:bg-slate-800/80 cursor-pointer flex items-center justify-between text-xs transition-colors"
                      >
                        <div>
                          <p className="font-semibold text-slate-100">{p.name}</p>
                          <p className="text-[10px] text-slate-400 font-mono">
                            Barcode: {p.barcode} | Stock: {p.current_stock}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-emerald-400">₹{p.selling_price.toFixed(2)}</p>
                          {p.category_name && (
                            <span className="text-[10px] text-slate-500">{p.category_name}</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Added items list */}
              {formItems.length > 0 ? (
                <div className="border border-slate-800 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-950 text-slate-400">
                      <tr>
                        <th className="p-2.5">Item</th>
                        <th className="p-2.5 text-center">Qty</th>
                        <th className="p-2.5 text-right">Rate</th>
                        <th className="p-2.5 text-right">Amt</th>
                        <th className="p-2.5 text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {formItems.map((item) => (
                        <tr key={item.product.id}>
                          <td className="p-2.5 font-medium text-slate-200">
                            <div>{item.product.name}</div>
                            <div className="text-[10px] text-slate-500 font-mono">{item.product.barcode}</div>
                          </td>
                          <td className="p-2.5 text-center">
                            <input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={(e) => {
                                const val = parseInt(e.target.value, 10) || 1;
                                setFormItems(
                                  formItems.map((i) =>
                                    i.product.id === item.product.id
                                      ? { ...i, quantity: Math.max(1, val) }
                                      : i
                                  )
                                );
                              }}
                              className="w-14 px-1 py-0.5 bg-slate-950 border border-slate-700 rounded text-center font-mono text-white text-xs"
                            />
                          </td>
                          <td className="p-2.5 text-right font-mono text-slate-300">
                            ₹{item.rate.toFixed(2)}
                          </td>
                          <td className="p-2.5 text-right font-mono font-bold text-emerald-400">
                            ₹{(item.quantity * item.rate).toFixed(2)}
                          </td>
                          <td className="p-2.5 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveFormItem(item.product.id)}
                              className="p-1 text-red-400 hover:text-red-300 hover:bg-slate-800 rounded cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-4 rounded-xl border border-dashed border-slate-800 text-center text-xs text-slate-500">
                  No items added yet. Search a product or scan barcode above to add.
                </div>
              )}

              {/* Discount & Totals */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400">Discount (₹):</span>
                  <input
                    type="number"
                    min="0"
                    value={discount}
                    onChange={(e) => setDiscount(e.target.value)}
                    className="w-20 px-2 py-1 bg-slate-950 border border-slate-700 rounded text-right font-mono text-white text-xs"
                  />
                </div>

                <div className="text-right">
                  <span className="text-slate-400">Total Net: </span>
                  <span className="text-base font-bold font-mono text-emerald-400">
                    ₹{formTotal.toFixed(2)}
                  </span>
                </div>
              </div>

              {createType === 'INVOICE' && (
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Payment Method
                  </label>
                  <select
                    value={invoicePaymentMethod}
                    onChange={(e) => setInvoicePaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white font-mono"
                  >
                    <option value="CASH">Cash</option>
                    <option value="UPI">UPI</option>
                    <option value="CARD">Card</option>
                    <option value="PAYTM_MANUAL">Paytm Machine (Manual)</option>
                  </select>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-lg text-slate-400 hover:bg-slate-800 text-xs font-medium cursor-pointer"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || formItems.length === 0}
                  className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold shadow-md cursor-pointer transition-colors"
                >
                  {isSubmitting ? 'Generating...' : `Generate ${createType}`}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Invoice Confirmation Modal */}
      {deleteInvoiceTarget && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full shadow-2xl p-6 space-y-4">
            <div className="flex items-center gap-3 text-red-400">
              <AlertCircle className="w-6 h-6 shrink-0" />
              <h3 className="text-base font-bold text-white">
                Delete Invoice #{deleteInvoiceTarget.invoice_number}?
              </h3>
            </div>

            <p className="text-xs text-slate-300">
              Are you sure you want to delete this invoice for{' '}
              <strong className="text-white">₹{deleteInvoiceTarget.total_amount.toFixed(2)}</strong>?
            </p>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <label className="flex items-center gap-2.5 cursor-pointer text-xs text-slate-200">
                <input
                  type="checkbox"
                  checked={restoreStockOnInvoiceDelete}
                  onChange={(e) => setRestoreStockOnInvoiceDelete(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-900 text-blue-500 w-4 h-4"
                />
                <span>Restore product stock inventory levels automatically</span>
              </label>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteInvoiceTarget(null)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-lg text-slate-400 hover:bg-slate-800 text-xs font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteInvoice}
                disabled={isDeleting}
                className="px-5 py-2 rounded-lg bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-xs font-bold cursor-pointer transition-colors shadow-md"
              >
                {isDeleting ? 'Deleting...' : 'Delete Invoice'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Barcode Camera Scanner Modal */}
      {showScanner && (
        <BarcodeScannerModal
          isOpen={showScanner}
          onScan={handleBarcodeScanned}
          onClose={() => setShowScanner(false)}
          title="Scan Item for Estimate"
          instruction="Point camera at product barcode"
        />
      )}

      {/* Quick Add Product Modal */}
      {quickAddBarcode && (
        <QuickAddProductModal
          initialBarcode={quickAddBarcode === 'NEW' ? '' : quickAddBarcode}
          categories={categories}
          currentLang={currentLang}
          onClose={() => setQuickAddBarcode(null)}
          onSuccess={(newProduct) => {
            setProducts((prev) => [...prev, newProduct]);
            handleAddItemToForm(newProduct);
            setQuickAddBarcode(null);
          }}
        />
      )}

      {/* Printable Receipt Modal */}
      {printableReceipt && (
        <ReceiptModal
          receiptData={printableReceipt}
          currentLang={currentLang}
          onClose={() => setPrintableReceipt(null)}
        />
      )}
    </div>
  );
};
