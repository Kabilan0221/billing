import React, { useState, useEffect } from 'react';
import {
  Package,
  Plus,
  Search,
  Edit2,
  Trash2,
  Upload,
  Barcode,
  FolderPlus,
  AlertTriangle,
  CheckCircle2,
  Camera,
  Sparkles,
  Printer,
  X,
} from 'lucide-react';
import { Category, Product } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { BulkImportModal } from '../components/BulkImportModal';
import { generateUniqueBarcode } from '../utils/barcode';
import { BarcodeScannerModal } from '../components/BarcodeScannerModal';
import { BarcodeVisual } from '../components/BarcodeVisual';

interface ProductsPageProps {
  currentLang: Language;
}

export const ProductsPage: React.FC<ProductsPageProps> = ({ currentLang }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<number | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);

  // Add / Edit Modal state
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');
  const [showBulkImport, setShowBulkImport] = useState(false);

  // Barcode actions
  const [showScanner, setShowScanner] = useState(false);
  const [barcodeModalProd, setBarcodeModalProd] = useState<Product | null>(null);

  const [formError, setFormError] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  const t = translations[currentLang];

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [prods, cats] = await Promise.all([
        ipcClient.getProducts(search, selectedCategory),
        ipcClient.getCategories(),
      ]);
      setProducts(prods);
      setCategories(cats);
    } catch (err) {
      console.error('Failed to load products:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [search, selectedCategory]);

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct?.name?.trim()) {
      setFormError('Product name is required');
      return;
    }

    const finalBarcode = (editingProduct.barcode || '').trim() || generateUniqueBarcode(products.map((p) => p.barcode));

    if (editingProduct?.selling_price === undefined || editingProduct.selling_price < 0) {
      setFormError('Valid selling price is required');
      return;
    }

    try {
      await ipcClient.saveProduct({
        ...editingProduct,
        barcode: finalBarcode,
      });
      setEditingProduct(null);
      setFormError('');
      setFeedback('Product saved successfully in SQLite database');
      loadData();
    } catch (err: any) {
      setFormError(err?.message || 'Error saving product');
    }
  };

  const handleDeleteProduct = async (id: number, name: string) => {
    if (window.confirm(`Are you sure you want to delete product '${name}'? This cannot be undone.`)) {
      try {
        await ipcClient.deleteProduct(id);
        setFeedback(`Deleted product '${name}'`);
        loadData();
      } catch (err: any) {
        alert(err?.message || 'Failed to delete product');
      }
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    try {
      await ipcClient.addCategory(newCatName.trim(), newCatDesc.trim());
      setNewCatName('');
      setNewCatDesc('');
      setShowCategoryModal(false);
      loadData();
    } catch (err: any) {
      alert(err?.message || 'Failed to add category');
    }
  };

  const handleGenerateBarcodeForEdit = () => {
    const existing = products.map((p) => p.barcode);
    const code = generateUniqueBarcode(existing);
    setEditingProduct((prev) => (prev ? { ...prev, barcode: code } : null));
  };

  return (
    <div id="products-page-container" className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Package className="w-6 h-6 text-blue-400" />
            <span>{t.productsCatalog}</span>
          </h2>
          <p className="text-xs text-slate-400">
            Manage items, barcodes, prices, categories, and inventory stock
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setShowCategoryModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium cursor-pointer transition-colors"
          >
            <FolderPlus className="w-4 h-4 text-emerald-400" />
            <span>+ Category</span>
          </button>

          <button
            onClick={() => setShowBulkImport(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium cursor-pointer transition-colors"
          >
            <Upload className="w-4 h-4 text-cyan-400" />
            <span>{t.bulkImport}</span>
          </button>

          <button
            onClick={() => {
              const defaultBarcode = generateUniqueBarcode(products.map((p) => p.barcode));
              setEditingProduct({
                name: '',
                barcode: defaultBarcode,
                category_id: categories[0]?.id,
                selling_price: 0,
                purchase_price: 0,
                opening_stock: 50,
                min_stock_level: 5,
              });
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-900/30 cursor-pointer transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addProduct}</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-slate-900 p-3 rounded-xl border border-slate-800">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.searchProducts}
            className="w-full pl-9 pr-4 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-blue-500"
          />
        </div>

        <div className="w-full sm:w-56">
          <select
            value={selectedCategory || ''}
            onChange={(e) =>
              setSelectedCategory(e.target.value ? Number(e.target.value) : undefined)
            }
            className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-blue-500"
          >
            <option value="">{t.allCategories}</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Product Table */}
      <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900 shadow-xl">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider border-b border-slate-800">
            <tr>
              <th className="p-3.5">#</th>
              <th className="p-3.5">{t.productName}</th>
              <th className="p-3.5">{t.barcode}</th>
              <th className="p-3.5">{t.category}</th>
              <th className="p-3.5 text-right">{t.purchasePrice} (₹)</th>
              <th className="p-3.5 text-right">{t.sellingPrice} (₹)</th>
              <th className="p-3.5 text-center">{t.currentStock}</th>
              <th className="p-3.5 text-center">{t.minStock}</th>
              <th className="p-3.5 text-center">{t.action}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {isLoading ? (
              <tr>
                <td colSpan={9} className="p-8 text-center text-slate-500">
                  Loading SQLite products...
                </td>
              </tr>
            ) : products.length === 0 ? (
              <tr>
                <td colSpan={9} className="p-8 text-center text-slate-500">
                  No products found. Click "+ Add New Product" or "Bulk Import" to populate your inventory.
                </td>
              </tr>
            ) : (
              products.map((p, idx) => {
                const isLowStock = p.current_stock <= p.min_stock_level;
                return (
                  <tr key={p.id} className="hover:bg-slate-800/40">
                    <td className="p-3.5 font-mono text-slate-500">{idx + 1}</td>
                    <td className="p-3.5 font-medium text-slate-100">{p.name}</td>
                    <td className="p-3.5 font-mono text-slate-300">
                      <button
                        onClick={() => setBarcodeModalProd(p)}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 border border-slate-700 text-[11px] text-cyan-300 cursor-pointer"
                        title="Click to view & print barcode sticker"
                      >
                        <Barcode className="w-3 h-3 text-cyan-400" />
                        <span>{p.barcode}</span>
                      </button>
                    </td>
                    <td className="p-3.5 text-slate-400">{p.category_name || '—'}</td>
                    <td className="p-3.5 text-right font-mono text-slate-400">
                      ₹{p.purchase_price.toFixed(2)}
                    </td>
                    <td className="p-3.5 text-right font-mono font-bold text-emerald-400">
                      ₹{p.selling_price.toFixed(2)}
                    </td>
                    <td className="p-3.5 text-center font-bold">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] ${
                          isLowStock
                            ? 'bg-amber-950/80 text-amber-300 border border-amber-800'
                            : 'bg-emerald-950/40 text-emerald-400'
                        }`}
                      >
                        {isLowStock && <AlertTriangle className="w-3 h-3 text-amber-400" />}
                        {p.current_stock}
                      </span>
                    </td>
                    <td className="p-3.5 text-center text-slate-400">{p.min_stock_level}</td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setBarcodeModalProd(p)}
                          className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded cursor-pointer transition-colors"
                          title="Print Barcode Label"
                        >
                          <Barcode className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setEditingProduct(p)}
                          className="p-1.5 text-slate-400 hover:text-blue-400 hover:bg-slate-800 rounded cursor-pointer transition-colors"
                          title="Edit Product"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(p.id, p.name)}
                          className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded cursor-pointer transition-colors"
                          title="Delete Product"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Add / Edit Product Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
              <h3 className="text-base font-semibold text-white">
                {editingProduct.id ? t.editProduct : t.addProduct}
              </h3>
              <button
                onClick={() => setEditingProduct(null)}
                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="p-5 space-y-4 overflow-y-auto">
              {formError && (
                <div className="p-2.5 rounded-lg bg-red-950 border border-red-800 text-red-300 text-xs">
                  {formError}
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {t.productName} *
                </label>
                <input
                  type="text"
                  required
                  value={editingProduct.name || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                  placeholder="e.g. Classic Ball Pen (Blue)"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-hidden focus:border-blue-500"
                />
              </div>

              {/* Barcode input with Camera Scan and Generate buttons */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-medium text-slate-300">
                    {t.barcode} (பார்கோடு) *
                  </label>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setShowScanner(true)}
                      className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded bg-blue-950 hover:bg-blue-900 text-blue-300 text-[11px] font-medium border border-blue-800/80 cursor-pointer transition-colors"
                      title="Scan barcode with camera"
                    >
                      <Camera className="w-3 h-3 text-blue-400" />
                      <span>Scan (ஸ்கேன்)</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleGenerateBarcodeForEdit}
                      className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded bg-emerald-950 hover:bg-emerald-900 text-emerald-300 text-[11px] font-medium border border-emerald-800/80 cursor-pointer transition-colors"
                      title="Generate new standard barcode"
                    >
                      <Sparkles className="w-3 h-3 text-emerald-400" />
                      <span>Generate (உருவாக்கு)</span>
                    </button>
                  </div>
                </div>
                <input
                  type="text"
                  required
                  value={editingProduct.barcode || ''}
                  onChange={(e) =>
                    setEditingProduct({ ...editingProduct, barcode: e.target.value })
                  }
                  placeholder="Enter or scan barcode..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white font-mono focus:outline-hidden focus:border-blue-500"
                />

                {editingProduct.barcode && editingProduct.barcode.trim() && (
                  <div className="mt-2">
                    <BarcodeVisual
                      value={editingProduct.barcode.trim()}
                      height={32}
                      showText={true}
                      fontSize={10}
                      productName={editingProduct.name || undefined}
                      price={editingProduct.selling_price || undefined}
                    />
                  </div>
                )}
              </div>

              {/* Category selector */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-medium text-slate-300">
                    {t.category}
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowCategoryModal(true)}
                    className="text-[11px] text-blue-400 hover:text-blue-300 flex items-center gap-1 cursor-pointer"
                  >
                    <FolderPlus className="w-3 h-3" />
                    <span>+ New Category</span>
                  </button>
                </div>
                <select
                  value={editingProduct.category_id || ''}
                  onChange={(e) =>
                    setEditingProduct({
                      ...editingProduct,
                      category_id: e.target.value ? Number(e.target.value) : undefined,
                    })
                  }
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-hidden focus:border-blue-500"
                >
                  <option value="">-- Select Category --</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    {t.sellingPrice} (₹) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0"
                    required
                    value={editingProduct.selling_price ?? ''}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        selling_price: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-bold text-emerald-400 focus:outline-hidden focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    {t.purchasePrice} (₹)
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0"
                    value={editingProduct.purchase_price ?? ''}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        purchase_price: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-hidden focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {!editingProduct.id && (
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      {t.openingStock}
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={editingProduct.opening_stock ?? 0}
                      onChange={(e) =>
                        setEditingProduct({
                          ...editingProduct,
                          opening_stock: parseInt(e.target.value, 10) || 0,
                        })
                      }
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-hidden focus:border-blue-500"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    {t.minStock}
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={editingProduct.min_stock_level ?? 5}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        min_stock_level: parseInt(e.target.value, 10) || 5,
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-hidden focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-4 py-2 rounded-lg text-slate-400 hover:bg-slate-800 text-xs font-medium cursor-pointer"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md cursor-pointer transition-colors"
                >
                  {editingProduct.id ? t.save : t.addProduct}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Category Modal */}
      {showCategoryModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-semibold text-white">Create New Category</h3>
              <button
                onClick={() => setShowCategoryModal(false)}
                className="p-1 rounded text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddCategory} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Category Name *</label>
                <input
                  type="text"
                  required
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  placeholder="e.g. Art & Craft"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Description</label>
                <input
                  type="text"
                  value={newCatDesc}
                  onChange={(e) => setNewCatDesc(e.target.value)}
                  placeholder="Optional notes"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCategoryModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
                >
                  Save Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Barcode View / Print Label Modal */}
      {barcodeModalProd && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-sm w-full shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Barcode className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-white">Barcode Label Sticker</h3>
              </div>
              <button
                onClick={() => setBarcodeModalProd(null)}
                className="p-1 rounded text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-2">
              <BarcodeVisual
                value={barcodeModalProd.barcode}
                productName={barcodeModalProd.name}
                price={barcodeModalProd.selling_price}
                showActions={true}
                height={50}
                width={2}
              />
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setBarcodeModalProd(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Barcode Camera Scanner Modal */}
      {showScanner && (
        <BarcodeScannerModal
          isOpen={showScanner}
          onScan={(code) => {
            setEditingProduct((prev) => (prev ? { ...prev, barcode: code } : null));
            setShowScanner(false);
          }}
          onClose={() => setShowScanner(false)}
          title="Scan Product Barcode"
          instruction="Position product barcode in front of the camera"
        />
      )}

      {/* Bulk Import Modal */}
      {showBulkImport && (
        <BulkImportModal
          onSuccess={() => {
            setShowBulkImport(false);
            loadData();
          }}
          onClose={() => setShowBulkImport(false)}
          currentLang={currentLang}
        />
      )}
    </div>
  );
};
