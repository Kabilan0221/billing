import React, { useState, useEffect } from 'react';
import { Users, Search, Phone, MapPin, Receipt, Wallet } from 'lucide-react';
import { Customer } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';

interface CustomersPageProps {
  currentLang: Language;
}

export const CustomersPage: React.FC<CustomersPageProps> = ({ currentLang }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const t = translations[currentLang];

  const loadCustomers = async () => {
    try {
      setIsLoading(true);
      const data = await ipcClient.getCustomers(search);
      setCustomers(data);
    } catch (err) {
      console.error('Failed to load customers:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, [search]);

  return (
    <div id="customers-page-container" className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Users className="w-6 h-6 text-blue-400" />
            <span>{t.customers}</span>
          </h2>
          <p className="text-xs text-slate-400">
            Local customer ledger tracking spending and transaction frequency
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl text-xs text-slate-400">
          <span>Registered Customers:</span>
          <span className="font-bold text-white font-mono">{customers.length}</span>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative bg-slate-900 p-3 rounded-xl border border-slate-800">
        <Search className="w-4 h-4 absolute left-6 top-5.5 text-slate-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={t.searchCustomers}
          className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-blue-500"
        />
      </div>

      {/* Customers Table */}
      <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900 shadow-xl">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider border-b border-slate-800">
            <tr>
              <th className="p-3.5">#</th>
              <th className="p-3.5">{t.customerName}</th>
              <th className="p-3.5">{t.customerMobile}</th>
              <th className="p-3.5">{t.customerAddress}</th>
              <th className="p-3.5 text-center">{t.billsCount}</th>
              <th className="p-3.5 text-right">{t.totalSpent} (₹)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {isLoading ? (
              <tr>
                <td colSpan={6} className="p-8 text-center text-slate-500">
                  Loading SQLite customer directory...
                </td>
              </tr>
            ) : customers.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-8 text-center text-slate-500">
                  No registered customers yet. Enter customer names or mobile numbers during POS billing to register them automatically.
                </td>
              </tr>
            ) : (
              customers.map((c, idx) => (
                <tr key={c.id} className="hover:bg-slate-800/40">
                  <td className="p-3.5 font-mono text-slate-500">{idx + 1}</td>
                  <td className="p-3.5 font-semibold text-slate-100">{c.name}</td>
                  <td className="p-3.5 font-mono text-slate-300">{c.mobile || '—'}</td>
                  <td className="p-3.5 text-slate-400 truncate max-w-xs">{c.address || '—'}</td>
                  <td className="p-3.5 text-center">
                    <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                      {c.bills_count || 0}
                    </span>
                  </td>
                  <td className="p-3.5 text-right font-mono font-bold text-emerald-400">
                    ₹{(c.total_spent || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
