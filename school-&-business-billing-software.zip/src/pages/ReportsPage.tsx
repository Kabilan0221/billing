import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Calendar,
  DollarSign,
  Receipt,
  Boxes,
  Download,
  Printer,
  Banknote,
  Smartphone,
  CreditCard,
  Layers,
} from 'lucide-react';
import { SalesReportData } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';

interface ReportsPageProps {
  currentLang: Language;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ currentLang }) => {
  const today = new Date().toISOString().split('T')[0];
  const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0];

  const [startDate, setStartDate] = useState(thirtyDaysAgo);
  const [endDate, setEndDate] = useState(today);
  const [report, setReport] = useState<SalesReportData | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const t = translations[currentLang];

  const loadReport = async () => {
    try {
      setIsLoading(true);
      const data = await ipcClient.getSalesReport(startDate, endDate);
      setReport(data);
    } catch (err) {
      console.error('Failed to load sales report:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadReport();
  }, []);

  const handleExportCsv = () => {
    if (!report) return;

    let csv = 'Product Wise Sales Performance\n';
    csv += 'Product Name,Barcode,Quantity Sold,Total Revenue (INR)\n';
    for (const item of report.productSales) {
      csv += `"${item.product_name}","${item.barcode || ''}",${item.total_quantity},${item.total_revenue.toFixed(2)}\n`;
    }

    csv += '\nDaily Sales Trend\nDate,Bills Count,Daily Total (INR)\n';
    for (const day of report.dailySales) {
      csv += `${day.date},${day.bill_count},${day.total_amount.toFixed(2)}\n`;
    }

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Sales_Report_${startDate}_to_${endDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div id="reports-page-container" className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-blue-400" />
            <span>{t.reports}</span>
          </h2>
          <p className="text-xs text-slate-400">
            Offline SQLite analytical sales metrics, payment method breakdowns, and product trends
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            disabled={!report}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 cursor-pointer transition-colors"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            <span>{t.exportCsv}</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md cursor-pointer transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>{t.printReport}</span>
          </button>
        </div>
      </div>

      {/* Date Filter Toolbar */}
      <div className="flex flex-wrap items-center gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800">
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">{t.startDate}:</span>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
          />
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">{t.endDate}:</span>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white"
          />
        </div>

        <button
          onClick={loadReport}
          disabled={isLoading}
          className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer shadow transition-colors"
        >
          {isLoading ? 'Computing...' : t.generateReport}
        </button>
      </div>

      {report && (
        <div className="space-y-6">
          {/* Top High-Level Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-xl border bg-emerald-950/40 border-emerald-800/60 shadow-md flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400">Total Net Revenue</p>
                <p className="text-2xl font-bold font-mono text-emerald-400">
                  ₹{report.totalSales.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-emerald-900/50 text-emerald-400 flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>

            <div className="p-5 rounded-xl border bg-blue-950/40 border-blue-800/60 shadow-md flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400">Total Bills Processed</p>
                <p className="text-2xl font-bold font-mono text-blue-400">{report.totalBills}</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-blue-900/50 text-blue-400 flex items-center justify-center">
                <Receipt className="w-5 h-5" />
              </div>
            </div>

            <div className="p-5 rounded-xl border bg-indigo-950/40 border-indigo-800/60 shadow-md flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400">Total Items Sold</p>
                <p className="text-2xl font-bold font-mono text-indigo-400">
                  {report.totalQuantity}
                </p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-indigo-900/50 text-indigo-400 flex items-center justify-center">
                <Boxes className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* Payment Method Breakdown Cards */}
          <div className="space-y-2">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Payment Breakdown (Direct Cash / UPI / Card / Split / Paytm)
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                  <Banknote className="w-3.5 h-3.5" />
                  <span>{t.cashSales}</span>
                </div>
                <p className="text-base font-bold font-mono text-white">
                  ₹{report.cashSales.toFixed(2)}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 text-xs text-blue-400 font-medium">
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>{t.upiSales}</span>
                </div>
                <p className="text-base font-bold font-mono text-white">
                  ₹{report.upiSales.toFixed(2)}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 text-xs text-purple-400 font-medium">
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>{t.cardSales}</span>
                </div>
                <p className="text-base font-bold font-mono text-white">
                  ₹{report.cardSales.toFixed(2)}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 text-xs text-indigo-400 font-medium">
                  <Layers className="w-3.5 h-3.5" />
                  <span>{t.splitSales}</span>
                </div>
                <p className="text-base font-bold font-mono text-white">
                  ₹{report.splitSales.toFixed(2)}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 text-xs text-cyan-400 font-medium">
                  <span>{t.paytmSales}</span>
                </div>
                <p className="text-base font-bold font-mono text-white">
                  ₹{report.paytmSales.toFixed(2)}
                </p>
              </div>
            </div>
          </div>

          {/* Product Wise Sales Table */}
          <div className="space-y-2">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              {t.productPerformance}
            </h3>
            <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900 shadow-xl">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="p-3.5">#</th>
                    <th className="p-3.5">Product Name</th>
                    <th className="p-3.5">Barcode</th>
                    <th className="p-3.5 text-center">Quantity Sold</th>
                    <th className="p-3.5 text-right">Total Revenue (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {report.productSales.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-6 text-center text-slate-500">
                        No product sales recorded in selected timeframe.
                      </td>
                    </tr>
                  ) : (
                    report.productSales.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/40">
                        <td className="p-3.5 font-mono text-slate-500">{idx + 1}</td>
                        <td className="p-3.5 font-semibold text-slate-200">{item.product_name}</td>
                        <td className="p-3.5 font-mono text-slate-400">{item.barcode || '—'}</td>
                        <td className="p-3.5 text-center font-bold text-slate-200">
                          {item.total_quantity}
                        </td>
                        <td className="p-3.5 text-right font-mono font-bold text-emerald-400">
                          ₹{item.total_revenue.toFixed(2)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Daily Trend Table */}
          <div className="space-y-2">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              {t.dailyTrend}
            </h3>
            <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900 shadow-xl">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="p-3.5">Date</th>
                    <th className="p-3.5 text-center">Bills Count</th>
                    <th className="p-3.5 text-right">Total Net Sales (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {report.dailySales.map((day, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/40">
                      <td className="p-3.5 font-mono font-medium text-slate-200">{day.date}</td>
                      <td className="p-3.5 text-center font-mono text-slate-300">{day.bill_count}</td>
                      <td className="p-3.5 text-right font-mono font-bold text-emerald-400">
                        ₹{day.total_amount.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
