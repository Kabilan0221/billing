import React, { useState, useEffect } from 'react';
import { CreditCard, Banknote, Smartphone, Layers, Search, Filter } from 'lucide-react';
import { Payment, PaymentMethod } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';

interface PaymentsPageProps {
  currentLang: Language;
}

export const PaymentsPage: React.FC<PaymentsPageProps> = ({ currentLang }) => {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [methodFilter, setMethodFilter] = useState<string>('ALL');
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const t = translations[currentLang];

  const loadPayments = async () => {
    try {
      setIsLoading(true);
      const data = await ipcClient.getPayments();
      setPayments(data);
    } catch (err) {
      console.error('Failed to load payments:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadPayments();
  }, []);

  const filteredPayments = payments.filter((p) => {
    const matchesMethod = methodFilter === 'ALL' || p.payment_method === methodFilter;
    const matchesSearch =
      !search ||
      p.bill_number?.toLowerCase().includes(search.toLowerCase()) ||
      p.notes?.toLowerCase().includes(search.toLowerCase());
    return matchesMethod && matchesSearch;
  });

  const totalCollected = filteredPayments.reduce((acc, curr) => acc + curr.amount, 0);

  const getMethodBadge = (method: PaymentMethod) => {
    switch (method) {
      case 'CASH':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-950/60 text-emerald-400 border border-emerald-800/80">
            <Banknote className="w-3 h-3" />
            Cash
          </span>
        );
      case 'UPI':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-blue-950/60 text-blue-400 border border-blue-800/80">
            <Smartphone className="w-3 h-3" />
            UPI
          </span>
        );
      case 'CARD':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-purple-950/60 text-purple-400 border border-purple-800/80">
            <CreditCard className="w-3 h-3" />
            Card
          </span>
        );
      case 'SPLIT':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-950/60 text-indigo-400 border border-indigo-800/80">
            <Layers className="w-3 h-3" />
            Split
          </span>
        );
      case 'PAYTM_MANUAL':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-cyan-950/60 text-cyan-400 border border-cyan-800/80">
            Paytm Machine (Manual)
          </span>
        );
      default:
        return <span>{method}</span>;
    }
  };

  return (
    <div id="payments-page-container" className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-blue-400" />
            <span>{t.payments}</span>
          </h2>
          <p className="text-xs text-slate-400">
            Local transaction ledger: Cash, UPI, Cards, Split breakdowns, and Paytm manual records
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl">
          <span className="text-xs text-slate-400">Total Filtered Amount:</span>
          <span className="text-lg font-bold font-mono text-emerald-400">
            ₹{totalCollected.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </span>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-slate-900 p-3 rounded-xl border border-slate-800">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by Bill # or reference note..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-blue-500"
          />
        </div>

        <select
          value={methodFilter}
          onChange={(e) => setMethodFilter(e.target.value)}
          className="w-full sm:w-56 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-blue-500"
        >
          <option value="ALL">All Payment Methods</option>
          <option value="CASH">Cash</option>
          <option value="UPI">UPI</option>
          <option value="CARD">Credit / Debit Card</option>
          <option value="SPLIT">Split Payment</option>
          <option value="PAYTM_MANUAL">Paytm Machine (Manual)</option>
        </select>
      </div>

      {/* Table */}
      <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900 shadow-xl">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider border-b border-slate-800">
            <tr>
              <th className="p-3.5">#</th>
              <th className="p-3.5">Bill Number</th>
              <th className="p-3.5">Payment Method</th>
              <th className="p-3.5 text-right">Amount Paid (₹)</th>
              <th className="p-3.5">Split / Tender Details</th>
              <th className="p-3.5">Date & Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {isLoading ? (
              <tr>
                <td colSpan={6} className="p-8 text-center text-slate-500">
                  Loading SQLite payment records...
                </td>
              </tr>
            ) : filteredPayments.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-8 text-center text-slate-500">
                  No payment records found. Completed sales in POS will automatically register here.
                </td>
              </tr>
            ) : (
              filteredPayments.map((p, idx) => (
                <tr key={p.id} className="hover:bg-slate-800/40">
                  <td className="p-3.5 font-mono text-slate-500">{idx + 1}</td>
                  <td className="p-3.5 font-mono font-medium text-slate-200">
                    {p.bill_number ? `#${p.bill_number}` : 'Direct Payment'}
                  </td>
                  <td className="p-3.5">{getMethodBadge(p.payment_method)}</td>
                  <td className="p-3.5 text-right font-mono font-bold text-emerald-400">
                    ₹{p.amount.toFixed(2)}
                  </td>
                  <td className="p-3.5 text-slate-400 text-[11px] font-mono">
                    {p.split_details ? (
                      <span className="text-indigo-300">{p.split_details}</span>
                    ) : p.notes ? (
                      p.notes
                    ) : (
                      '—'
                    )}
                  </td>
                  <td className="p-3.5 text-slate-400">
                    {new Date(p.created_at).toLocaleString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
