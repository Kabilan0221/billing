import React, { useState, useEffect, useRef } from 'react';
import {
  Barcode,
  Search,
  Plus,
  Minus,
  Trash2,
  User,
  Phone,
  CreditCard,
  Banknote,
  Smartphone,
  Layers,
  Printer,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  PackagePlus,
  Camera,
} from 'lucide-react';
import { Bill, Category, PaymentMethod, Product, SplitPaymentDetail } from '../types';
import { ipcClient } from '../services/ipc-client';
import { Language, translations } from '../i18n/translations';
import { QuickAddProductModal } from '../components/QuickAddProductModal';
import { ReceiptModal } from '../components/ReceiptModal';
import { PrintableReceiptData } from '../printing/thermal-printer';
import { BarcodeScannerModal } from '../components/BarcodeScannerModal';

interface PosBillingPageProps {
  currentLang: Language;
}

interface CartItem {
  product: Product;
  quantity: number;
  rate: number;
  amount: number;
}

export const PosBillingPage: React.FC<PosBillingPageProps> = ({ currentLang }) => {
  const [barcodeInput, setBarcodeInput] = useState('');
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [isSearchingProducts, setIsSearchingProducts] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);

  // Cart state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [discount, setDiscount] = useState<string>('0');

  // Customer state
  const [customerName, setCustomerName] = useState('');
  const [customerMobile, setCustomerMobile] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');

  // Payment state
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CASH');
  const [cashTendered, setCashTendered] = useState<string>('');
  const [splitDetails, setSplitDetails] = useState<SplitPaymentDetail>({
    cash: 0,
    upi: 0,
    card: 0,
    paytm: 0,
  });
  const [notes, setNotes] = useState('');

  // Modals & Feedback
  const [quickAddBarcode, setQuickAddBarcode] = useState<string | null>(null);
  const [showCameraScanner, setShowCameraScanner] = useState(false);
  const [completedReceipt, setCompletedReceipt] = useState<PrintableReceiptData | null>(null);
  const [isProcessingSale, setIsProcessingSale] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const t = translations[currentLang];

  useEffect(() => {
    loadProductsAndCategories();
    barcodeInputRef.current?.focus();
  }, []);

  const loadProductsAndCategories = async () => {
    try {
      const [prods, cats] = await Promise.all([
        ipcClient.getProducts(),
        ipcClient.getCategories(),
      ]);
      setAllProducts(prods);
      setCategories(cats);
    } catch (err) {
      console.error('Failed to load products/categories:', err);
    }
  };

  // Barcode / Search handler
  const handleBarcodeSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const query = barcodeInput.trim();
    if (!query) return;

    // 1. Exact Barcode lookup
    const foundByBarcode = await ipcClient.getProductByBarcode(query);
    if (foundByBarcode) {
      addItemToCart(foundByBarcode);
      setBarcodeInput('');
      setFilteredProducts([]);
      return;
    }

    // 2. Name search matching
    const matching = allProducts.filter((p) =>
      p.name.toLowerCase().includes(query.toLowerCase())
    );
    if (matching.length === 1) {
      addItemToCart(matching[0]);
      setBarcodeInput('');
      setFilteredProducts([]);
      return;
    } else if (matching.length > 1) {
      setFilteredProducts(matching);
      return;
    }

    // 3. Not found -> prompt Quick Add Product without leaving workflow
    setQuickAddBarcode(query);
    setBarcodeInput('');
    setFilteredProducts([]);
  };

  const handleSearchChange = (val: string) => {
    setBarcodeInput(val);
    if (!val.trim()) {
      setFilteredProducts([]);
      return;
    }
    const matches = allProducts.filter(
      (p) =>
        p.name.toLowerCase().includes(val.toLowerCase()) ||
        p.barcode.toLowerCase().includes(val.toLowerCase())
    );
    setFilteredProducts(matches.slice(0, 8));
  };

  const addItemToCart = (product: Product) => {
    setCart((prev) => {
      const existingIdx = prev.findIndex((item) => item.product.id === product.id);
      if (existingIdx >= 0) {
        const updated = [...prev];
        const currentItem = updated[existingIdx];
        const newQty = currentItem.quantity + 1;
        updated[existingIdx] = {
          ...currentItem,
          quantity: newQty,
          amount: newQty * currentItem.rate,
        };
        return updated;
      } else {
        return [
          ...prev,
          {
            product,
            quantity: 1,
            rate: product.selling_price,
            amount: product.selling_price,
          },
        ];
      }
    });
    setFilteredProducts([]);
    barcodeInputRef.current?.focus();
  };

  const updateQuantity = (productId: number, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            if (newQty <= 0) return null;
            return {
              ...item,
              quantity: newQty,
              amount: newQty * item.rate,
            };
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const updateItemRate = (productId: number, newRate: number) => {
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === productId) {
          const rate = Math.max(0, newRate);
          return {
            ...item,
            rate,
            amount: item.quantity * rate,
          };
        }
        return item;
      })
    );
  };

  const removeFromCart = (productId: number) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
    setDiscount('0');
    setCashTendered('');
    setNotes('');
    setFeedbackMsg(null);
    barcodeInputRef.current?.focus();
  };

  // Calculations
  const subtotal = cart.reduce((sum, item) => sum + item.amount, 0);
  const discountVal = Math.min(subtotal, Math.max(0, parseFloat(discount) || 0));
  const totalAmount = Math.max(0, subtotal - discountVal);

  const tendered = parseFloat(cashTendered) || 0;
  const changeDue = paymentMethod === 'CASH' && tendered >= totalAmount ? tendered - totalAmount : 0;

  // Complete Sale & Print Bill
  const handleCompleteSale = async () => {
    if (cart.length === 0) {
      setFeedbackMsg({ type: 'error', text: 'Cart is empty. Add products to continue.' });
      return;
    }

    if (paymentMethod === 'SPLIT') {
      const splitSum =
        (splitDetails.cash || 0) +
        (splitDetails.upi || 0) +
        (splitDetails.card || 0) +
        (splitDetails.paytm || 0);
      if (Math.abs(splitSum - totalAmount) > 0.01) {
        setFeedbackMsg({
          type: 'error',
          text: `Split payment total (₹${splitSum.toFixed(2)}) must equal bill total (₹${totalAmount.toFixed(2)})`,
        });
        return;
      }
    }

    try {
      setIsProcessingSale(true);
      setFeedbackMsg(null);

      const bill = await ipcClient.createBill({
        customerName: customerName.trim() || undefined,
        customerMobile: customerMobile.trim() || undefined,
        customerAddress: customerAddress.trim() || undefined,
        items: cart.map((item) => ({
          product_id: item.product.id,
          quantity: item.quantity,
          rate: item.rate,
        })),
        discount: discountVal,
        paymentMethod,
        cashTendered: paymentMethod === 'CASH' ? tendered || totalAmount : undefined,
        changeDue: paymentMethod === 'CASH' ? changeDue : undefined,
        splitDetails: paymentMethod === 'SPLIT' ? JSON.stringify(splitDetails) : undefined,
        notes: notes.trim() || undefined,
      });

      const settings = await ipcClient.getSettings();

      // Format printable receipt data
      const receipt: PrintableReceiptData = {
        title: 'BILL',
        documentNumber: bill.bill_number,
        date: new Date(bill.created_at).toLocaleDateString(),
        time: new Date(bill.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        customerName: bill.customer_name,
        customerMobile: bill.customer_mobile,
        items: cart.map((i) => ({
          name: i.product.name,
          quantity: i.quantity,
          rate: i.rate,
          amount: i.amount,
        })),
        subtotal: bill.subtotal,
        discount: bill.discount,
        total: bill.total_amount,
        paymentMethod: bill.payment_method,
        cashTendered: bill.cash_tendered,
        changeDue: bill.change_due,
        splitDetails: bill.split_details,
        settings,
      };

      setCompletedReceipt(receipt);
      setFeedbackMsg({ type: 'success', text: `${t.billCompletedSuccess} Bill #${bill.bill_number}` });

      // Refresh product stock list in background
      loadProductsAndCategories();

      // Clear current cart for next customer
      clearCart();
    } catch (err: any) {
      setFeedbackMsg({ type: 'error', text: err?.message || 'Failed to complete sale transaction' });
    } finally {
      setIsProcessingSale(false);
    }
  };

  // Keyboard shortcut listener for F9 / Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F9') {
        e.preventDefault();
        handleCompleteSale();
      } else if (e.key === 'Escape' && !quickAddBarcode && !completedReceipt) {
        barcodeInputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [cart, totalAmount, paymentMethod, tendered, splitDetails, quickAddBarcode, completedReceipt]);

  return (
    <div id="pos-billing-container" className="h-[calc(100vh-2.5rem)] flex flex-col md:flex-row overflow-hidden bg-slate-950 text-slate-100">
      {/* Left section: Product Search & Cart Table */}
      <div className="flex-1 flex flex-col border-r border-slate-800 overflow-hidden">
        {/* Barcode Search Bar */}
        <div className="p-3 bg-slate-900 border-b border-slate-800 shrink-0">
          <form onSubmit={handleBarcodeSubmit} className="relative flex items-center gap-2">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Barcode className="w-5 h-5 text-blue-400" />
              </div>
              <input
                ref={barcodeInputRef}
                type="text"
                value={barcodeInput}
                onChange={(e) => handleSearchChange(e.target.value)}
                placeholder={t.barcodeSearchPlaceholder}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-sm text-slate-100 font-medium placeholder-slate-500 focus:outline-hidden focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md transition-colors cursor-pointer shrink-0"
            >
              {t.addItem}
            </button>
            <button
              type="button"
              onClick={() => setShowCameraScanner(true)}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-blue-300 text-xs font-medium border border-blue-800/80 cursor-pointer shrink-0 transition-colors"
              title="Scan Barcode with Camera"
            >
              <Camera className="w-4 h-4 text-blue-400" />
              <span className="hidden sm:inline">Camera Scan</span>
            </button>
            <button
              type="button"
              onClick={() => setQuickAddBarcode('NEW')}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 cursor-pointer shrink-0"
              title="Quick Add Product without leaving POS"
            >
              <PackagePlus className="w-4 h-4 text-emerald-400" />
              <span className="hidden sm:inline">{t.quickAddProduct}</span>
            </button>
          </form>

          {/* Autocomplete Dropdown */}
          {filteredProducts.length > 0 && (
            <div className="absolute left-3 right-80 mt-1 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-40 overflow-hidden divide-y divide-slate-800 max-h-60 overflow-y-auto">
              {filteredProducts.map((p) => (
                <div
                  key={p.id}
                  onClick={() => {
                    addItemToCart(p);
                    setBarcodeInput('');
                  }}
                  className="p-3 hover:bg-slate-800/80 cursor-pointer flex items-center justify-between text-xs transition-colors"
                >
                  <div className="space-y-0.5">
                    <p className="font-semibold text-slate-100">{p.name}</p>
                    <p className="text-[11px] text-slate-400 font-mono">
                      Barcode: {p.barcode} | Stock: {p.current_stock}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-emerald-400">₹{p.selling_price.toFixed(2)}</p>
                    {p.category_name && (
                      <span className="text-[10px] text-slate-500">{p.category_name}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Feedback Alert */}
        {feedbackMsg && (
          <div
            className={`px-4 py-2 text-xs flex items-center justify-between ${
              feedbackMsg.type === 'success'
                ? 'bg-emerald-950/80 text-emerald-300 border-b border-emerald-800'
                : 'bg-red-950/80 text-red-300 border-b border-red-800'
            }`}
          >
            <div className="flex items-center gap-2">
              {feedbackMsg.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4" />
              ) : (
                <AlertCircle className="w-4 h-4" />
              )}
              <span>{feedbackMsg.text}</span>
            </div>
            <button
              onClick={() => setFeedbackMsg(null)}
              className="text-slate-400 hover:text-white"
            >
              ✕
            </button>
          </div>
        )}

        {/* Cart Items Table */}
        <div className="flex-1 overflow-y-auto p-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-3 p-8">
              <Barcode className="w-16 h-16 text-slate-700 stroke-1" />
              <p className="text-sm">{t.cartEmpty}</p>
              <p className="text-xs text-slate-600">
                Type a barcode or scan with a handheld scanner. Scanned items add immediately.
              </p>
            </div>
          ) : (
            <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900/60 shadow-inner">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-900 text-slate-400 uppercase tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="p-3">#</th>
                    <th className="p-3">{t.item}</th>
                    <th className="p-3">{t.barcode}</th>
                    <th className="p-3 text-center">{t.qty}</th>
                    <th className="p-3 text-right">{t.rate} (₹)</th>
                    <th className="p-3 text-right">{t.amount} (₹)</th>
                    <th className="p-3 text-center">{t.action}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {cart.map((item, idx) => (
                    <tr key={item.product.id} className="hover:bg-slate-800/40">
                      <td className="p-3 font-mono text-slate-500">{idx + 1}</td>
                      <td className="p-3 font-medium text-slate-100">
                        <div>{item.product.name}</div>
                        <div className="text-[10px] text-slate-500">
                          Stock available: {item.product.current_stock}
                        </div>
                      </td>
                      <td className="p-3 font-mono text-slate-400">{item.product.barcode}</td>
                      <td className="p-3">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.product.id, -1)}
                            className="w-6 h-6 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-8 text-center font-bold text-sm text-white">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.product.id, 1)}
                            className="w-6 h-6 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                      <td className="p-3 text-right">
                        <input
                          type="number"
                          step="any"
                          value={item.rate}
                          onChange={(e) =>
                            updateItemRate(item.product.id, parseFloat(e.target.value) || 0)
                          }
                          className="w-20 px-1.5 py-1 bg-slate-950 border border-slate-700 rounded text-right text-xs text-slate-100 font-mono"
                        />
                      </td>
                      <td className="p-3 text-right font-bold text-emerald-400">
                        ₹{item.amount.toFixed(2)}
                      </td>
                      <td className="p-3 text-center">
                        <button
                          type="button"
                          onClick={() => removeFromCart(item.product.id)}
                          className="p-1 text-red-400 hover:text-red-300 hover:bg-red-950/50 rounded cursor-pointer transition-colors"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Clear Cart Footer Button */}
        {cart.length > 0 && (
          <div className="p-2 px-4 bg-slate-900 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400 shrink-0">
            <span>{cart.length} item(s) in cart</span>
            <button
              onClick={clearCart}
              className="flex items-center gap-1 text-red-400 hover:text-red-300 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Clear Cart</span>
            </button>
          </div>
        )}
      </div>

      {/* Right section: Customer, Pricing & Payment Sidebar */}
      <div className="w-full md:w-96 bg-slate-900 flex flex-col justify-between p-4 overflow-y-auto space-y-4 shrink-0">
        <div className="space-y-4">
          {/* Customer Details Accordion/Section */}
          <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2">
            <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-blue-400" />
              {t.customerDetails}
            </span>
            <div className="space-y-2">
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder={t.customerName}
                className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-blue-500"
              />
              <div className="flex gap-2">
                <input
                  type="text"
                  value={customerMobile}
                  onChange={(e) => setCustomerMobile(e.target.value)}
                  placeholder={t.customerMobile}
                  className="flex-1 px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-200 placeholder-slate-500 font-mono focus:outline-hidden focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-400">
              {t.paymentMethod}
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setPaymentMethod('CASH')}
                className={`flex items-center gap-2 p-2.5 rounded-xl border font-medium cursor-pointer transition-colors ${
                  paymentMethod === 'CASH'
                    ? 'bg-emerald-950 border-emerald-600 text-emerald-300'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Banknote className="w-4 h-4 text-emerald-400" />
                <span>{t.cash}</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('UPI')}
                className={`flex items-center gap-2 p-2.5 rounded-xl border font-medium cursor-pointer transition-colors ${
                  paymentMethod === 'UPI'
                    ? 'bg-blue-950 border-blue-600 text-blue-300'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Smartphone className="w-4 h-4 text-blue-400" />
                <span>{t.upi}</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('CARD')}
                className={`flex items-center gap-2 p-2.5 rounded-xl border font-medium cursor-pointer transition-colors ${
                  paymentMethod === 'CARD'
                    ? 'bg-purple-950 border-purple-600 text-purple-300'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <CreditCard className="w-4 h-4 text-purple-400" />
                <span>{t.card}</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('SPLIT')}
                className={`flex items-center gap-2 p-2.5 rounded-xl border font-medium cursor-pointer transition-colors ${
                  paymentMethod === 'SPLIT'
                    ? 'bg-indigo-950 border-indigo-600 text-indigo-300'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Layers className="w-4 h-4 text-indigo-400" />
                <span>{t.split}</span>
              </button>
            </div>

            {/* Paytm manual option */}
            <button
              type="button"
              onClick={() => setPaymentMethod('PAYTM_MANUAL')}
              className={`w-full flex items-center justify-center gap-2 p-2 rounded-lg border text-xs font-medium cursor-pointer transition-colors ${
                paymentMethod === 'PAYTM_MANUAL'
                  ? 'bg-cyan-950 border-cyan-600 text-cyan-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <span>{t.paytmManual}</span>
            </button>
          </div>

          {/* Cash Tendered & Change Due Input */}
          {paymentMethod === 'CASH' && (
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">{t.cashTendered}</span>
                <input
                  type="number"
                  step="any"
                  value={cashTendered}
                  onChange={(e) => setCashTendered(e.target.value)}
                  placeholder={totalAmount.toFixed(2)}
                  className="w-28 px-2 py-1 bg-slate-900 border border-slate-700 rounded text-right font-mono font-bold text-white focus:outline-hidden focus:border-emerald-500"
                />
              </div>
              <div className="flex items-center justify-between text-xs border-t border-slate-800 pt-2">
                <span className="text-slate-400">{t.changeDue}</span>
                <span className="font-bold text-sm text-emerald-400 font-mono">
                  ₹{changeDue.toFixed(2)}
                </span>
              </div>
            </div>
          )}

          {/* Split Payment inputs */}
          {paymentMethod === 'SPLIT' && (
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2 text-xs">
              <span className="font-semibold text-slate-300">Enter Split Amounts:</span>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-slate-400">Cash (₹):</span>
                  <input
                    type="number"
                    value={splitDetails.cash || ''}
                    onChange={(e) =>
                      setSplitDetails({ ...splitDetails, cash: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded font-mono text-white"
                  />
                </div>
                <div>
                  <span className="text-slate-400">UPI (₹):</span>
                  <input
                    type="number"
                    value={splitDetails.upi || ''}
                    onChange={(e) =>
                      setSplitDetails({ ...splitDetails, upi: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded font-mono text-white"
                  />
                </div>
                <div>
                  <span className="text-slate-400">Card (₹):</span>
                  <input
                    type="number"
                    value={splitDetails.card || ''}
                    onChange={(e) =>
                      setSplitDetails({ ...splitDetails, card: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded font-mono text-white"
                  />
                </div>
                <div>
                  <span className="text-slate-400">Paytm (₹):</span>
                  <input
                    type="number"
                    value={splitDetails.paytm || ''}
                    onChange={(e) =>
                      setSplitDetails({ ...splitDetails, paytm: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded font-mono text-white"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Pricing Summary & Checkout Button */}
        <div className="space-y-3 pt-3 border-t border-slate-800">
          <div className="space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>{t.subtotal}:</span>
              <span className="font-mono">₹{subtotal.toFixed(2)}</span>
            </div>

            <div className="flex items-center justify-between text-slate-400">
              <span>{t.discount} (₹):</span>
              <input
                type="number"
                step="any"
                min="0"
                value={discount}
                onChange={(e) => setDiscount(e.target.value)}
                className="w-20 px-2 py-0.5 bg-slate-950 border border-slate-700 rounded text-right font-mono text-white text-xs"
              />
            </div>

            <div className="flex justify-between items-baseline pt-2 border-t border-slate-800 text-white">
              <span className="text-sm font-semibold">{t.total}:</span>
              <span className="text-2xl font-bold font-mono text-emerald-400">
                ₹{totalAmount.toFixed(2)}
              </span>
            </div>
          </div>

          <button
            type="button"
            disabled={isProcessingSale || cart.length === 0}
            onClick={handleCompleteSale}
            className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-bold shadow-lg shadow-emerald-900/40 cursor-pointer flex items-center justify-center gap-2 transition-all"
          >
            <Printer className="w-5 h-5" />
            <span>{isProcessingSale ? 'Saving Sale...' : t.completeSale}</span>
          </button>
        </div>
      </div>

      {/* Quick Add Product Modal */}
      {quickAddBarcode && (
        <QuickAddProductModal
          initialBarcode={quickAddBarcode === 'NEW' ? '' : quickAddBarcode}
          categories={categories}
          currentLang={currentLang}
          onSuccess={(newProduct) => {
            setQuickAddBarcode(null);
            addItemToCart(newProduct);
            loadProductsAndCategories();
          }}
          onClose={() => setQuickAddBarcode(null)}
        />
      )}

      {/* Camera Barcode Scanner Modal */}
      {showCameraScanner && (
        <BarcodeScannerModal
          isOpen={showCameraScanner}
          onScan={async (scannedCode) => {
            setShowCameraScanner(false);
            const found = await ipcClient.getProductByBarcode(scannedCode);
            if (found) {
              addItemToCart(found);
            } else {
              setQuickAddBarcode(scannedCode);
            }
          }}
          onClose={() => setShowCameraScanner(false)}
          title="Scan Product for POS Billing"
          instruction="Align barcode within camera viewframe"
        />
      )}

      {/* Thermal Receipt Preview Modal */}
      {completedReceipt && (
        <ReceiptModal
          receiptData={completedReceipt}
          currentLang={currentLang}
          onClose={() => setCompletedReceipt(null)}
        />
      )}
    </div>
  );
};
