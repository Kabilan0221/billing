// Utility for generating unique barcodes and audio feedback for scanning

export function generateUniqueBarcode(existingBarcodes: string[] = []): string {
  const existingSet = new Set(existingBarcodes.map((b) => b.trim().toLowerCase()));

  // Standard retail format: 890 (India GS1 prefix) + 9 unique digits
  for (let attempt = 0; attempt < 100; attempt++) {
    const timestampSuffix = Date.now().toString().slice(-6);
    const randomSuffix = Math.floor(100 + Math.random() * 900).toString();
    const candidate = `890${timestampSuffix}${randomSuffix}`;

    if (!existingSet.has(candidate.toLowerCase())) {
      return candidate;
    }
  }

  // Fallback high-entropy barcode
  return `890${Math.floor(100000000 + Math.random() * 900000000)}`;
}

// Pleasant POS beep feedback using Web Audio API
export function playScanBeep(success: boolean = true) {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    if (success) {
      // High crisp pitch for successful barcode scan
      osc.frequency.setValueAtTime(1760, ctx.currentTime); // A6
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } else {
      // Low dual pitch for error
      osc.frequency.setValueAtTime(300, ctx.currentTime);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    }
  } catch (err) {
    // Audio might be blocked by browser policy before first interaction
    console.debug('Audio beep unavailable:', err);
  }
}
